/* tslint:disable */

/* -------------------------------------------------- */

/*      Start of Webpack Hot Extension Middleware     */

/* ================================================== */

/*  This will be converted into a lodash templ., any  */

/*  external argument must be provided using it       */

/* -------------------------------------------------- */
(function(window) {
  var injectionContext = {
    browser: null
  };
  (function() {
    "" ||
      (function(global, factory) {
        if (typeof define === "function" && define.amd) {
          define("webextension-polyfill", ["module"], factory);
        } else if (typeof exports !== "undefined") {
          factory(module);
        } else {
          var mod = {
            exports: {}
          };
          factory(mod);
          global.browser = mod.exports;
        }
      })(this, function(module) {
        /* webextension-polyfill - v0.5.0 - Thu Sep 26 2019 22:22:26 */
        /* -*- Mode: indent-tabs-mode: nil; js-indent-level: 2 -*- */
        /* vim: set sts=2 sw=2 et tw=80: */
        /* This Source Code Form is subject to the terms of the Mozilla Public
         * License, v. 2.0. If a copy of the MPL was not distributed with this
         * file, You can obtain one at http://mozilla.org/MPL/2.0/. */
        "use strict";

        if (
          typeof browser === "undefined" ||
          Object.getPrototypeOf(browser) !== Object.prototype
        ) {
          const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE =
            "The message port closed before a response was received.";
          const SEND_RESPONSE_DEPRECATION_WARNING =
            "Returning a Promise is the preferred way to send a reply from an onMessage/onMessageExternal listener, as the sendResponse will be removed from the specs (See https://developer.mozilla.org/docs/Mozilla/Add-ons/WebExtensions/API/runtime/onMessage)";

          // Wrapping the bulk of this polyfill in a one-time-use function is a minor
          // optimization for Firefox. Since Spidermonkey does not fully parse the
          // contents of a function until the first time it's called, and since it will
          // never actually need to be called, this allows the polyfill to be included
          // in Firefox nearly for free.
          const wrapAPIs = extensionAPIs => {
            // NOTE: apiMetadata is associated to the content of the api-metadata.json file
            // at build time by replacing the following "include" with the content of the
            // JSON file.
            const apiMetadata = {
              alarms: {
                clear: {
                  minArgs: 0,
                  maxArgs: 1
                },
                clearAll: {
                  minArgs: 0,
                  maxArgs: 0
                },
                get: {
                  minArgs: 0,
                  maxArgs: 1
                },
                getAll: {
                  minArgs: 0,
                  maxArgs: 0
                }
              },
              bookmarks: {
                create: {
                  minArgs: 1,
                  maxArgs: 1
                },
                get: {
                  minArgs: 1,
                  maxArgs: 1
                },
                getChildren: {
                  minArgs: 1,
                  maxArgs: 1
                },
                getRecent: {
                  minArgs: 1,
                  maxArgs: 1
                },
                getSubTree: {
                  minArgs: 1,
                  maxArgs: 1
                },
                getTree: {
                  minArgs: 0,
                  maxArgs: 0
                },
                move: {
                  minArgs: 2,
                  maxArgs: 2
                },
                remove: {
                  minArgs: 1,
                  maxArgs: 1
                },
                removeTree: {
                  minArgs: 1,
                  maxArgs: 1
                },
                search: {
                  minArgs: 1,
                  maxArgs: 1
                },
                update: {
                  minArgs: 2,
                  maxArgs: 2
                }
              },
              browserAction: {
                disable: {
                  minArgs: 0,
                  maxArgs: 1,
                  fallbackToNoCallback: true
                },
                enable: {
                  minArgs: 0,
                  maxArgs: 1,
                  fallbackToNoCallback: true
                },
                getBadgeBackgroundColor: {
                  minArgs: 1,
                  maxArgs: 1
                },
                getBadgeText: {
                  minArgs: 1,
                  maxArgs: 1
                },
                getPopup: {
                  minArgs: 1,
                  maxArgs: 1
                },
                getTitle: {
                  minArgs: 1,
                  maxArgs: 1
                },
                openPopup: {
                  minArgs: 0,
                  maxArgs: 0
                },
                setBadgeBackgroundColor: {
                  minArgs: 1,
                  maxArgs: 1,
                  fallbackToNoCallback: true
                },
                setBadgeText: {
                  minArgs: 1,
                  maxArgs: 1,
                  fallbackToNoCallback: true
                },
                setIcon: {
                  minArgs: 1,
                  maxArgs: 1
                },
                setPopup: {
                  minArgs: 1,
                  maxArgs: 1,
                  fallbackToNoCallback: true
                },
                setTitle: {
                  minArgs: 1,
                  maxArgs: 1,
                  fallbackToNoCallback: true
                }
              },
              browsingData: {
                remove: {
                  minArgs: 2,
                  maxArgs: 2
                },
                removeCache: {
                  minArgs: 1,
                  maxArgs: 1
                },
                removeCookies: {
                  minArgs: 1,
                  maxArgs: 1
                },
                removeDownloads: {
                  minArgs: 1,
                  maxArgs: 1
                },
                removeFormData: {
                  minArgs: 1,
                  maxArgs: 1
                },
                removeHistory: {
                  minArgs: 1,
                  maxArgs: 1
                },
                removeLocalStorage: {
                  minArgs: 1,
                  maxArgs: 1
                },
                removePasswords: {
                  minArgs: 1,
                  maxArgs: 1
                },
                removePluginData: {
                  minArgs: 1,
                  maxArgs: 1
                },
                settings: {
                  minArgs: 0,
                  maxArgs: 0
                }
              },
              commands: {
                getAll: {
                  minArgs: 0,
                  maxArgs: 0
                }
              },
              contextMenus: {
                remove: {
                  minArgs: 1,
                  maxArgs: 1
                },
                removeAll: {
                  minArgs: 0,
                  maxArgs: 0
                },
                update: {
                  minArgs: 2,
                  maxArgs: 2
                }
              },
              cookies: {
                get: {
                  minArgs: 1,
                  maxArgs: 1
                },
                getAll: {
                  minArgs: 1,
                  maxArgs: 1
                },
                getAllCookieStores: {
                  minArgs: 0,
                  maxArgs: 0
                },
                remove: {
                  minArgs: 1,
                  maxArgs: 1
                },
                set: {
                  minArgs: 1,
                  maxArgs: 1
                }
              },
              devtools: {
                inspectedWindow: {
                  eval: {
                    minArgs: 1,
                    maxArgs: 2,
                    singleCallbackArg: false
                  }
                },
                panels: {
                  create: {
                    minArgs: 3,
                    maxArgs: 3,
                    singleCallbackArg: true
                  }
                }
              },
              downloads: {
                cancel: {
                  minArgs: 1,
                  maxArgs: 1
                },
                download: {
                  minArgs: 1,
                  maxArgs: 1
                },
                erase: {
                  minArgs: 1,
                  maxArgs: 1
                },
                getFileIcon: {
                  minArgs: 1,
                  maxArgs: 2
                },
                open: {
                  minArgs: 1,
                  maxArgs: 1,
                  fallbackToNoCallback: true
                },
                pause: {
                  minArgs: 1,
                  maxArgs: 1
                },
                removeFile: {
                  minArgs: 1,
                  maxArgs: 1
                },
                resume: {
                  minArgs: 1,
                  maxArgs: 1
                },
                search: {
                  minArgs: 1,
                  maxArgs: 1
                },
                show: {
                  minArgs: 1,
                  maxArgs: 1,
                  fallbackToNoCallback: true
                }
              },
              extension: {
                isAllowedFileSchemeAccess: {
                  minArgs: 0,
                  maxArgs: 0
                },
                isAllowedIncognitoAccess: {
                  minArgs: 0,
                  maxArgs: 0
                }
              },
              history: {
                addUrl: {
                  minArgs: 1,
                  maxArgs: 1
                },
                deleteAll: {
                  minArgs: 0,
                  maxArgs: 0
                },
                deleteRange: {
                  minArgs: 1,
                  maxArgs: 1
                },
                deleteUrl: {
                  minArgs: 1,
                  maxArgs: 1
                },
                getVisits: {
                  minArgs: 1,
                  maxArgs: 1
                },
                search: {
                  minArgs: 1,
                  maxArgs: 1
                }
              },
              i18n: {
                detectLanguage: {
                  minArgs: 1,
                  maxArgs: 1
                },
                getAcceptLanguages: {
                  minArgs: 0,
                  maxArgs: 0
                }
              },
              identity: {
                launchWebAuthFlow: {
                  minArgs: 1,
                  maxArgs: 1
                }
              },
              idle: {
                queryState: {
                  minArgs: 1,
                  maxArgs: 1
                }
              },
              management: {
                get: {
                  minArgs: 1,
                  maxArgs: 1
                },
                getAll: {
                  minArgs: 0,
                  maxArgs: 0
                },
                getSelf: {
                  minArgs: 0,
                  maxArgs: 0
                },
                setEnabled: {
                  minArgs: 2,
                  maxArgs: 2
                },
                uninstallSelf: {
                  minArgs: 0,
                  maxArgs: 1
                }
              },
              notifications: {
                clear: {
                  minArgs: 1,
                  maxArgs: 1
                },
                create: {
                  minArgs: 1,
                  maxArgs: 2
                },
                getAll: {
                  minArgs: 0,
                  maxArgs: 0
                },
                getPermissionLevel: {
                  minArgs: 0,
                  maxArgs: 0
                },
                update: {
                  minArgs: 2,
                  maxArgs: 2
                }
              },
              pageAction: {
                getPopup: {
                  minArgs: 1,
                  maxArgs: 1
                },
                getTitle: {
                  minArgs: 1,
                  maxArgs: 1
                },
                hide: {
                  minArgs: 1,
                  maxArgs: 1,
                  fallbackToNoCallback: true
                },
                setIcon: {
                  minArgs: 1,
                  maxArgs: 1
                },
                setPopup: {
                  minArgs: 1,
                  maxArgs: 1,
                  fallbackToNoCallback: true
                },
                setTitle: {
                  minArgs: 1,
                  maxArgs: 1,
                  fallbackToNoCallback: true
                },
                show: {
                  minArgs: 1,
                  maxArgs: 1,
                  fallbackToNoCallback: true
                }
              },
              permissions: {
                contains: {
                  minArgs: 1,
                  maxArgs: 1
                },
                getAll: {
                  minArgs: 0,
                  maxArgs: 0
                },
                remove: {
                  minArgs: 1,
                  maxArgs: 1
                },
                request: {
                  minArgs: 1,
                  maxArgs: 1
                }
              },
              runtime: {
                getBackgroundPage: {
                  minArgs: 0,
                  maxArgs: 0
                },
                getPlatformInfo: {
                  minArgs: 0,
                  maxArgs: 0
                },
                openOptionsPage: {
                  minArgs: 0,
                  maxArgs: 0
                },
                requestUpdateCheck: {
                  minArgs: 0,
                  maxArgs: 0
                },
                sendMessage: {
                  minArgs: 1,
                  maxArgs: 3
                },
                sendNativeMessage: {
                  minArgs: 2,
                  maxArgs: 2
                },
                setUninstallURL: {
                  minArgs: 1,
                  maxArgs: 1
                }
              },
              sessions: {
                getDevices: {
                  minArgs: 0,
                  maxArgs: 1
                },
                getRecentlyClosed: {
                  minArgs: 0,
                  maxArgs: 1
                },
                restore: {
                  minArgs: 0,
                  maxArgs: 1
                }
              },
              storage: {
                local: {
                  clear: {
                    minArgs: 0,
                    maxArgs: 0
                  },
                  get: {
                    minArgs: 0,
                    maxArgs: 1
                  },
                  getBytesInUse: {
                    minArgs: 0,
                    maxArgs: 1
                  },
                  remove: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  set: {
                    minArgs: 1,
                    maxArgs: 1
                  }
                },
                managed: {
                  get: {
                    minArgs: 0,
                    maxArgs: 1
                  },
                  getBytesInUse: {
                    minArgs: 0,
                    maxArgs: 1
                  }
                },
                sync: {
                  clear: {
                    minArgs: 0,
                    maxArgs: 0
                  },
                  get: {
                    minArgs: 0,
                    maxArgs: 1
                  },
                  getBytesInUse: {
                    minArgs: 0,
                    maxArgs: 1
                  },
                  remove: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  set: {
                    minArgs: 1,
                    maxArgs: 1
                  }
                }
              },
              tabs: {
                captureVisibleTab: {
                  minArgs: 0,
                  maxArgs: 2
                },
                create: {
                  minArgs: 1,
                  maxArgs: 1
                },
                detectLanguage: {
                  minArgs: 0,
                  maxArgs: 1
                },
                discard: {
                  minArgs: 0,
                  maxArgs: 1
                },
                duplicate: {
                  minArgs: 1,
                  maxArgs: 1
                },
                executeScript: {
                  minArgs: 1,
                  maxArgs: 2
                },
                get: {
                  minArgs: 1,
                  maxArgs: 1
                },
                getCurrent: {
                  minArgs: 0,
                  maxArgs: 0
                },
                getZoom: {
                  minArgs: 0,
                  maxArgs: 1
                },
                getZoomSettings: {
                  minArgs: 0,
                  maxArgs: 1
                },
                highlight: {
                  minArgs: 1,
                  maxArgs: 1
                },
                insertCSS: {
                  minArgs: 1,
                  maxArgs: 2
                },
                move: {
                  minArgs: 2,
                  maxArgs: 2
                },
                query: {
                  minArgs: 1,
                  maxArgs: 1
                },
                reload: {
                  minArgs: 0,
                  maxArgs: 2
                },
                remove: {
                  minArgs: 1,
                  maxArgs: 1
                },
                removeCSS: {
                  minArgs: 1,
                  maxArgs: 2
                },
                sendMessage: {
                  minArgs: 2,
                  maxArgs: 3
                },
                setZoom: {
                  minArgs: 1,
                  maxArgs: 2
                },
                setZoomSettings: {
                  minArgs: 1,
                  maxArgs: 2
                },
                update: {
                  minArgs: 1,
                  maxArgs: 2
                }
              },
              topSites: {
                get: {
                  minArgs: 0,
                  maxArgs: 0
                }
              },
              webNavigation: {
                getAllFrames: {
                  minArgs: 1,
                  maxArgs: 1
                },
                getFrame: {
                  minArgs: 1,
                  maxArgs: 1
                }
              },
              webRequest: {
                handlerBehaviorChanged: {
                  minArgs: 0,
                  maxArgs: 0
                }
              },
              windows: {
                create: {
                  minArgs: 0,
                  maxArgs: 1
                },
                get: {
                  minArgs: 1,
                  maxArgs: 2
                },
                getAll: {
                  minArgs: 0,
                  maxArgs: 1
                },
                getCurrent: {
                  minArgs: 0,
                  maxArgs: 1
                },
                getLastFocused: {
                  minArgs: 0,
                  maxArgs: 1
                },
                remove: {
                  minArgs: 1,
                  maxArgs: 1
                },
                update: {
                  minArgs: 2,
                  maxArgs: 2
                }
              }
            };

            if (Object.keys(apiMetadata).length === 0) {
              throw new Error(
                "api-metadata.json has not been included in browser-polyfill"
              );
            }

            /**
             * A WeakMap subclass which creates and stores a value for any key which does
             * not exist when accessed, but behaves exactly as an ordinary WeakMap
             * otherwise.
             *
             * @param {function} createItem
             *        A function which will be called in order to create the value for any
             *        key which does not exist, the first time it is accessed. The
             *        function receives, as its only argument, the key being created.
             */
            class DefaultWeakMap extends WeakMap {
              constructor(createItem, items = undefined) {
                super(items);
                this.createItem = createItem;
              }

              get(key) {
                if (!this.has(key)) {
                  this.set(key, this.createItem(key));
                }

                return super.get(key);
              }
            }

            /**
             * Returns true if the given object is an object with a `then` method, and can
             * therefore be assumed to behave as a Promise.
             *
             * @param {*} value The value to test.
             * @returns {boolean} True if the value is thenable.
             */
            const isThenable = value => {
              return (
                value &&
                typeof value === "object" &&
                typeof value.then === "function"
              );
            };

            /**
             * Creates and returns a function which, when called, will resolve or reject
             * the given promise based on how it is called:
             *
             * - If, when called, `chrome.runtime.lastError` contains a non-null object,
             *   the promise is rejected with that value.
             * - If the function is called with exactly one argument, the promise is
             *   resolved to that value.
             * - Otherwise, the promise is resolved to an array containing all of the
             *   function's arguments.
             *
             * @param {object} promise
             *        An object containing the resolution and rejection functions of a
             *        promise.
             * @param {function} promise.resolve
             *        The promise's resolution function.
             * @param {function} promise.rejection
             *        The promise's rejection function.
             * @param {object} metadata
             *        Metadata about the wrapped method which has created the callback.
             * @param {integer} metadata.maxResolvedArgs
             *        The maximum number of arguments which may be passed to the
             *        callback created by the wrapped async function.
             *
             * @returns {function}
             *        The generated callback function.
             */
            const makeCallback = (promise, metadata) => {
              return (...callbackArgs) => {
                if (extensionAPIs.runtime.lastError) {
                  promise.reject(extensionAPIs.runtime.lastError);
                } else if (
                  metadata.singleCallbackArg ||
                  (callbackArgs.length <= 1 &&
                    metadata.singleCallbackArg !== false)
                ) {
                  promise.resolve(callbackArgs[0]);
                } else {
                  promise.resolve(callbackArgs);
                }
              };
            };

            const pluralizeArguments = numArgs =>
              numArgs == 1 ? "argument" : "arguments";

            /**
             * Creates a wrapper function for a method with the given name and metadata.
             *
             * @param {string} name
             *        The name of the method which is being wrapped.
             * @param {object} metadata
             *        Metadata about the method being wrapped.
             * @param {integer} metadata.minArgs
             *        The minimum number of arguments which must be passed to the
             *        function. If called with fewer than this number of arguments, the
             *        wrapper will raise an exception.
             * @param {integer} metadata.maxArgs
             *        The maximum number of arguments which may be passed to the
             *        function. If called with more than this number of arguments, the
             *        wrapper will raise an exception.
             * @param {integer} metadata.maxResolvedArgs
             *        The maximum number of arguments which may be passed to the
             *        callback created by the wrapped async function.
             *
             * @returns {function(object, ...*)}
             *       The generated wrapper function.
             */
            const wrapAsyncFunction = (name, metadata) => {
              return function asyncFunctionWrapper(target, ...args) {
                if (args.length < metadata.minArgs) {
                  throw new Error(
                    `Expected at least ${metadata.minArgs} ${pluralizeArguments(
                      metadata.minArgs
                    )} for ${name}(), got ${args.length}`
                  );
                }

                if (args.length > metadata.maxArgs) {
                  throw new Error(
                    `Expected at most ${metadata.maxArgs} ${pluralizeArguments(
                      metadata.maxArgs
                    )} for ${name}(), got ${args.length}`
                  );
                }

                return new Promise((resolve, reject) => {
                  if (metadata.fallbackToNoCallback) {
                    // This API method has currently no callback on Chrome, but it return a promise on Firefox,
                    // and so the polyfill will try to call it with a callback first, and it will fallback
                    // to not passing the callback if the first call fails.
                    try {
                      target[name](
                        ...args,
                        makeCallback({ resolve, reject }, metadata)
                      );
                    } catch (cbError) {
                      console.warn(
                        `${name} API method doesn't seem to support the callback parameter, ` +
                          "falling back to call it without a callback: ",
                        cbError
                      );

                      target[name](...args);

                      // Update the API method metadata, so that the next API calls will not try to
                      // use the unsupported callback anymore.
                      metadata.fallbackToNoCallback = false;
                      metadata.noCallback = true;

                      resolve();
                    }
                  } else if (metadata.noCallback) {
                    target[name](...args);
                    resolve();
                  } else {
                    target[name](
                      ...args,
                      makeCallback({ resolve, reject }, metadata)
                    );
                  }
                });
              };
            };

            /**
             * Wraps an existing method of the target object, so that calls to it are
             * intercepted by the given wrapper function. The wrapper function receives,
             * as its first argument, the original `target` object, followed by each of
             * the arguments passed to the original method.
             *
             * @param {object} target
             *        The original target object that the wrapped method belongs to.
             * @param {function} method
             *        The method being wrapped. This is used as the target of the Proxy
             *        object which is created to wrap the method.
             * @param {function} wrapper
             *        The wrapper function which is called in place of a direct invocation
             *        of the wrapped method.
             *
             * @returns {Proxy<function>}
             *        A Proxy object for the given method, which invokes the given wrapper
             *        method in its place.
             */
            const wrapMethod = (target, method, wrapper) => {
              return new Proxy(method, {
                apply(targetMethod, thisObj, args) {
                  return wrapper.call(thisObj, target, ...args);
                }
              });
            };

            let hasOwnProperty = Function.call.bind(
              Object.prototype.hasOwnProperty
            );

            /**
             * Wraps an object in a Proxy which intercepts and wraps certain methods
             * based on the given `wrappers` and `metadata` objects.
             *
             * @param {object} target
             *        The target object to wrap.
             *
             * @param {object} [wrappers = {}]
             *        An object tree containing wrapper functions for special cases. Any
             *        function present in this object tree is called in place of the
             *        method in the same location in the `target` object tree. These
             *        wrapper methods are invoked as described in {@see wrapMethod}.
             *
             * @param {object} [metadata = {}]
             *        An object tree containing metadata used to automatically generate
             *        Promise-based wrapper functions for asynchronous. Any function in
             *        the `target` object tree which has a corresponding metadata object
             *        in the same location in the `metadata` tree is replaced with an
             *        automatically-generated wrapper function, as described in
             *        {@see wrapAsyncFunction}
             *
             * @returns {Proxy<object>}
             */
            const wrapObject = (target, wrappers = {}, metadata = {}) => {
              let cache = Object.create(null);
              let handlers = {
                has(proxyTarget, prop) {
                  return prop in target || prop in cache;
                },

                get(proxyTarget, prop, receiver) {
                  if (prop in cache) {
                    return cache[prop];
                  }

                  if (!(prop in target)) {
                    return undefined;
                  }

                  let value = target[prop];

                  if (typeof value === "function") {
                    // This is a method on the underlying object. Check if we need to do
                    // any wrapping.

                    if (typeof wrappers[prop] === "function") {
                      // We have a special-case wrapper for this method.
                      value = wrapMethod(target, target[prop], wrappers[prop]);
                    } else if (hasOwnProperty(metadata, prop)) {
                      // This is an async method that we have metadata for. Create a
                      // Promise wrapper for it.
                      let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                      value = wrapMethod(target, target[prop], wrapper);
                    } else {
                      // This is a method that we don't know or care about. Return the
                      // original method, bound to the underlying object.
                      value = value.bind(target);
                    }
                  } else if (
                    typeof value === "object" &&
                    value !== null &&
                    (hasOwnProperty(wrappers, prop) ||
                      hasOwnProperty(metadata, prop))
                  ) {
                    // This is an object that we need to do some wrapping for the children
                    // of. Create a sub-object wrapper for it with the appropriate child
                    // metadata.
                    value = wrapObject(value, wrappers[prop], metadata[prop]);
                  } else {
                    // We don't need to do any wrapping for this property,
                    // so just forward all access to the underlying object.
                    Object.defineProperty(cache, prop, {
                      configurable: true,
                      enumerable: true,
                      get() {
                        return target[prop];
                      },
                      set(value) {
                        target[prop] = value;
                      }
                    });

                    return value;
                  }

                  cache[prop] = value;
                  return value;
                },

                set(proxyTarget, prop, value, receiver) {
                  if (prop in cache) {
                    cache[prop] = value;
                  } else {
                    target[prop] = value;
                  }
                  return true;
                },

                defineProperty(proxyTarget, prop, desc) {
                  return Reflect.defineProperty(cache, prop, desc);
                },

                deleteProperty(proxyTarget, prop) {
                  return Reflect.deleteProperty(cache, prop);
                }
              };

              // Per contract of the Proxy API, the "get" proxy handler must return the
              // original value of the target if that value is declared read-only and
              // non-configurable. For this reason, we create an object with the
              // prototype set to `target` instead of using `target` directly.
              // Otherwise we cannot return a custom object for APIs that
              // are declared read-only and non-configurable, such as `chrome.devtools`.
              //
              // The proxy handlers themselves will still use the original `target`
              // instead of the `proxyTarget`, so that the methods and properties are
              // dereferenced via the original targets.
              let proxyTarget = Object.create(target);
              return new Proxy(proxyTarget, handlers);
            };

            /**
             * Creates a set of wrapper functions for an event object, which handles
             * wrapping of listener functions that those messages are passed.
             *
             * A single wrapper is created for each listener function, and stored in a
             * map. Subsequent calls to `addListener`, `hasListener`, or `removeListener`
             * retrieve the original wrapper, so that  attempts to remove a
             * previously-added listener work as expected.
             *
             * @param {DefaultWeakMap<function, function>} wrapperMap
             *        A DefaultWeakMap object which will create the appropriate wrapper
             *        for a given listener function when one does not exist, and retrieve
             *        an existing one when it does.
             *
             * @returns {object}
             */
            const wrapEvent = wrapperMap => ({
              addListener(target, listener, ...args) {
                target.addListener(wrapperMap.get(listener), ...args);
              },

              hasListener(target, listener) {
                return target.hasListener(wrapperMap.get(listener));
              },

              removeListener(target, listener) {
                target.removeListener(wrapperMap.get(listener));
              }
            });

            // Keep track if the deprecation warning has been logged at least once.
            let loggedSendResponseDeprecationWarning = false;

            const onMessageWrappers = new DefaultWeakMap(listener => {
              if (typeof listener !== "function") {
                return listener;
              }

              /**
               * Wraps a message listener function so that it may send responses based on
               * its return value, rather than by returning a sentinel value and calling a
               * callback. If the listener function returns a Promise, the response is
               * sent when the promise either resolves or rejects.
               *
               * @param {*} message
               *        The message sent by the other end of the channel.
               * @param {object} sender
               *        Details about the sender of the message.
               * @param {function(*)} sendResponse
               *        A callback which, when called with an arbitrary argument, sends
               *        that value as a response.
               * @returns {boolean}
               *        True if the wrapped listener returned a Promise, which will later
               *        yield a response. False otherwise.
               */
              return function onMessage(message, sender, sendResponse) {
                let didCallSendResponse = false;

                let wrappedSendResponse;
                let sendResponsePromise = new Promise(resolve => {
                  wrappedSendResponse = function(response) {
                    if (!loggedSendResponseDeprecationWarning) {
                      console.warn(
                        SEND_RESPONSE_DEPRECATION_WARNING,
                        new Error().stack
                      );
                      loggedSendResponseDeprecationWarning = true;
                    }
                    didCallSendResponse = true;
                    resolve(response);
                  };
                });

                let result;
                try {
                  result = listener(message, sender, wrappedSendResponse);
                } catch (err) {
                  result = Promise.reject(err);
                }

                const isResultThenable = result !== true && isThenable(result);

                // If the listener didn't returned true or a Promise, or called
                // wrappedSendResponse synchronously, we can exit earlier
                // because there will be no response sent from this listener.
                if (
                  result !== true &&
                  !isResultThenable &&
                  !didCallSendResponse
                ) {
                  return false;
                }

                // A small helper to send the message if the promise resolves
                // and an error if the promise rejects (a wrapped sendMessage has
                // to translate the message into a resolved promise or a rejected
                // promise).
                const sendPromisedResult = promise => {
                  promise
                    .then(
                      msg => {
                        // send the message value.
                        sendResponse(msg);
                      },
                      error => {
                        // Send a JSON representation of the error if the rejected value
                        // is an instance of error, or the object itself otherwise.
                        let message;
                        if (
                          error &&
                          (error instanceof Error ||
                            typeof error.message === "string")
                        ) {
                          message = error.message;
                        } else {
                          message = "An unexpected error occurred";
                        }

                        sendResponse({
                          __mozWebExtensionPolyfillReject__: true,
                          message
                        });
                      }
                    )
                    .catch(err => {
                      // Print an error on the console if unable to send the response.
                      console.error(
                        "Failed to send onMessage rejected reply",
                        err
                      );
                    });
                };

                // If the listener returned a Promise, send the resolved value as a
                // result, otherwise wait the promise related to the wrappedSendResponse
                // callback to resolve and send it as a response.
                if (isResultThenable) {
                  sendPromisedResult(result);
                } else {
                  sendPromisedResult(sendResponsePromise);
                }

                // Let Chrome know that the listener is replying.
                return true;
              };
            });

            const wrappedSendMessageCallback = ({ reject, resolve }, reply) => {
              if (extensionAPIs.runtime.lastError) {
                // Detect when none of the listeners replied to the sendMessage call and resolve
                // the promise to undefined as in Firefox.
                // See https://github.com/mozilla/webextension-polyfill/issues/130
                if (
                  extensionAPIs.runtime.lastError.message ===
                  CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE
                ) {
                  resolve();
                } else {
                  reject(extensionAPIs.runtime.lastError);
                }
              } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                // Convert back the JSON representation of the error into
                // an Error instance.
                reject(new Error(reply.message));
              } else {
                resolve(reply);
              }
            };

            const wrappedSendMessage = (
              name,
              metadata,
              apiNamespaceObj,
              ...args
            ) => {
              if (args.length < metadata.minArgs) {
                throw new Error(
                  `Expected at least ${metadata.minArgs} ${pluralizeArguments(
                    metadata.minArgs
                  )} for ${name}(), got ${args.length}`
                );
              }

              if (args.length > metadata.maxArgs) {
                throw new Error(
                  `Expected at most ${metadata.maxArgs} ${pluralizeArguments(
                    metadata.maxArgs
                  )} for ${name}(), got ${args.length}`
                );
              }

              return new Promise((resolve, reject) => {
                const wrappedCb = wrappedSendMessageCallback.bind(null, {
                  resolve,
                  reject
                });
                args.push(wrappedCb);
                apiNamespaceObj.sendMessage(...args);
              });
            };

            const staticWrappers = {
              runtime: {
                onMessage: wrapEvent(onMessageWrappers),
                onMessageExternal: wrapEvent(onMessageWrappers),
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 1,
                  maxArgs: 3
                })
              },
              tabs: {
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 2,
                  maxArgs: 3
                })
              }
            };
            const settingMetadata = {
              clear: { minArgs: 1, maxArgs: 1 },
              get: { minArgs: 1, maxArgs: 1 },
              set: { minArgs: 1, maxArgs: 1 }
            };
            apiMetadata.privacy = {
              network: {
                networkPredictionEnabled: settingMetadata,
                webRTCIPHandlingPolicy: settingMetadata
              },
              services: {
                passwordSavingEnabled: settingMetadata
              },
              websites: {
                hyperlinkAuditingEnabled: settingMetadata,
                referrersEnabled: settingMetadata
              }
            };

            return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
          };

          if (
            typeof chrome != "object" ||
            !chrome ||
            !chrome.runtime ||
            !chrome.runtime.id
          ) {
            throw new Error(
              "This script should only be loaded in a browser extension."
            );
          }

          // The build process adds a UMD wrapper around this file, which makes the
          // `module` variable available.
          module.exports = wrapAPIs(chrome);
        } else {
          module.exports = browser;
        }
      });
    //# sourceMappingURL=browser-polyfill.js.map
    ("");
  }.bind(injectionContext)());
  var browser = injectionContext.browser;
  var signals = JSON.parse(
    '{"SIGN_CHANGE":"SIGN_CHANGE","SIGN_RELOAD":"SIGN_RELOAD","SIGN_RELOADED":"SIGN_RELOADED","SIGN_LOG":"SIGN_LOG","SIGN_CONNECT":"SIGN_CONNECT"}'
  );
  var config = JSON.parse(
    '{"RECONNECT_INTERVAL":2000,"SOCKET_ERR_CODE_REF":"https://tools.ietf.org/html/rfc6455#section-7.4.1"}'
  );
  var reloadPage = "true" === "true";
  var wsHost = "ws://localhost:9090";
  var SIGN_CHANGE = signals.SIGN_CHANGE,
    SIGN_RELOAD = signals.SIGN_RELOAD,
    SIGN_RELOADED = signals.SIGN_RELOADED,
    SIGN_LOG = signals.SIGN_LOG,
    SIGN_CONNECT = signals.SIGN_CONNECT;
  var RECONNECT_INTERVAL = config.RECONNECT_INTERVAL,
    SOCKET_ERR_CODE_REF = config.SOCKET_ERR_CODE_REF;
  var extension = browser.extension,
    runtime = browser.runtime,
    tabs = browser.tabs;
  var manifest = runtime.getManifest(); // =============================== Helper functions ======================================= //

  var formatter = function formatter(msg) {
    return "[ WER: ".concat(msg, " ]");
  };

  var logger = function logger(msg) {
    var level =
      arguments.length > 1 && arguments[1] !== undefined
        ? arguments[1]
        : "info";
    return console[level](formatter(msg));
  };

  var timeFormatter = function timeFormatter(date) {
    return date.toTimeString().replace(/.*(\d{2}:\d{2}:\d{2}).*/, "$1");
  }; // ========================== Called only on content scripts ============================== //

  function contentScriptWorker() {
    runtime
      .sendMessage({
        type: SIGN_CONNECT
      })
      .then(function(msg) {
        return console.info(msg);
      });
    runtime.onMessage.addListener(function(_ref) {
      var type = _ref.type,
        payload = _ref.payload;

      switch (type) {
        case SIGN_RELOAD:
          logger("Detected Changes. Reloading ...");
          reloadPage && window.location.reload();
          break;

        case SIGN_LOG:
          console.info(payload);
          break;
      }
    });
  } // ======================== Called only on background scripts ============================= //

  function backgroundWorker(socket) {
    runtime.onMessage.addListener(function(action, sender) {
      if (action.type === SIGN_CONNECT) {
        return Promise.resolve(
          formatter("Connected to Extension Hot Reloader")
        );
      }

      return true;
    });
    socket.addEventListener("message", function(_ref2) {
      var data = _ref2.data;

      var _JSON$parse = JSON.parse(data),
        type = _JSON$parse.type,
        payload = _JSON$parse.payload;

      if (type === SIGN_CHANGE && (!payload || !payload.onlyPageChanged)) {
        tabs
          .query({
            status: "complete"
          })
          .then(function(loadedTabs) {
            loadedTabs.forEach(function(tab) {
              return (
                tab.id &&
                tabs.sendMessage(tab.id, {
                  type: SIGN_RELOAD
                })
              );
            });
            socket.send(
              JSON.stringify({
                type: SIGN_RELOADED,
                payload: formatter(
                  ""
                    .concat(timeFormatter(new Date()), " - ")
                    .concat(manifest.name, " successfully reloaded")
                )
              })
            );
            runtime.reload();
          });
      } else {
        runtime.sendMessage({
          type: type,
          payload: payload
        });
      }
    });
    socket.addEventListener("close", function(_ref3) {
      var code = _ref3.code;
      logger(
        "Socket connection closed. Code "
          .concat(code, ". See more in ")
          .concat(SOCKET_ERR_CODE_REF),
        "warn"
      );
      var intId = setInterval(function() {
        logger("Attempting to reconnect (tip: Check if Webpack is running)");
        var ws = new WebSocket(wsHost);

        ws.onerror = function() {
          return logger(
            "Error trying to re-connect. Reattempting in ".concat(
              RECONNECT_INTERVAL / 1000,
              "s"
            ),
            "warn"
          );
        };

        ws.addEventListener("open", function() {
          clearInterval(intId);
          logger("Reconnected. Reloading plugin");
          runtime.reload();
        });
      }, RECONNECT_INTERVAL);
    });
  } // ======================== Called only on extension pages that are not the background ============================= //

  function extensionPageWorker() {
    runtime
      .sendMessage({
        type: SIGN_CONNECT
      })
      .then(function(msg) {
        return console.info(msg);
      });
    runtime.onMessage.addListener(function(_ref4) {
      var type = _ref4.type,
        payload = _ref4.payload;

      switch (type) {
        case SIGN_CHANGE:
          logger("Detected Changes. Reloading ...");
          reloadPage && window.location.reload();
          break;

        case SIGN_LOG:
          console.info(payload);
          break;
      }
    });
  } // ======================= Bootstraps the middleware =========================== //

  runtime.reload
    ? extension.getBackgroundPage() === window
      ? backgroundWorker(new WebSocket(wsHost))
      : extensionPageWorker()
    : contentScriptWorker();
})(window);
/* ----------------------------------------------- */

/* End of Webpack Hot Extension Middleware  */

/* ----------------------------------------------- */ /******/ (function(
  modules
) {
  // webpackBootstrap
  /******/ // The module cache
  /******/ var installedModules = {}; // The require function
  /******/
  /******/ /******/ function __webpack_require__(moduleId) {
    /******/
    /******/ // Check if module is in cache
    /******/ if (installedModules[moduleId]) {
      /******/ return installedModules[moduleId].exports;
      /******/
    } // Create a new module (and put it into the cache)
    /******/ /******/ var module = (installedModules[moduleId] = {
      /******/ i: moduleId,
      /******/ l: false,
      /******/ exports: {}
      /******/
    }); // Execute the module function
    /******/
    /******/ /******/ modules[moduleId].call(
      module.exports,
      module,
      module.exports,
      __webpack_require__
    ); // Flag the module as loaded
    /******/
    /******/ /******/ module.l = true; // Return the exports of the module
    /******/
    /******/ /******/ return module.exports;
    /******/
  } // expose the modules object (__webpack_modules__)
  /******/
  /******/
  /******/ /******/ __webpack_require__.m = modules; // expose the module cache
  /******/
  /******/ /******/ __webpack_require__.c = installedModules; // define getter function for harmony exports
  /******/
  /******/ /******/ __webpack_require__.d = function(exports, name, getter) {
    /******/ if (!__webpack_require__.o(exports, name)) {
      /******/ Object.defineProperty(exports, name, {
        enumerable: true,
        get: getter
      });
      /******/
    }
    /******/
  }; // define __esModule on exports
  /******/
  /******/ /******/ __webpack_require__.r = function(exports) {
    /******/ if (typeof Symbol !== "undefined" && Symbol.toStringTag) {
      /******/ Object.defineProperty(exports, Symbol.toStringTag, {
        value: "Module"
      });
      /******/
    }
    /******/ Object.defineProperty(exports, "__esModule", { value: true });
    /******/
  }; // create a fake namespace object // mode & 1: value is a module id, require it // mode & 2: merge all properties of value into the ns // mode & 4: return value when already ns object // mode & 8|1: behave like require
  /******/
  /******/ /******/ /******/ /******/ /******/ /******/ __webpack_require__.t = function(
    value,
    mode
  ) {
    /******/ if (mode & 1) value = __webpack_require__(value);
    /******/ if (mode & 8) return value;
    /******/ if (
      mode & 4 &&
      typeof value === "object" &&
      value &&
      value.__esModule
    )
      return value;
    /******/ var ns = Object.create(null);
    /******/ __webpack_require__.r(ns);
    /******/ Object.defineProperty(ns, "default", {
      enumerable: true,
      value: value
    });
    /******/ if (mode & 2 && typeof value != "string")
      for (var key in value)
        __webpack_require__.d(
          ns,
          key,
          function(key) {
            return value[key];
          }.bind(null, key)
        );
    /******/ return ns;
    /******/
  }; // getDefaultExport function for compatibility with non-harmony modules
  /******/
  /******/ /******/ __webpack_require__.n = function(module) {
    /******/ var getter =
      module && module.__esModule
        ? /******/ function getDefault() {
            return module["default"];
          }
        : /******/ function getModuleExports() {
            return module;
          };
    /******/ __webpack_require__.d(getter, "a", getter);
    /******/ return getter;
    /******/
  }; // Object.prototype.hasOwnProperty.call
  /******/
  /******/ /******/ __webpack_require__.o = function(object, property) {
    return Object.prototype.hasOwnProperty.call(object, property);
  }; // __webpack_public_path__
  /******/
  /******/ /******/ __webpack_require__.p = ""; // Load entry module and return exports
  /******/
  /******/
  /******/ /******/ return __webpack_require__(
    (__webpack_require__.s = "./content.js")
  );
  /******/
})(
  /************************************************************************/
  /******/ {
    /***/ "../node_modules/secure-ls/dist/secure-ls.js":
      /*!***************************************************!*\
  !*** ../node_modules/secure-ls/dist/secure-ls.js ***!
  \***************************************************/
      /*! no static exports found */
      /***/ function(module, exports, __webpack_require__) {
        eval(
          "(function webpackUniversalModuleDefinition(root, factory) {\n\tif(true)\n\t\tmodule.exports = factory();\n\telse {}\n})(this, function() {\nreturn /******/ (function(modules) { // webpackBootstrap\n/******/ \t// The module cache\n/******/ \tvar installedModules = {};\n/******/\n/******/ \t// The require function\n/******/ \tfunction __webpack_require__(moduleId) {\n/******/\n/******/ \t\t// Check if module is in cache\n/******/ \t\tif(installedModules[moduleId])\n/******/ \t\t\treturn installedModules[moduleId].exports;\n/******/\n/******/ \t\t// Create a new module (and put it into the cache)\n/******/ \t\tvar module = installedModules[moduleId] = {\n/******/ \t\t\texports: {},\n/******/ \t\t\tid: moduleId,\n/******/ \t\t\tloaded: false\n/******/ \t\t};\n/******/\n/******/ \t\t// Execute the module function\n/******/ \t\tmodules[moduleId].call(module.exports, module, module.exports, __webpack_require__);\n/******/\n/******/ \t\t// Flag the module as loaded\n/******/ \t\tmodule.loaded = true;\n/******/\n/******/ \t\t// Return the exports of the module\n/******/ \t\treturn module.exports;\n/******/ \t}\n/******/\n/******/\n/******/ \t// expose the modules object (__webpack_modules__)\n/******/ \t__webpack_require__.m = modules;\n/******/\n/******/ \t// expose the module cache\n/******/ \t__webpack_require__.c = installedModules;\n/******/\n/******/ \t// __webpack_public_path__\n/******/ \t__webpack_require__.p = \"\";\n/******/\n/******/ \t// Load entry module and return exports\n/******/ \treturn __webpack_require__(0);\n/******/ })\n/************************************************************************/\n/******/ ([\n/* 0 */\n/***/ function(module, exports, __webpack_require__) {\n\n\t'use strict';\n\t\n\tObject.defineProperty(exports, \"__esModule\", {\n\t  value: true\n\t});\n\t\n\tvar _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if (\"value\" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();\n\t\n\tvar _utils = __webpack_require__(1);\n\t\n\tvar _utils2 = _interopRequireDefault(_utils);\n\t\n\tvar _constants = __webpack_require__(2);\n\t\n\tvar _constants2 = _interopRequireDefault(_constants);\n\t\n\tvar _encUtf = __webpack_require__(8);\n\t\n\tvar _encUtf2 = _interopRequireDefault(_encUtf);\n\t\n\tvar _Base = __webpack_require__(9);\n\t\n\tvar _Base2 = _interopRequireDefault(_Base);\n\t\n\tvar _lzString = __webpack_require__(10);\n\t\n\tvar _lzString2 = _interopRequireDefault(_lzString);\n\t\n\tvar _aes = __webpack_require__(11);\n\t\n\tvar _aes2 = _interopRequireDefault(_aes);\n\t\n\tvar _tripledes = __webpack_require__(16);\n\t\n\tvar _tripledes2 = _interopRequireDefault(_tripledes);\n\t\n\tvar _rabbit = __webpack_require__(17);\n\t\n\tvar _rabbit2 = _interopRequireDefault(_rabbit);\n\t\n\tvar _rc = __webpack_require__(18);\n\t\n\tvar _rc2 = _interopRequireDefault(_rc);\n\t\n\tfunction _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }\n\t\n\tfunction _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError(\"Cannot call a class as a function\"); } }\n\t\n\tvar SecureLS = function () {\n\t  function SecureLS(config) {\n\t    _classCallCheck(this, SecureLS);\n\t\n\t    config = config || {};\n\t    this._name = 'secure-ls';\n\t    this.utils = _utils2.default;\n\t    this.constants = _constants2.default;\n\t    this.Base64 = _Base2.default;\n\t    this.LZString = _lzString2.default;\n\t    this.AES = _aes2.default;\n\t    this.DES = _tripledes2.default;\n\t    this.RABBIT = _rabbit2.default;\n\t    this.RC4 = _rc2.default;\n\t    this.enc = _encUtf2.default;\n\t\n\t    this.config = {\n\t      isCompression: true,\n\t      encodingType: _constants2.default.EncrytionTypes.BASE64,\n\t      encryptionSecret: config.encryptionSecret,\n\t      encryptionNamespace: config.encryptionNamespace\n\t    };\n\t    this.config.isCompression = typeof config.isCompression !== 'undefined' ? config.isCompression : true;\n\t    this.config.encodingType = typeof config.encodingType !== 'undefined' || config.encodingType === '' ? config.encodingType.toLowerCase() : _constants2.default.EncrytionTypes.BASE64;\n\t\n\t    this.ls = localStorage;\n\t    this.init();\n\t  }\n\t\n\t  _createClass(SecureLS, [{\n\t    key: 'init',\n\t    value: function init() {\n\t      var metaData = this.getMetaData();\n\t\n\t      this.WarningEnum = this.constants.WarningEnum;\n\t      this.WarningTypes = this.constants.WarningTypes;\n\t      this.EncrytionTypes = this.constants.EncrytionTypes;\n\t\n\t      this._isBase64 = this._isBase64EncryptionType();\n\t      this._isAES = this._isAESEncryptionType();\n\t      this._isDES = this._isDESEncryptionType();\n\t      this._isRabbit = this._isRabbitEncryptionType();\n\t      this._isRC4 = this._isRC4EncryptionType();\n\t      this._isCompression = this._isDataCompressionEnabled();\n\t\n\t      // fill the already present keys to the list of keys being used by secure-ls\n\t      this.utils.allKeys = metaData.keys || this.resetAllKeys();\n\t    }\n\t  }, {\n\t    key: '_isBase64EncryptionType',\n\t    value: function _isBase64EncryptionType() {\n\t      return _Base2.default && (typeof this.config.encodingType === 'undefined' || this.config.encodingType === this.constants.EncrytionTypes.BASE64);\n\t    }\n\t  }, {\n\t    key: '_isAESEncryptionType',\n\t    value: function _isAESEncryptionType() {\n\t      return _aes2.default && this.config.encodingType === this.constants.EncrytionTypes.AES;\n\t    }\n\t  }, {\n\t    key: '_isDESEncryptionType',\n\t    value: function _isDESEncryptionType() {\n\t      return _tripledes2.default && this.config.encodingType === this.constants.EncrytionTypes.DES;\n\t    }\n\t  }, {\n\t    key: '_isRabbitEncryptionType',\n\t    value: function _isRabbitEncryptionType() {\n\t      return _rabbit2.default && this.config.encodingType === this.constants.EncrytionTypes.RABBIT;\n\t    }\n\t  }, {\n\t    key: '_isRC4EncryptionType',\n\t    value: function _isRC4EncryptionType() {\n\t      return _rc2.default && this.config.encodingType === this.constants.EncrytionTypes.RC4;\n\t    }\n\t  }, {\n\t    key: '_isDataCompressionEnabled',\n\t    value: function _isDataCompressionEnabled() {\n\t      return this.config.isCompression;\n\t    }\n\t  }, {\n\t    key: 'getEncryptionSecret',\n\t    value: function getEncryptionSecret(key) {\n\t      var metaData = this.getMetaData();\n\t      var obj = this.utils.getObjectFromKey(metaData.keys, key);\n\t\n\t      if (!obj) {\n\t        return;\n\t      }\n\t\n\t      if (this._isAES || this._isDES || this._isRabbit || this._isRC4) {\n\t        if (typeof this.config.encryptionSecret === 'undefined') {\n\t          this.utils.encryptionSecret = obj.s;\n\t\n\t          if (!this.utils.encryptionSecret) {\n\t            this.utils.encryptionSecret = this.utils.generateSecretKey();\n\t            this.setMetaData();\n\t          }\n\t        } else {\n\t          this.utils.encryptionSecret = this.config.encryptionSecret || obj.s || '';\n\t        }\n\t      }\n\t    }\n\t  }, {\n\t    key: 'get',\n\t    value: function get(key, isAllKeysData) {\n\t      var decodedData = '',\n\t          jsonData = '',\n\t          deCompressedData = void 0,\n\t          bytes = void 0,\n\t          data = void 0;\n\t\n\t      if (!this.utils.is(key)) {\n\t        this.utils.warn(this.WarningEnum.KEY_NOT_PROVIDED);\n\t        return jsonData;\n\t      }\n\t\n\t      data = this.getDataFromLocalStorage(key);\n\t\n\t      if (!data) {\n\t        return jsonData;\n\t      }\n\t\n\t      deCompressedData = data; // saves else\n\t      if (this._isCompression || isAllKeysData) {\n\t        // meta data always compressed\n\t        deCompressedData = _lzString2.default.decompressFromUTF16(data);\n\t      }\n\t\n\t      decodedData = deCompressedData; // saves else\n\t      if (this._isBase64 || isAllKeysData) {\n\t        // meta data always Base64\n\t        decodedData = _Base2.default.decode(deCompressedData);\n\t      } else {\n\t        this.getEncryptionSecret(key);\n\t        if (this._isAES) {\n\t          bytes = _aes2.default.decrypt(deCompressedData.toString(), this.utils.encryptionSecret);\n\t        } else if (this._isDES) {\n\t          bytes = _tripledes2.default.decrypt(deCompressedData.toString(), this.utils.encryptionSecret);\n\t        } else if (this._isRabbit) {\n\t          bytes = _rabbit2.default.decrypt(deCompressedData.toString(), this.utils.encryptionSecret);\n\t        } else if (this._isRC4) {\n\t          bytes = _rc2.default.decrypt(deCompressedData.toString(), this.utils.encryptionSecret);\n\t        }\n\t\n\t        if (bytes) {\n\t          decodedData = bytes.toString(_encUtf2.default._Utf8);\n\t        }\n\t      }\n\t\n\t      try {\n\t        jsonData = JSON.parse(decodedData);\n\t      } catch (e) {\n\t        throw new Error('Could not parse JSON');\n\t      }\n\t\n\t      return jsonData;\n\t    }\n\t  }, {\n\t    key: 'getDataFromLocalStorage',\n\t    value: function getDataFromLocalStorage(key) {\n\t      return this.ls.getItem(key, true);\n\t    }\n\t  }, {\n\t    key: 'getAllKeys',\n\t    value: function getAllKeys() {\n\t      var data = this.getMetaData();\n\t\n\t      return this.utils.extractKeyNames(data) || [];\n\t    }\n\t  }, {\n\t    key: 'set',\n\t    value: function set(key, data) {\n\t      var dataToStore = '';\n\t\n\t      if (!this.utils.is(key)) {\n\t        this.utils.warn(this.WarningEnum.KEY_NOT_PROVIDED);\n\t        return;\n\t      }\n\t\n\t      this.getEncryptionSecret(key);\n\t\n\t      // add key(s) to Array if not already added, only for keys other than meta key\n\t      if (!(String(key) === String(this.utils.metaKey))) {\n\t        if (!this.utils.isKeyPresent(key)) {\n\t          this.utils.addToKeysList(key);\n\t          this.setMetaData();\n\t        }\n\t      }\n\t\n\t      dataToStore = this.processData(data);\n\t      // Store the data to localStorage\n\t      this.setDataToLocalStorage(key, dataToStore);\n\t    }\n\t  }, {\n\t    key: 'setDataToLocalStorage',\n\t    value: function setDataToLocalStorage(key, data) {\n\t      this.ls.setItem(key, data);\n\t    }\n\t  }, {\n\t    key: 'remove',\n\t    value: function remove(key) {\n\t      if (!this.utils.is(key)) {\n\t        this.utils.warn(this.WarningEnum.KEY_NOT_PROVIDED);\n\t        return;\n\t      }\n\t\n\t      if (key === this.utils.metaKey && this.getAllKeys().length) {\n\t        this.utils.warn(this.WarningEnum.META_KEY_REMOVE);\n\t        return;\n\t      }\n\t\n\t      if (this.utils.isKeyPresent(key)) {\n\t        this.utils.removeFromKeysList(key);\n\t        this.setMetaData();\n\t      }\n\t      this.ls.removeItem(key);\n\t    }\n\t  }, {\n\t    key: 'removeAll',\n\t    value: function removeAll() {\n\t      var keys = void 0,\n\t          i = void 0;\n\t\n\t      keys = this.getAllKeys();\n\t      for (i = 0; i < keys.length; i++) {\n\t        this.ls.removeItem(keys[i]);\n\t      }\n\t      this.ls.removeItem(this.utils.metaKey);\n\t\n\t      this.resetAllKeys();\n\t    }\n\t  }, {\n\t    key: 'clear',\n\t    value: function clear() {\n\t      this.ls.clear();\n\t      this.resetAllKeys();\n\t    }\n\t  }, {\n\t    key: 'resetAllKeys',\n\t    value: function resetAllKeys() {\n\t      this.utils.allKeys = [];\n\t      return [];\n\t    }\n\t  }, {\n\t    key: 'processData',\n\t    value: function processData(data, isAllKeysData) {\n\t      if (data === null || data === undefined || data === '') {\n\t        return '';\n\t      }\n\t\n\t      var jsonData = void 0,\n\t          encodedData = void 0,\n\t          compressedData = void 0;\n\t\n\t      try {\n\t        jsonData = JSON.stringify(data);\n\t      } catch (e) {\n\t        throw new Error('Could not stringify data.');\n\t      }\n\t\n\t      // Encode Based on encoding type\n\t      // If not set, default to Base64 for securing data\n\t      encodedData = jsonData;\n\t      if (this._isBase64 || isAllKeysData) {\n\t        encodedData = _Base2.default.encode(jsonData);\n\t      } else {\n\t        if (this._isAES) {\n\t          encodedData = _aes2.default.encrypt(jsonData, this.utils.encryptionSecret);\n\t        } else if (this._isDES) {\n\t          encodedData = _tripledes2.default.encrypt(jsonData, this.utils.encryptionSecret);\n\t        } else if (this._isRabbit) {\n\t          encodedData = _rabbit2.default.encrypt(jsonData, this.utils.encryptionSecret);\n\t        } else if (this._isRC4) {\n\t          encodedData = _rc2.default.encrypt(jsonData, this.utils.encryptionSecret);\n\t        }\n\t\n\t        encodedData = encodedData && encodedData.toString();\n\t      }\n\t\n\t      // Compress data if set to true\n\t      compressedData = encodedData;\n\t      if (this._isCompression || isAllKeysData) {\n\t        compressedData = _lzString2.default.compressToUTF16(encodedData);\n\t      }\n\t\n\t      return compressedData;\n\t    }\n\t  }, {\n\t    key: 'setMetaData',\n\t    value: function setMetaData() {\n\t      var dataToStore = this.processData({\n\t        keys: this.utils.allKeys\n\t      }, true);\n\t\n\t      // Store the data to localStorage\n\t      this.setDataToLocalStorage(this.getMetaKey(), dataToStore);\n\t    }\n\t  }, {\n\t    key: 'getMetaData',\n\t    value: function getMetaData() {\n\t      return this.get(this.getMetaKey(), true) || {};\n\t    }\n\t  }, {\n\t    key: 'getMetaKey',\n\t    value: function getMetaKey() {\n\t      return this.utils.metaKey + (this.config.encryptionNamespace ? '__' + this.config.encryptionNamespace : '');\n\t    }\n\t  }]);\n\t\n\t  return SecureLS;\n\t}();\n\t\n\texports.default = SecureLS;\n\t;\n\tmodule.exports = exports['default'];\n\n/***/ },\n/* 1 */\n/***/ function(module, exports, __webpack_require__) {\n\n\t'use strict';\n\t\n\tvar _constants = __webpack_require__(2);\n\t\n\tvar _constants2 = _interopRequireDefault(_constants);\n\t\n\tvar _WordArray = __webpack_require__(3);\n\t\n\tvar _WordArray2 = _interopRequireDefault(_WordArray);\n\t\n\tvar _pbkdf = __webpack_require__(4);\n\t\n\tvar _pbkdf2 = _interopRequireDefault(_pbkdf);\n\t\n\tfunction _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }\n\t\n\tvar utils = {\n\t  metaKey: '_secure__ls__metadata',\n\t  encryptionSecret: '',\n\t  secretPhrase: 's3cr3t$#@135^&*246',\n\t  allKeys: [],\n\t  is: function is(key) {\n\t    if (key) {\n\t      return true;\n\t    }\n\t    return false;\n\t  },\n\t  warn: function warn(reason) {\n\t    reason = reason ? reason : _constants2.default.WarningEnum.DEFAULT_TEXT;\n\t    console.warn(_constants2.default.WarningTypes[reason]);\n\t  },\n\t  generateSecretKey: function generateSecretKey() {\n\t    var salt = _WordArray2.default.random(128 / 8);\n\t    var key128Bits = (0, _pbkdf2.default)(this.secretPhrase, salt, { keySize: 128 / 32 });\n\t\n\t    return key128Bits && key128Bits.toString();\n\t  },\n\t  getObjectFromKey: function getObjectFromKey(data, key) {\n\t    if (!data || !data.length) {\n\t      return {};\n\t    }\n\t\n\t    var i = void 0,\n\t        obj = {};\n\t\n\t    for (i = 0; i < data.length; i++) {\n\t      if (data[i].k === key) {\n\t        obj = data[i];\n\t        break;\n\t      }\n\t    }\n\t\n\t    return obj;\n\t  },\n\t  extractKeyNames: function extractKeyNames(data) {\n\t    if (!data || !data.keys || !data.keys.length) {\n\t      return [];\n\t    }\n\t\n\t    return data.keys.map(function (keyData) {\n\t      return keyData.k;\n\t    });\n\t  },\n\t  getAllKeys: function getAllKeys() {\n\t    return this.allKeys;\n\t  },\n\t  isKeyPresent: function isKeyPresent(key) {\n\t    var isKeyAlreadyPresent = false;\n\t\n\t    for (var i = 0; i < this.allKeys.length; i++) {\n\t      if (String(this.allKeys[i].k) === String(key)) {\n\t        isKeyAlreadyPresent = true; // found\n\t        break;\n\t      }\n\t    }\n\t\n\t    return isKeyAlreadyPresent;\n\t  },\n\t  addToKeysList: function addToKeysList(key) {\n\t    this.allKeys.push({\n\t      k: key,\n\t      s: this.encryptionSecret\n\t    });\n\t  },\n\t  removeFromKeysList: function removeFromKeysList(key) {\n\t    var i = void 0,\n\t        index = -1;\n\t\n\t    for (i = 0; i < this.allKeys.length; i++) {\n\t      if (this.allKeys[i].k === key) {\n\t        index = i;\n\t        break;\n\t      }\n\t    }\n\t    if (index !== -1) {\n\t      this.allKeys.splice(index, 1);\n\t    }\n\t    return index;\n\t  }\n\t};\n\t\n\tmodule.exports = utils;\n\n/***/ },\n/* 2 */\n/***/ function(module, exports) {\n\n\t'use strict';\n\t\n\tvar WarningEnum = {\n\t  KEY_NOT_PROVIDED: 'keyNotProvided',\n\t  META_KEY_REMOVE: 'metaKeyRemove',\n\t  DEFAULT_TEXT: 'defaultText'\n\t};\n\t\n\tvar WarningTypes = {};\n\t\n\tWarningTypes[WarningEnum.KEY_NOT_PROVIDED] = 'Secure LS: Key not provided. Aborting operation!';\n\tWarningTypes[WarningEnum.META_KEY_REMOVE] = 'Secure LS: Meta key can not be removed\\nunless all keys created by Secure LS are removed!';\n\tWarningTypes[WarningEnum.DEFAULT_TEXT] = 'Unexpected output';\n\t\n\tvar constants = {\n\t  WarningEnum: WarningEnum,\n\t  WarningTypes: WarningTypes,\n\t  EncrytionTypes: {\n\t    BASE64: 'base64',\n\t    AES: 'aes',\n\t    DES: 'des',\n\t    RABBIT: 'rabbit',\n\t    RC4: 'rc4'\n\t  }\n\t};\n\t\n\tmodule.exports = constants;\n\n/***/ },\n/* 3 */\n/***/ function(module, exports) {\n\n\t\"use strict\";\n\t\n\t/*\n\t ES6 compatible port of CryptoJS - WordArray for PBKDF2 password key generation\n\t\n\t Source: https://github.com/brix/crypto-js\n\t LICENSE: MIT\n\t */\n\t\n\tvar CryptoJSWordArray = {};\n\t\n\tCryptoJSWordArray.random = function (nBytes) {\n\t  var words = [];\n\t  var r = function r(mw) {\n\t    var mz = 0x3ade68b1;\n\t    var mask = 0xffffffff;\n\t\n\t    return function () {\n\t      mz = 0x9069 * (mz & 0xFFFF) + (mz >> 0x10) & mask;\n\t      mw = 0x4650 * (mw & 0xFFFF) + (mw >> 0x10) & mask;\n\t      var result = (mz << 0x10) + mw & mask;\n\t\n\t      result /= 0x100000000;\n\t      result += 0.5;\n\t      return result * (Math.random() > 0.5 ? 1 : -1);\n\t    };\n\t  };\n\t\n\t  for (var i = 0, rcache; i < nBytes; i += 4) {\n\t    var _r = r((rcache || Math.random()) * 0x100000000);\n\t\n\t    rcache = _r() * 0x3ade67b7;\n\t    words.push(_r() * 0x100000000 | 0);\n\t  }\n\t\n\t  return new this.Set(words, nBytes);\n\t};\n\t\n\tCryptoJSWordArray.Set = function (words, sigBytes) {\n\t  words = this.words = words || [];\n\t\n\t  if (sigBytes !== undefined) {\n\t    this.sigBytes = sigBytes;\n\t  } else {\n\t    this.sigBytes = words.length * 8;\n\t  }\n\t};\n\t\n\tmodule.exports = CryptoJSWordArray;\n\n/***/ },\n/* 4 */\n/***/ function(module, exports, __webpack_require__) {\n\n\t;(function (root, factory, undef) {\n\t\tif (true) {\n\t\t\t// CommonJS\n\t\t\tmodule.exports = exports = factory(__webpack_require__(5), __webpack_require__(6), __webpack_require__(7));\n\t\t}\n\t\telse {}\n\t}(this, function (CryptoJS) {\n\t\n\t\t(function () {\n\t\t    // Shortcuts\n\t\t    var C = CryptoJS;\n\t\t    var C_lib = C.lib;\n\t\t    var Base = C_lib.Base;\n\t\t    var WordArray = C_lib.WordArray;\n\t\t    var C_algo = C.algo;\n\t\t    var SHA1 = C_algo.SHA1;\n\t\t    var HMAC = C_algo.HMAC;\n\t\n\t\t    /**\n\t\t     * Password-Based Key Derivation Function 2 algorithm.\n\t\t     */\n\t\t    var PBKDF2 = C_algo.PBKDF2 = Base.extend({\n\t\t        /**\n\t\t         * Configuration options.\n\t\t         *\n\t\t         * @property {number} keySize The key size in words to generate. Default: 4 (128 bits)\n\t\t         * @property {Hasher} hasher The hasher to use. Default: SHA1\n\t\t         * @property {number} iterations The number of iterations to perform. Default: 1\n\t\t         */\n\t\t        cfg: Base.extend({\n\t\t            keySize: 128/32,\n\t\t            hasher: SHA1,\n\t\t            iterations: 1\n\t\t        }),\n\t\n\t\t        /**\n\t\t         * Initializes a newly created key derivation function.\n\t\t         *\n\t\t         * @param {Object} cfg (Optional) The configuration options to use for the derivation.\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var kdf = CryptoJS.algo.PBKDF2.create();\n\t\t         *     var kdf = CryptoJS.algo.PBKDF2.create({ keySize: 8 });\n\t\t         *     var kdf = CryptoJS.algo.PBKDF2.create({ keySize: 8, iterations: 1000 });\n\t\t         */\n\t\t        init: function (cfg) {\n\t\t            this.cfg = this.cfg.extend(cfg);\n\t\t        },\n\t\n\t\t        /**\n\t\t         * Computes the Password-Based Key Derivation Function 2.\n\t\t         *\n\t\t         * @param {WordArray|string} password The password.\n\t\t         * @param {WordArray|string} salt A salt.\n\t\t         *\n\t\t         * @return {WordArray} The derived key.\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var key = kdf.compute(password, salt);\n\t\t         */\n\t\t        compute: function (password, salt) {\n\t\t            // Shortcut\n\t\t            var cfg = this.cfg;\n\t\n\t\t            // Init HMAC\n\t\t            var hmac = HMAC.create(cfg.hasher, password);\n\t\n\t\t            // Initial values\n\t\t            var derivedKey = WordArray.create();\n\t\t            var blockIndex = WordArray.create([0x00000001]);\n\t\n\t\t            // Shortcuts\n\t\t            var derivedKeyWords = derivedKey.words;\n\t\t            var blockIndexWords = blockIndex.words;\n\t\t            var keySize = cfg.keySize;\n\t\t            var iterations = cfg.iterations;\n\t\n\t\t            // Generate key\n\t\t            while (derivedKeyWords.length < keySize) {\n\t\t                var block = hmac.update(salt).finalize(blockIndex);\n\t\t                hmac.reset();\n\t\n\t\t                // Shortcuts\n\t\t                var blockWords = block.words;\n\t\t                var blockWordsLength = blockWords.length;\n\t\n\t\t                // Iterations\n\t\t                var intermediate = block;\n\t\t                for (var i = 1; i < iterations; i++) {\n\t\t                    intermediate = hmac.finalize(intermediate);\n\t\t                    hmac.reset();\n\t\n\t\t                    // Shortcut\n\t\t                    var intermediateWords = intermediate.words;\n\t\n\t\t                    // XOR intermediate with block\n\t\t                    for (var j = 0; j < blockWordsLength; j++) {\n\t\t                        blockWords[j] ^= intermediateWords[j];\n\t\t                    }\n\t\t                }\n\t\n\t\t                derivedKey.concat(block);\n\t\t                blockIndexWords[0]++;\n\t\t            }\n\t\t            derivedKey.sigBytes = keySize * 4;\n\t\n\t\t            return derivedKey;\n\t\t        }\n\t\t    });\n\t\n\t\t    /**\n\t\t     * Computes the Password-Based Key Derivation Function 2.\n\t\t     *\n\t\t     * @param {WordArray|string} password The password.\n\t\t     * @param {WordArray|string} salt A salt.\n\t\t     * @param {Object} cfg (Optional) The configuration options to use for this computation.\n\t\t     *\n\t\t     * @return {WordArray} The derived key.\n\t\t     *\n\t\t     * @static\n\t\t     *\n\t\t     * @example\n\t\t     *\n\t\t     *     var key = CryptoJS.PBKDF2(password, salt);\n\t\t     *     var key = CryptoJS.PBKDF2(password, salt, { keySize: 8 });\n\t\t     *     var key = CryptoJS.PBKDF2(password, salt, { keySize: 8, iterations: 1000 });\n\t\t     */\n\t\t    C.PBKDF2 = function (password, salt, cfg) {\n\t\t        return PBKDF2.create(cfg).compute(password, salt);\n\t\t    };\n\t\t}());\n\t\n\t\n\t\treturn CryptoJS.PBKDF2;\n\t\n\t}));\n\n/***/ },\n/* 5 */\n/***/ function(module, exports, __webpack_require__) {\n\n\t;(function (root, factory) {\n\t\tif (true) {\n\t\t\t// CommonJS\n\t\t\tmodule.exports = exports = factory();\n\t\t}\n\t\telse {}\n\t}(this, function () {\n\t\n\t\t/**\n\t\t * CryptoJS core components.\n\t\t */\n\t\tvar CryptoJS = CryptoJS || (function (Math, undefined) {\n\t\t    /*\n\t\t     * Local polyfil of Object.create\n\t\t     */\n\t\t    var create = Object.create || (function () {\n\t\t        function F() {};\n\t\n\t\t        return function (obj) {\n\t\t            var subtype;\n\t\n\t\t            F.prototype = obj;\n\t\n\t\t            subtype = new F();\n\t\n\t\t            F.prototype = null;\n\t\n\t\t            return subtype;\n\t\t        };\n\t\t    }())\n\t\n\t\t    /**\n\t\t     * CryptoJS namespace.\n\t\t     */\n\t\t    var C = {};\n\t\n\t\t    /**\n\t\t     * Library namespace.\n\t\t     */\n\t\t    var C_lib = C.lib = {};\n\t\n\t\t    /**\n\t\t     * Base object for prototypal inheritance.\n\t\t     */\n\t\t    var Base = C_lib.Base = (function () {\n\t\n\t\n\t\t        return {\n\t\t            /**\n\t\t             * Creates a new object that inherits from this object.\n\t\t             *\n\t\t             * @param {Object} overrides Properties to copy into the new object.\n\t\t             *\n\t\t             * @return {Object} The new object.\n\t\t             *\n\t\t             * @static\n\t\t             *\n\t\t             * @example\n\t\t             *\n\t\t             *     var MyType = CryptoJS.lib.Base.extend({\n\t\t             *         field: 'value',\n\t\t             *\n\t\t             *         method: function () {\n\t\t             *         }\n\t\t             *     });\n\t\t             */\n\t\t            extend: function (overrides) {\n\t\t                // Spawn\n\t\t                var subtype = create(this);\n\t\n\t\t                // Augment\n\t\t                if (overrides) {\n\t\t                    subtype.mixIn(overrides);\n\t\t                }\n\t\n\t\t                // Create default initializer\n\t\t                if (!subtype.hasOwnProperty('init') || this.init === subtype.init) {\n\t\t                    subtype.init = function () {\n\t\t                        subtype.$super.init.apply(this, arguments);\n\t\t                    };\n\t\t                }\n\t\n\t\t                // Initializer's prototype is the subtype object\n\t\t                subtype.init.prototype = subtype;\n\t\n\t\t                // Reference supertype\n\t\t                subtype.$super = this;\n\t\n\t\t                return subtype;\n\t\t            },\n\t\n\t\t            /**\n\t\t             * Extends this object and runs the init method.\n\t\t             * Arguments to create() will be passed to init().\n\t\t             *\n\t\t             * @return {Object} The new object.\n\t\t             *\n\t\t             * @static\n\t\t             *\n\t\t             * @example\n\t\t             *\n\t\t             *     var instance = MyType.create();\n\t\t             */\n\t\t            create: function () {\n\t\t                var instance = this.extend();\n\t\t                instance.init.apply(instance, arguments);\n\t\n\t\t                return instance;\n\t\t            },\n\t\n\t\t            /**\n\t\t             * Initializes a newly created object.\n\t\t             * Override this method to add some logic when your objects are created.\n\t\t             *\n\t\t             * @example\n\t\t             *\n\t\t             *     var MyType = CryptoJS.lib.Base.extend({\n\t\t             *         init: function () {\n\t\t             *             // ...\n\t\t             *         }\n\t\t             *     });\n\t\t             */\n\t\t            init: function () {\n\t\t            },\n\t\n\t\t            /**\n\t\t             * Copies properties into this object.\n\t\t             *\n\t\t             * @param {Object} properties The properties to mix in.\n\t\t             *\n\t\t             * @example\n\t\t             *\n\t\t             *     MyType.mixIn({\n\t\t             *         field: 'value'\n\t\t             *     });\n\t\t             */\n\t\t            mixIn: function (properties) {\n\t\t                for (var propertyName in properties) {\n\t\t                    if (properties.hasOwnProperty(propertyName)) {\n\t\t                        this[propertyName] = properties[propertyName];\n\t\t                    }\n\t\t                }\n\t\n\t\t                // IE won't copy toString using the loop above\n\t\t                if (properties.hasOwnProperty('toString')) {\n\t\t                    this.toString = properties.toString;\n\t\t                }\n\t\t            },\n\t\n\t\t            /**\n\t\t             * Creates a copy of this object.\n\t\t             *\n\t\t             * @return {Object} The clone.\n\t\t             *\n\t\t             * @example\n\t\t             *\n\t\t             *     var clone = instance.clone();\n\t\t             */\n\t\t            clone: function () {\n\t\t                return this.init.prototype.extend(this);\n\t\t            }\n\t\t        };\n\t\t    }());\n\t\n\t\t    /**\n\t\t     * An array of 32-bit words.\n\t\t     *\n\t\t     * @property {Array} words The array of 32-bit words.\n\t\t     * @property {number} sigBytes The number of significant bytes in this word array.\n\t\t     */\n\t\t    var WordArray = C_lib.WordArray = Base.extend({\n\t\t        /**\n\t\t         * Initializes a newly created word array.\n\t\t         *\n\t\t         * @param {Array} words (Optional) An array of 32-bit words.\n\t\t         * @param {number} sigBytes (Optional) The number of significant bytes in the words.\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var wordArray = CryptoJS.lib.WordArray.create();\n\t\t         *     var wordArray = CryptoJS.lib.WordArray.create([0x00010203, 0x04050607]);\n\t\t         *     var wordArray = CryptoJS.lib.WordArray.create([0x00010203, 0x04050607], 6);\n\t\t         */\n\t\t        init: function (words, sigBytes) {\n\t\t            words = this.words = words || [];\n\t\n\t\t            if (sigBytes != undefined) {\n\t\t                this.sigBytes = sigBytes;\n\t\t            } else {\n\t\t                this.sigBytes = words.length * 4;\n\t\t            }\n\t\t        },\n\t\n\t\t        /**\n\t\t         * Converts this word array to a string.\n\t\t         *\n\t\t         * @param {Encoder} encoder (Optional) The encoding strategy to use. Default: CryptoJS.enc.Hex\n\t\t         *\n\t\t         * @return {string} The stringified word array.\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var string = wordArray + '';\n\t\t         *     var string = wordArray.toString();\n\t\t         *     var string = wordArray.toString(CryptoJS.enc.Utf8);\n\t\t         */\n\t\t        toString: function (encoder) {\n\t\t            return (encoder || Hex).stringify(this);\n\t\t        },\n\t\n\t\t        /**\n\t\t         * Concatenates a word array to this word array.\n\t\t         *\n\t\t         * @param {WordArray} wordArray The word array to append.\n\t\t         *\n\t\t         * @return {WordArray} This word array.\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     wordArray1.concat(wordArray2);\n\t\t         */\n\t\t        concat: function (wordArray) {\n\t\t            // Shortcuts\n\t\t            var thisWords = this.words;\n\t\t            var thatWords = wordArray.words;\n\t\t            var thisSigBytes = this.sigBytes;\n\t\t            var thatSigBytes = wordArray.sigBytes;\n\t\n\t\t            // Clamp excess bits\n\t\t            this.clamp();\n\t\n\t\t            // Concat\n\t\t            if (thisSigBytes % 4) {\n\t\t                // Copy one byte at a time\n\t\t                for (var i = 0; i < thatSigBytes; i++) {\n\t\t                    var thatByte = (thatWords[i >>> 2] >>> (24 - (i % 4) * 8)) & 0xff;\n\t\t                    thisWords[(thisSigBytes + i) >>> 2] |= thatByte << (24 - ((thisSigBytes + i) % 4) * 8);\n\t\t                }\n\t\t            } else {\n\t\t                // Copy one word at a time\n\t\t                for (var i = 0; i < thatSigBytes; i += 4) {\n\t\t                    thisWords[(thisSigBytes + i) >>> 2] = thatWords[i >>> 2];\n\t\t                }\n\t\t            }\n\t\t            this.sigBytes += thatSigBytes;\n\t\n\t\t            // Chainable\n\t\t            return this;\n\t\t        },\n\t\n\t\t        /**\n\t\t         * Removes insignificant bits.\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     wordArray.clamp();\n\t\t         */\n\t\t        clamp: function () {\n\t\t            // Shortcuts\n\t\t            var words = this.words;\n\t\t            var sigBytes = this.sigBytes;\n\t\n\t\t            // Clamp\n\t\t            words[sigBytes >>> 2] &= 0xffffffff << (32 - (sigBytes % 4) * 8);\n\t\t            words.length = Math.ceil(sigBytes / 4);\n\t\t        },\n\t\n\t\t        /**\n\t\t         * Creates a copy of this word array.\n\t\t         *\n\t\t         * @return {WordArray} The clone.\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var clone = wordArray.clone();\n\t\t         */\n\t\t        clone: function () {\n\t\t            var clone = Base.clone.call(this);\n\t\t            clone.words = this.words.slice(0);\n\t\n\t\t            return clone;\n\t\t        },\n\t\n\t\t        /**\n\t\t         * Creates a word array filled with random bytes.\n\t\t         *\n\t\t         * @param {number} nBytes The number of random bytes to generate.\n\t\t         *\n\t\t         * @return {WordArray} The random word array.\n\t\t         *\n\t\t         * @static\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var wordArray = CryptoJS.lib.WordArray.random(16);\n\t\t         */\n\t\t        random: function (nBytes) {\n\t\t            var words = [];\n\t\n\t\t            var r = (function (m_w) {\n\t\t                var m_w = m_w;\n\t\t                var m_z = 0x3ade68b1;\n\t\t                var mask = 0xffffffff;\n\t\n\t\t                return function () {\n\t\t                    m_z = (0x9069 * (m_z & 0xFFFF) + (m_z >> 0x10)) & mask;\n\t\t                    m_w = (0x4650 * (m_w & 0xFFFF) + (m_w >> 0x10)) & mask;\n\t\t                    var result = ((m_z << 0x10) + m_w) & mask;\n\t\t                    result /= 0x100000000;\n\t\t                    result += 0.5;\n\t\t                    return result * (Math.random() > .5 ? 1 : -1);\n\t\t                }\n\t\t            });\n\t\n\t\t            for (var i = 0, rcache; i < nBytes; i += 4) {\n\t\t                var _r = r((rcache || Math.random()) * 0x100000000);\n\t\n\t\t                rcache = _r() * 0x3ade67b7;\n\t\t                words.push((_r() * 0x100000000) | 0);\n\t\t            }\n\t\n\t\t            return new WordArray.init(words, nBytes);\n\t\t        }\n\t\t    });\n\t\n\t\t    /**\n\t\t     * Encoder namespace.\n\t\t     */\n\t\t    var C_enc = C.enc = {};\n\t\n\t\t    /**\n\t\t     * Hex encoding strategy.\n\t\t     */\n\t\t    var Hex = C_enc.Hex = {\n\t\t        /**\n\t\t         * Converts a word array to a hex string.\n\t\t         *\n\t\t         * @param {WordArray} wordArray The word array.\n\t\t         *\n\t\t         * @return {string} The hex string.\n\t\t         *\n\t\t         * @static\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var hexString = CryptoJS.enc.Hex.stringify(wordArray);\n\t\t         */\n\t\t        stringify: function (wordArray) {\n\t\t            // Shortcuts\n\t\t            var words = wordArray.words;\n\t\t            var sigBytes = wordArray.sigBytes;\n\t\n\t\t            // Convert\n\t\t            var hexChars = [];\n\t\t            for (var i = 0; i < sigBytes; i++) {\n\t\t                var bite = (words[i >>> 2] >>> (24 - (i % 4) * 8)) & 0xff;\n\t\t                hexChars.push((bite >>> 4).toString(16));\n\t\t                hexChars.push((bite & 0x0f).toString(16));\n\t\t            }\n\t\n\t\t            return hexChars.join('');\n\t\t        },\n\t\n\t\t        /**\n\t\t         * Converts a hex string to a word array.\n\t\t         *\n\t\t         * @param {string} hexStr The hex string.\n\t\t         *\n\t\t         * @return {WordArray} The word array.\n\t\t         *\n\t\t         * @static\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var wordArray = CryptoJS.enc.Hex.parse(hexString);\n\t\t         */\n\t\t        parse: function (hexStr) {\n\t\t            // Shortcut\n\t\t            var hexStrLength = hexStr.length;\n\t\n\t\t            // Convert\n\t\t            var words = [];\n\t\t            for (var i = 0; i < hexStrLength; i += 2) {\n\t\t                words[i >>> 3] |= parseInt(hexStr.substr(i, 2), 16) << (24 - (i % 8) * 4);\n\t\t            }\n\t\n\t\t            return new WordArray.init(words, hexStrLength / 2);\n\t\t        }\n\t\t    };\n\t\n\t\t    /**\n\t\t     * Latin1 encoding strategy.\n\t\t     */\n\t\t    var Latin1 = C_enc.Latin1 = {\n\t\t        /**\n\t\t         * Converts a word array to a Latin1 string.\n\t\t         *\n\t\t         * @param {WordArray} wordArray The word array.\n\t\t         *\n\t\t         * @return {string} The Latin1 string.\n\t\t         *\n\t\t         * @static\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var latin1String = CryptoJS.enc.Latin1.stringify(wordArray);\n\t\t         */\n\t\t        stringify: function (wordArray) {\n\t\t            // Shortcuts\n\t\t            var words = wordArray.words;\n\t\t            var sigBytes = wordArray.sigBytes;\n\t\n\t\t            // Convert\n\t\t            var latin1Chars = [];\n\t\t            for (var i = 0; i < sigBytes; i++) {\n\t\t                var bite = (words[i >>> 2] >>> (24 - (i % 4) * 8)) & 0xff;\n\t\t                latin1Chars.push(String.fromCharCode(bite));\n\t\t            }\n\t\n\t\t            return latin1Chars.join('');\n\t\t        },\n\t\n\t\t        /**\n\t\t         * Converts a Latin1 string to a word array.\n\t\t         *\n\t\t         * @param {string} latin1Str The Latin1 string.\n\t\t         *\n\t\t         * @return {WordArray} The word array.\n\t\t         *\n\t\t         * @static\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var wordArray = CryptoJS.enc.Latin1.parse(latin1String);\n\t\t         */\n\t\t        parse: function (latin1Str) {\n\t\t            // Shortcut\n\t\t            var latin1StrLength = latin1Str.length;\n\t\n\t\t            // Convert\n\t\t            var words = [];\n\t\t            for (var i = 0; i < latin1StrLength; i++) {\n\t\t                words[i >>> 2] |= (latin1Str.charCodeAt(i) & 0xff) << (24 - (i % 4) * 8);\n\t\t            }\n\t\n\t\t            return new WordArray.init(words, latin1StrLength);\n\t\t        }\n\t\t    };\n\t\n\t\t    /**\n\t\t     * UTF-8 encoding strategy.\n\t\t     */\n\t\t    var Utf8 = C_enc.Utf8 = {\n\t\t        /**\n\t\t         * Converts a word array to a UTF-8 string.\n\t\t         *\n\t\t         * @param {WordArray} wordArray The word array.\n\t\t         *\n\t\t         * @return {string} The UTF-8 string.\n\t\t         *\n\t\t         * @static\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var utf8String = CryptoJS.enc.Utf8.stringify(wordArray);\n\t\t         */\n\t\t        stringify: function (wordArray) {\n\t\t            try {\n\t\t                return decodeURIComponent(escape(Latin1.stringify(wordArray)));\n\t\t            } catch (e) {\n\t\t                throw new Error('Malformed UTF-8 data');\n\t\t            }\n\t\t        },\n\t\n\t\t        /**\n\t\t         * Converts a UTF-8 string to a word array.\n\t\t         *\n\t\t         * @param {string} utf8Str The UTF-8 string.\n\t\t         *\n\t\t         * @return {WordArray} The word array.\n\t\t         *\n\t\t         * @static\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var wordArray = CryptoJS.enc.Utf8.parse(utf8String);\n\t\t         */\n\t\t        parse: function (utf8Str) {\n\t\t            return Latin1.parse(unescape(encodeURIComponent(utf8Str)));\n\t\t        }\n\t\t    };\n\t\n\t\t    /**\n\t\t     * Abstract buffered block algorithm template.\n\t\t     *\n\t\t     * The property blockSize must be implemented in a concrete subtype.\n\t\t     *\n\t\t     * @property {number} _minBufferSize The number of blocks that should be kept unprocessed in the buffer. Default: 0\n\t\t     */\n\t\t    var BufferedBlockAlgorithm = C_lib.BufferedBlockAlgorithm = Base.extend({\n\t\t        /**\n\t\t         * Resets this block algorithm's data buffer to its initial state.\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     bufferedBlockAlgorithm.reset();\n\t\t         */\n\t\t        reset: function () {\n\t\t            // Initial values\n\t\t            this._data = new WordArray.init();\n\t\t            this._nDataBytes = 0;\n\t\t        },\n\t\n\t\t        /**\n\t\t         * Adds new data to this block algorithm's buffer.\n\t\t         *\n\t\t         * @param {WordArray|string} data The data to append. Strings are converted to a WordArray using UTF-8.\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     bufferedBlockAlgorithm._append('data');\n\t\t         *     bufferedBlockAlgorithm._append(wordArray);\n\t\t         */\n\t\t        _append: function (data) {\n\t\t            // Convert string to WordArray, else assume WordArray already\n\t\t            if (typeof data == 'string') {\n\t\t                data = Utf8.parse(data);\n\t\t            }\n\t\n\t\t            // Append\n\t\t            this._data.concat(data);\n\t\t            this._nDataBytes += data.sigBytes;\n\t\t        },\n\t\n\t\t        /**\n\t\t         * Processes available data blocks.\n\t\t         *\n\t\t         * This method invokes _doProcessBlock(offset), which must be implemented by a concrete subtype.\n\t\t         *\n\t\t         * @param {boolean} doFlush Whether all blocks and partial blocks should be processed.\n\t\t         *\n\t\t         * @return {WordArray} The processed data.\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var processedData = bufferedBlockAlgorithm._process();\n\t\t         *     var processedData = bufferedBlockAlgorithm._process(!!'flush');\n\t\t         */\n\t\t        _process: function (doFlush) {\n\t\t            // Shortcuts\n\t\t            var data = this._data;\n\t\t            var dataWords = data.words;\n\t\t            var dataSigBytes = data.sigBytes;\n\t\t            var blockSize = this.blockSize;\n\t\t            var blockSizeBytes = blockSize * 4;\n\t\n\t\t            // Count blocks ready\n\t\t            var nBlocksReady = dataSigBytes / blockSizeBytes;\n\t\t            if (doFlush) {\n\t\t                // Round up to include partial blocks\n\t\t                nBlocksReady = Math.ceil(nBlocksReady);\n\t\t            } else {\n\t\t                // Round down to include only full blocks,\n\t\t                // less the number of blocks that must remain in the buffer\n\t\t                nBlocksReady = Math.max((nBlocksReady | 0) - this._minBufferSize, 0);\n\t\t            }\n\t\n\t\t            // Count words ready\n\t\t            var nWordsReady = nBlocksReady * blockSize;\n\t\n\t\t            // Count bytes ready\n\t\t            var nBytesReady = Math.min(nWordsReady * 4, dataSigBytes);\n\t\n\t\t            // Process blocks\n\t\t            if (nWordsReady) {\n\t\t                for (var offset = 0; offset < nWordsReady; offset += blockSize) {\n\t\t                    // Perform concrete-algorithm logic\n\t\t                    this._doProcessBlock(dataWords, offset);\n\t\t                }\n\t\n\t\t                // Remove processed words\n\t\t                var processedWords = dataWords.splice(0, nWordsReady);\n\t\t                data.sigBytes -= nBytesReady;\n\t\t            }\n\t\n\t\t            // Return processed words\n\t\t            return new WordArray.init(processedWords, nBytesReady);\n\t\t        },\n\t\n\t\t        /**\n\t\t         * Creates a copy of this object.\n\t\t         *\n\t\t         * @return {Object} The clone.\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var clone = bufferedBlockAlgorithm.clone();\n\t\t         */\n\t\t        clone: function () {\n\t\t            var clone = Base.clone.call(this);\n\t\t            clone._data = this._data.clone();\n\t\n\t\t            return clone;\n\t\t        },\n\t\n\t\t        _minBufferSize: 0\n\t\t    });\n\t\n\t\t    /**\n\t\t     * Abstract hasher template.\n\t\t     *\n\t\t     * @property {number} blockSize The number of 32-bit words this hasher operates on. Default: 16 (512 bits)\n\t\t     */\n\t\t    var Hasher = C_lib.Hasher = BufferedBlockAlgorithm.extend({\n\t\t        /**\n\t\t         * Configuration options.\n\t\t         */\n\t\t        cfg: Base.extend(),\n\t\n\t\t        /**\n\t\t         * Initializes a newly created hasher.\n\t\t         *\n\t\t         * @param {Object} cfg (Optional) The configuration options to use for this hash computation.\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var hasher = CryptoJS.algo.SHA256.create();\n\t\t         */\n\t\t        init: function (cfg) {\n\t\t            // Apply config defaults\n\t\t            this.cfg = this.cfg.extend(cfg);\n\t\n\t\t            // Set initial values\n\t\t            this.reset();\n\t\t        },\n\t\n\t\t        /**\n\t\t         * Resets this hasher to its initial state.\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     hasher.reset();\n\t\t         */\n\t\t        reset: function () {\n\t\t            // Reset data buffer\n\t\t            BufferedBlockAlgorithm.reset.call(this);\n\t\n\t\t            // Perform concrete-hasher logic\n\t\t            this._doReset();\n\t\t        },\n\t\n\t\t        /**\n\t\t         * Updates this hasher with a message.\n\t\t         *\n\t\t         * @param {WordArray|string} messageUpdate The message to append.\n\t\t         *\n\t\t         * @return {Hasher} This hasher.\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     hasher.update('message');\n\t\t         *     hasher.update(wordArray);\n\t\t         */\n\t\t        update: function (messageUpdate) {\n\t\t            // Append\n\t\t            this._append(messageUpdate);\n\t\n\t\t            // Update the hash\n\t\t            this._process();\n\t\n\t\t            // Chainable\n\t\t            return this;\n\t\t        },\n\t\n\t\t        /**\n\t\t         * Finalizes the hash computation.\n\t\t         * Note that the finalize operation is effectively a destructive, read-once operation.\n\t\t         *\n\t\t         * @param {WordArray|string} messageUpdate (Optional) A final message update.\n\t\t         *\n\t\t         * @return {WordArray} The hash.\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var hash = hasher.finalize();\n\t\t         *     var hash = hasher.finalize('message');\n\t\t         *     var hash = hasher.finalize(wordArray);\n\t\t         */\n\t\t        finalize: function (messageUpdate) {\n\t\t            // Final message update\n\t\t            if (messageUpdate) {\n\t\t                this._append(messageUpdate);\n\t\t            }\n\t\n\t\t            // Perform concrete-hasher logic\n\t\t            var hash = this._doFinalize();\n\t\n\t\t            return hash;\n\t\t        },\n\t\n\t\t        blockSize: 512/32,\n\t\n\t\t        /**\n\t\t         * Creates a shortcut function to a hasher's object interface.\n\t\t         *\n\t\t         * @param {Hasher} hasher The hasher to create a helper for.\n\t\t         *\n\t\t         * @return {Function} The shortcut function.\n\t\t         *\n\t\t         * @static\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var SHA256 = CryptoJS.lib.Hasher._createHelper(CryptoJS.algo.SHA256);\n\t\t         */\n\t\t        _createHelper: function (hasher) {\n\t\t            return function (message, cfg) {\n\t\t                return new hasher.init(cfg).finalize(message);\n\t\t            };\n\t\t        },\n\t\n\t\t        /**\n\t\t         * Creates a shortcut function to the HMAC's object interface.\n\t\t         *\n\t\t         * @param {Hasher} hasher The hasher to use in this HMAC helper.\n\t\t         *\n\t\t         * @return {Function} The shortcut function.\n\t\t         *\n\t\t         * @static\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var HmacSHA256 = CryptoJS.lib.Hasher._createHmacHelper(CryptoJS.algo.SHA256);\n\t\t         */\n\t\t        _createHmacHelper: function (hasher) {\n\t\t            return function (message, key) {\n\t\t                return new C_algo.HMAC.init(hasher, key).finalize(message);\n\t\t            };\n\t\t        }\n\t\t    });\n\t\n\t\t    /**\n\t\t     * Algorithm namespace.\n\t\t     */\n\t\t    var C_algo = C.algo = {};\n\t\n\t\t    return C;\n\t\t}(Math));\n\t\n\t\n\t\treturn CryptoJS;\n\t\n\t}));\n\n/***/ },\n/* 6 */\n/***/ function(module, exports, __webpack_require__) {\n\n\t;(function (root, factory) {\n\t\tif (true) {\n\t\t\t// CommonJS\n\t\t\tmodule.exports = exports = factory(__webpack_require__(5));\n\t\t}\n\t\telse {}\n\t}(this, function (CryptoJS) {\n\t\n\t\t(function () {\n\t\t    // Shortcuts\n\t\t    var C = CryptoJS;\n\t\t    var C_lib = C.lib;\n\t\t    var WordArray = C_lib.WordArray;\n\t\t    var Hasher = C_lib.Hasher;\n\t\t    var C_algo = C.algo;\n\t\n\t\t    // Reusable object\n\t\t    var W = [];\n\t\n\t\t    /**\n\t\t     * SHA-1 hash algorithm.\n\t\t     */\n\t\t    var SHA1 = C_algo.SHA1 = Hasher.extend({\n\t\t        _doReset: function () {\n\t\t            this._hash = new WordArray.init([\n\t\t                0x67452301, 0xefcdab89,\n\t\t                0x98badcfe, 0x10325476,\n\t\t                0xc3d2e1f0\n\t\t            ]);\n\t\t        },\n\t\n\t\t        _doProcessBlock: function (M, offset) {\n\t\t            // Shortcut\n\t\t            var H = this._hash.words;\n\t\n\t\t            // Working variables\n\t\t            var a = H[0];\n\t\t            var b = H[1];\n\t\t            var c = H[2];\n\t\t            var d = H[3];\n\t\t            var e = H[4];\n\t\n\t\t            // Computation\n\t\t            for (var i = 0; i < 80; i++) {\n\t\t                if (i < 16) {\n\t\t                    W[i] = M[offset + i] | 0;\n\t\t                } else {\n\t\t                    var n = W[i - 3] ^ W[i - 8] ^ W[i - 14] ^ W[i - 16];\n\t\t                    W[i] = (n << 1) | (n >>> 31);\n\t\t                }\n\t\n\t\t                var t = ((a << 5) | (a >>> 27)) + e + W[i];\n\t\t                if (i < 20) {\n\t\t                    t += ((b & c) | (~b & d)) + 0x5a827999;\n\t\t                } else if (i < 40) {\n\t\t                    t += (b ^ c ^ d) + 0x6ed9eba1;\n\t\t                } else if (i < 60) {\n\t\t                    t += ((b & c) | (b & d) | (c & d)) - 0x70e44324;\n\t\t                } else /* if (i < 80) */ {\n\t\t                    t += (b ^ c ^ d) - 0x359d3e2a;\n\t\t                }\n\t\n\t\t                e = d;\n\t\t                d = c;\n\t\t                c = (b << 30) | (b >>> 2);\n\t\t                b = a;\n\t\t                a = t;\n\t\t            }\n\t\n\t\t            // Intermediate hash value\n\t\t            H[0] = (H[0] + a) | 0;\n\t\t            H[1] = (H[1] + b) | 0;\n\t\t            H[2] = (H[2] + c) | 0;\n\t\t            H[3] = (H[3] + d) | 0;\n\t\t            H[4] = (H[4] + e) | 0;\n\t\t        },\n\t\n\t\t        _doFinalize: function () {\n\t\t            // Shortcuts\n\t\t            var data = this._data;\n\t\t            var dataWords = data.words;\n\t\n\t\t            var nBitsTotal = this._nDataBytes * 8;\n\t\t            var nBitsLeft = data.sigBytes * 8;\n\t\n\t\t            // Add padding\n\t\t            dataWords[nBitsLeft >>> 5] |= 0x80 << (24 - nBitsLeft % 32);\n\t\t            dataWords[(((nBitsLeft + 64) >>> 9) << 4) + 14] = Math.floor(nBitsTotal / 0x100000000);\n\t\t            dataWords[(((nBitsLeft + 64) >>> 9) << 4) + 15] = nBitsTotal;\n\t\t            data.sigBytes = dataWords.length * 4;\n\t\n\t\t            // Hash final blocks\n\t\t            this._process();\n\t\n\t\t            // Return final computed hash\n\t\t            return this._hash;\n\t\t        },\n\t\n\t\t        clone: function () {\n\t\t            var clone = Hasher.clone.call(this);\n\t\t            clone._hash = this._hash.clone();\n\t\n\t\t            return clone;\n\t\t        }\n\t\t    });\n\t\n\t\t    /**\n\t\t     * Shortcut function to the hasher's object interface.\n\t\t     *\n\t\t     * @param {WordArray|string} message The message to hash.\n\t\t     *\n\t\t     * @return {WordArray} The hash.\n\t\t     *\n\t\t     * @static\n\t\t     *\n\t\t     * @example\n\t\t     *\n\t\t     *     var hash = CryptoJS.SHA1('message');\n\t\t     *     var hash = CryptoJS.SHA1(wordArray);\n\t\t     */\n\t\t    C.SHA1 = Hasher._createHelper(SHA1);\n\t\n\t\t    /**\n\t\t     * Shortcut function to the HMAC's object interface.\n\t\t     *\n\t\t     * @param {WordArray|string} message The message to hash.\n\t\t     * @param {WordArray|string} key The secret key.\n\t\t     *\n\t\t     * @return {WordArray} The HMAC.\n\t\t     *\n\t\t     * @static\n\t\t     *\n\t\t     * @example\n\t\t     *\n\t\t     *     var hmac = CryptoJS.HmacSHA1(message, key);\n\t\t     */\n\t\t    C.HmacSHA1 = Hasher._createHmacHelper(SHA1);\n\t\t}());\n\t\n\t\n\t\treturn CryptoJS.SHA1;\n\t\n\t}));\n\n/***/ },\n/* 7 */\n/***/ function(module, exports, __webpack_require__) {\n\n\t;(function (root, factory) {\n\t\tif (true) {\n\t\t\t// CommonJS\n\t\t\tmodule.exports = exports = factory(__webpack_require__(5));\n\t\t}\n\t\telse {}\n\t}(this, function (CryptoJS) {\n\t\n\t\t(function () {\n\t\t    // Shortcuts\n\t\t    var C = CryptoJS;\n\t\t    var C_lib = C.lib;\n\t\t    var Base = C_lib.Base;\n\t\t    var C_enc = C.enc;\n\t\t    var Utf8 = C_enc.Utf8;\n\t\t    var C_algo = C.algo;\n\t\n\t\t    /**\n\t\t     * HMAC algorithm.\n\t\t     */\n\t\t    var HMAC = C_algo.HMAC = Base.extend({\n\t\t        /**\n\t\t         * Initializes a newly created HMAC.\n\t\t         *\n\t\t         * @param {Hasher} hasher The hash algorithm to use.\n\t\t         * @param {WordArray|string} key The secret key.\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var hmacHasher = CryptoJS.algo.HMAC.create(CryptoJS.algo.SHA256, key);\n\t\t         */\n\t\t        init: function (hasher, key) {\n\t\t            // Init hasher\n\t\t            hasher = this._hasher = new hasher.init();\n\t\n\t\t            // Convert string to WordArray, else assume WordArray already\n\t\t            if (typeof key == 'string') {\n\t\t                key = Utf8.parse(key);\n\t\t            }\n\t\n\t\t            // Shortcuts\n\t\t            var hasherBlockSize = hasher.blockSize;\n\t\t            var hasherBlockSizeBytes = hasherBlockSize * 4;\n\t\n\t\t            // Allow arbitrary length keys\n\t\t            if (key.sigBytes > hasherBlockSizeBytes) {\n\t\t                key = hasher.finalize(key);\n\t\t            }\n\t\n\t\t            // Clamp excess bits\n\t\t            key.clamp();\n\t\n\t\t            // Clone key for inner and outer pads\n\t\t            var oKey = this._oKey = key.clone();\n\t\t            var iKey = this._iKey = key.clone();\n\t\n\t\t            // Shortcuts\n\t\t            var oKeyWords = oKey.words;\n\t\t            var iKeyWords = iKey.words;\n\t\n\t\t            // XOR keys with pad constants\n\t\t            for (var i = 0; i < hasherBlockSize; i++) {\n\t\t                oKeyWords[i] ^= 0x5c5c5c5c;\n\t\t                iKeyWords[i] ^= 0x36363636;\n\t\t            }\n\t\t            oKey.sigBytes = iKey.sigBytes = hasherBlockSizeBytes;\n\t\n\t\t            // Set initial values\n\t\t            this.reset();\n\t\t        },\n\t\n\t\t        /**\n\t\t         * Resets this HMAC to its initial state.\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     hmacHasher.reset();\n\t\t         */\n\t\t        reset: function () {\n\t\t            // Shortcut\n\t\t            var hasher = this._hasher;\n\t\n\t\t            // Reset\n\t\t            hasher.reset();\n\t\t            hasher.update(this._iKey);\n\t\t        },\n\t\n\t\t        /**\n\t\t         * Updates this HMAC with a message.\n\t\t         *\n\t\t         * @param {WordArray|string} messageUpdate The message to append.\n\t\t         *\n\t\t         * @return {HMAC} This HMAC instance.\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     hmacHasher.update('message');\n\t\t         *     hmacHasher.update(wordArray);\n\t\t         */\n\t\t        update: function (messageUpdate) {\n\t\t            this._hasher.update(messageUpdate);\n\t\n\t\t            // Chainable\n\t\t            return this;\n\t\t        },\n\t\n\t\t        /**\n\t\t         * Finalizes the HMAC computation.\n\t\t         * Note that the finalize operation is effectively a destructive, read-once operation.\n\t\t         *\n\t\t         * @param {WordArray|string} messageUpdate (Optional) A final message update.\n\t\t         *\n\t\t         * @return {WordArray} The HMAC.\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var hmac = hmacHasher.finalize();\n\t\t         *     var hmac = hmacHasher.finalize('message');\n\t\t         *     var hmac = hmacHasher.finalize(wordArray);\n\t\t         */\n\t\t        finalize: function (messageUpdate) {\n\t\t            // Shortcut\n\t\t            var hasher = this._hasher;\n\t\n\t\t            // Compute HMAC\n\t\t            var innerHash = hasher.finalize(messageUpdate);\n\t\t            hasher.reset();\n\t\t            var hmac = hasher.finalize(this._oKey.clone().concat(innerHash));\n\t\n\t\t            return hmac;\n\t\t        }\n\t\t    });\n\t\t}());\n\t\n\t\n\t}));\n\n/***/ },\n/* 8 */\n/***/ function(module, exports) {\n\n\t'use strict';\n\t\n\t/*\n\t ES6 compatible port of CryptoJS - encoding\n\t\n\t Source: https://github.com/brix/crypto-js\n\t LICENSE: MIT\n\t */\n\tvar enc = {};\n\t\n\tenc.Latin1 = {\n\t  stringify: function stringify(wordArray) {\n\t    // Shortcuts\n\t    var words = wordArray.words;\n\t    var sigBytes = wordArray.sigBytes;\n\t    var latin1Chars = [],\n\t        i = void 0,\n\t        bite = void 0;\n\t\n\t    // Convert\n\t    for (i = 0; i < sigBytes; i++) {\n\t      bite = words[i >>> 2] >>> 24 - i % 4 * 8 & 0xff;\n\t      latin1Chars.push(String.fromCharCode(bite));\n\t    }\n\t\n\t    return latin1Chars.join('');\n\t  }\n\t};\n\t\n\tenc._Utf8 = {\n\t  stringify: function stringify(wordArray) {\n\t    try {\n\t      return decodeURIComponent(escape(enc.Latin1.stringify(wordArray)));\n\t    } catch (e) {\n\t      throw new Error('Malformed UTF-8 data');\n\t    }\n\t  }\n\t};\n\t\n\tmodule.exports = enc;\n\n/***/ },\n/* 9 */\n/***/ function(module, exports) {\n\n\t'use strict';\n\t\n\tvar Base64 = {\n\t  _keyStr: 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=',\n\t  encode: function encode(e) {\n\t    var t = '';\n\t    var n = void 0,\n\t        r = void 0,\n\t        i = void 0,\n\t        s = void 0,\n\t        o = void 0,\n\t        u = void 0,\n\t        a = void 0;\n\t    var f = 0;\n\t\n\t    e = Base64._utf8Encode(e);\n\t    while (f < e.length) {\n\t      n = e.charCodeAt(f++);\n\t      r = e.charCodeAt(f++);\n\t      i = e.charCodeAt(f++);\n\t      s = n >> 2;\n\t      o = (n & 3) << 4 | r >> 4;\n\t      u = (r & 15) << 2 | i >> 6;\n\t      a = i & 63;\n\t      if (isNaN(r)) {\n\t        u = a = 64;\n\t      } else if (isNaN(i)) {\n\t        a = 64;\n\t      }\n\t      t = t + this._keyStr.charAt(s) + this._keyStr.charAt(o) + this._keyStr.charAt(u) + this._keyStr.charAt(a);\n\t    }\n\t    return t;\n\t  },\n\t  decode: function decode(e) {\n\t    var t = '';\n\t    var n = void 0,\n\t        r = void 0,\n\t        i = void 0;\n\t    var s = void 0,\n\t        o = void 0,\n\t        u = void 0,\n\t        a = void 0;\n\t    var f = 0;\n\t\n\t    e = e.replace(/[^A-Za-z0-9\\+\\/\\=]/g, '');\n\t    while (f < e.length) {\n\t      s = this._keyStr.indexOf(e.charAt(f++));\n\t      o = this._keyStr.indexOf(e.charAt(f++));\n\t      u = this._keyStr.indexOf(e.charAt(f++));\n\t      a = this._keyStr.indexOf(e.charAt(f++));\n\t      n = s << 2 | o >> 4;\n\t      r = (o & 15) << 4 | u >> 2;\n\t      i = (u & 3) << 6 | a;\n\t      t = t + String.fromCharCode(n);\n\t      if (u !== 64) {\n\t        t = t + String.fromCharCode(r);\n\t      }\n\t      if (a !== 64) {\n\t        t = t + String.fromCharCode(i);\n\t      }\n\t    }\n\t    t = Base64._utf8Decode(t);\n\t    return t;\n\t  },\n\t  _utf8Encode: function _utf8Encode(e) {\n\t    e = e.replace(/\\r\\n/g, '\\n');\n\t    var t = '';\n\t\n\t    for (var n = 0; n < e.length; n++) {\n\t      var r = e.charCodeAt(n);\n\t\n\t      if (r < 128) {\n\t        t += String.fromCharCode(r);\n\t      } else if (r > 127 && r < 2048) {\n\t        t += String.fromCharCode(r >> 6 | 192);\n\t        t += String.fromCharCode(r & 63 | 128);\n\t      } else {\n\t        t += String.fromCharCode(r >> 12 | 224);\n\t        t += String.fromCharCode(r >> 6 & 63 | 128);\n\t        t += String.fromCharCode(r & 63 | 128);\n\t      }\n\t    }\n\t    return t;\n\t  },\n\t  _utf8Decode: function _utf8Decode(e) {\n\t    var t = '';\n\t    var n = 0;\n\t    var r = void 0,\n\t        c2 = void 0,\n\t        c3 = void 0;\n\t\n\t    r = c2 = 0;\n\t    while (n < e.length) {\n\t      r = e.charCodeAt(n);\n\t      if (r < 128) {\n\t        t += String.fromCharCode(r);\n\t        n++;\n\t      } else if (r > 191 && r < 224) {\n\t        c2 = e.charCodeAt(n + 1);\n\t        t += String.fromCharCode((r & 31) << 6 | c2 & 63);\n\t        n += 2;\n\t      } else {\n\t        c2 = e.charCodeAt(n + 1);\n\t        c3 = e.charCodeAt(n + 2);\n\t        t += String.fromCharCode((r & 15) << 12 | (c2 & 63) << 6 | c3 & 63);\n\t        n += 3;\n\t      }\n\t    }\n\t    return t;\n\t  }\n\t};\n\t\n\tmodule.exports = Base64;\n\n/***/ },\n/* 10 */\n/***/ function(module, exports, __webpack_require__) {\n\n\tvar __WEBPACK_AMD_DEFINE_RESULT__;// Copyright (c) 2013 Pieroxy <pieroxy@pieroxy.net>\n\t// This work is free. You can redistribute it and/or modify it\n\t// under the terms of the WTFPL, Version 2\n\t// For more information see LICENSE.txt or http://www.wtfpl.net/\n\t//\n\t// For more information, the home page:\n\t// http://pieroxy.net/blog/pages/lz-string/testing.html\n\t//\n\t// LZ-based compression algorithm, version 1.4.4\n\tvar LZString = (function() {\n\t\n\t// private property\n\tvar f = String.fromCharCode;\n\tvar keyStrBase64 = \"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=\";\n\tvar keyStrUriSafe = \"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+-$\";\n\tvar baseReverseDic = {};\n\t\n\tfunction getBaseValue(alphabet, character) {\n\t  if (!baseReverseDic[alphabet]) {\n\t    baseReverseDic[alphabet] = {};\n\t    for (var i=0 ; i<alphabet.length ; i++) {\n\t      baseReverseDic[alphabet][alphabet.charAt(i)] = i;\n\t    }\n\t  }\n\t  return baseReverseDic[alphabet][character];\n\t}\n\t\n\tvar LZString = {\n\t  compressToBase64 : function (input) {\n\t    if (input == null) return \"\";\n\t    var res = LZString._compress(input, 6, function(a){return keyStrBase64.charAt(a);});\n\t    switch (res.length % 4) { // To produce valid Base64\n\t    default: // When could this happen ?\n\t    case 0 : return res;\n\t    case 1 : return res+\"===\";\n\t    case 2 : return res+\"==\";\n\t    case 3 : return res+\"=\";\n\t    }\n\t  },\n\t\n\t  decompressFromBase64 : function (input) {\n\t    if (input == null) return \"\";\n\t    if (input == \"\") return null;\n\t    return LZString._decompress(input.length, 32, function(index) { return getBaseValue(keyStrBase64, input.charAt(index)); });\n\t  },\n\t\n\t  compressToUTF16 : function (input) {\n\t    if (input == null) return \"\";\n\t    return LZString._compress(input, 15, function(a){return f(a+32);}) + \" \";\n\t  },\n\t\n\t  decompressFromUTF16: function (compressed) {\n\t    if (compressed == null) return \"\";\n\t    if (compressed == \"\") return null;\n\t    return LZString._decompress(compressed.length, 16384, function(index) { return compressed.charCodeAt(index) - 32; });\n\t  },\n\t\n\t  //compress into uint8array (UCS-2 big endian format)\n\t  compressToUint8Array: function (uncompressed) {\n\t    var compressed = LZString.compress(uncompressed);\n\t    var buf=new Uint8Array(compressed.length*2); // 2 bytes per character\n\t\n\t    for (var i=0, TotalLen=compressed.length; i<TotalLen; i++) {\n\t      var current_value = compressed.charCodeAt(i);\n\t      buf[i*2] = current_value >>> 8;\n\t      buf[i*2+1] = current_value % 256;\n\t    }\n\t    return buf;\n\t  },\n\t\n\t  //decompress from uint8array (UCS-2 big endian format)\n\t  decompressFromUint8Array:function (compressed) {\n\t    if (compressed===null || compressed===undefined){\n\t        return LZString.decompress(compressed);\n\t    } else {\n\t        var buf=new Array(compressed.length/2); // 2 bytes per character\n\t        for (var i=0, TotalLen=buf.length; i<TotalLen; i++) {\n\t          buf[i]=compressed[i*2]*256+compressed[i*2+1];\n\t        }\n\t\n\t        var result = [];\n\t        buf.forEach(function (c) {\n\t          result.push(f(c));\n\t        });\n\t        return LZString.decompress(result.join(''));\n\t\n\t    }\n\t\n\t  },\n\t\n\t\n\t  //compress into a string that is already URI encoded\n\t  compressToEncodedURIComponent: function (input) {\n\t    if (input == null) return \"\";\n\t    return LZString._compress(input, 6, function(a){return keyStrUriSafe.charAt(a);});\n\t  },\n\t\n\t  //decompress from an output of compressToEncodedURIComponent\n\t  decompressFromEncodedURIComponent:function (input) {\n\t    if (input == null) return \"\";\n\t    if (input == \"\") return null;\n\t    input = input.replace(/ /g, \"+\");\n\t    return LZString._decompress(input.length, 32, function(index) { return getBaseValue(keyStrUriSafe, input.charAt(index)); });\n\t  },\n\t\n\t  compress: function (uncompressed) {\n\t    return LZString._compress(uncompressed, 16, function(a){return f(a);});\n\t  },\n\t  _compress: function (uncompressed, bitsPerChar, getCharFromInt) {\n\t    if (uncompressed == null) return \"\";\n\t    var i, value,\n\t        context_dictionary= {},\n\t        context_dictionaryToCreate= {},\n\t        context_c=\"\",\n\t        context_wc=\"\",\n\t        context_w=\"\",\n\t        context_enlargeIn= 2, // Compensate for the first entry which should not count\n\t        context_dictSize= 3,\n\t        context_numBits= 2,\n\t        context_data=[],\n\t        context_data_val=0,\n\t        context_data_position=0,\n\t        ii;\n\t\n\t    for (ii = 0; ii < uncompressed.length; ii += 1) {\n\t      context_c = uncompressed.charAt(ii);\n\t      if (!Object.prototype.hasOwnProperty.call(context_dictionary,context_c)) {\n\t        context_dictionary[context_c] = context_dictSize++;\n\t        context_dictionaryToCreate[context_c] = true;\n\t      }\n\t\n\t      context_wc = context_w + context_c;\n\t      if (Object.prototype.hasOwnProperty.call(context_dictionary,context_wc)) {\n\t        context_w = context_wc;\n\t      } else {\n\t        if (Object.prototype.hasOwnProperty.call(context_dictionaryToCreate,context_w)) {\n\t          if (context_w.charCodeAt(0)<256) {\n\t            for (i=0 ; i<context_numBits ; i++) {\n\t              context_data_val = (context_data_val << 1);\n\t              if (context_data_position == bitsPerChar-1) {\n\t                context_data_position = 0;\n\t                context_data.push(getCharFromInt(context_data_val));\n\t                context_data_val = 0;\n\t              } else {\n\t                context_data_position++;\n\t              }\n\t            }\n\t            value = context_w.charCodeAt(0);\n\t            for (i=0 ; i<8 ; i++) {\n\t              context_data_val = (context_data_val << 1) | (value&1);\n\t              if (context_data_position == bitsPerChar-1) {\n\t                context_data_position = 0;\n\t                context_data.push(getCharFromInt(context_data_val));\n\t                context_data_val = 0;\n\t              } else {\n\t                context_data_position++;\n\t              }\n\t              value = value >> 1;\n\t            }\n\t          } else {\n\t            value = 1;\n\t            for (i=0 ; i<context_numBits ; i++) {\n\t              context_data_val = (context_data_val << 1) | value;\n\t              if (context_data_position ==bitsPerChar-1) {\n\t                context_data_position = 0;\n\t                context_data.push(getCharFromInt(context_data_val));\n\t                context_data_val = 0;\n\t              } else {\n\t                context_data_position++;\n\t              }\n\t              value = 0;\n\t            }\n\t            value = context_w.charCodeAt(0);\n\t            for (i=0 ; i<16 ; i++) {\n\t              context_data_val = (context_data_val << 1) | (value&1);\n\t              if (context_data_position == bitsPerChar-1) {\n\t                context_data_position = 0;\n\t                context_data.push(getCharFromInt(context_data_val));\n\t                context_data_val = 0;\n\t              } else {\n\t                context_data_position++;\n\t              }\n\t              value = value >> 1;\n\t            }\n\t          }\n\t          context_enlargeIn--;\n\t          if (context_enlargeIn == 0) {\n\t            context_enlargeIn = Math.pow(2, context_numBits);\n\t            context_numBits++;\n\t          }\n\t          delete context_dictionaryToCreate[context_w];\n\t        } else {\n\t          value = context_dictionary[context_w];\n\t          for (i=0 ; i<context_numBits ; i++) {\n\t            context_data_val = (context_data_val << 1) | (value&1);\n\t            if (context_data_position == bitsPerChar-1) {\n\t              context_data_position = 0;\n\t              context_data.push(getCharFromInt(context_data_val));\n\t              context_data_val = 0;\n\t            } else {\n\t              context_data_position++;\n\t            }\n\t            value = value >> 1;\n\t          }\n\t\n\t\n\t        }\n\t        context_enlargeIn--;\n\t        if (context_enlargeIn == 0) {\n\t          context_enlargeIn = Math.pow(2, context_numBits);\n\t          context_numBits++;\n\t        }\n\t        // Add wc to the dictionary.\n\t        context_dictionary[context_wc] = context_dictSize++;\n\t        context_w = String(context_c);\n\t      }\n\t    }\n\t\n\t    // Output the code for w.\n\t    if (context_w !== \"\") {\n\t      if (Object.prototype.hasOwnProperty.call(context_dictionaryToCreate,context_w)) {\n\t        if (context_w.charCodeAt(0)<256) {\n\t          for (i=0 ; i<context_numBits ; i++) {\n\t            context_data_val = (context_data_val << 1);\n\t            if (context_data_position == bitsPerChar-1) {\n\t              context_data_position = 0;\n\t              context_data.push(getCharFromInt(context_data_val));\n\t              context_data_val = 0;\n\t            } else {\n\t              context_data_position++;\n\t            }\n\t          }\n\t          value = context_w.charCodeAt(0);\n\t          for (i=0 ; i<8 ; i++) {\n\t            context_data_val = (context_data_val << 1) | (value&1);\n\t            if (context_data_position == bitsPerChar-1) {\n\t              context_data_position = 0;\n\t              context_data.push(getCharFromInt(context_data_val));\n\t              context_data_val = 0;\n\t            } else {\n\t              context_data_position++;\n\t            }\n\t            value = value >> 1;\n\t          }\n\t        } else {\n\t          value = 1;\n\t          for (i=0 ; i<context_numBits ; i++) {\n\t            context_data_val = (context_data_val << 1) | value;\n\t            if (context_data_position == bitsPerChar-1) {\n\t              context_data_position = 0;\n\t              context_data.push(getCharFromInt(context_data_val));\n\t              context_data_val = 0;\n\t            } else {\n\t              context_data_position++;\n\t            }\n\t            value = 0;\n\t          }\n\t          value = context_w.charCodeAt(0);\n\t          for (i=0 ; i<16 ; i++) {\n\t            context_data_val = (context_data_val << 1) | (value&1);\n\t            if (context_data_position == bitsPerChar-1) {\n\t              context_data_position = 0;\n\t              context_data.push(getCharFromInt(context_data_val));\n\t              context_data_val = 0;\n\t            } else {\n\t              context_data_position++;\n\t            }\n\t            value = value >> 1;\n\t          }\n\t        }\n\t        context_enlargeIn--;\n\t        if (context_enlargeIn == 0) {\n\t          context_enlargeIn = Math.pow(2, context_numBits);\n\t          context_numBits++;\n\t        }\n\t        delete context_dictionaryToCreate[context_w];\n\t      } else {\n\t        value = context_dictionary[context_w];\n\t        for (i=0 ; i<context_numBits ; i++) {\n\t          context_data_val = (context_data_val << 1) | (value&1);\n\t          if (context_data_position == bitsPerChar-1) {\n\t            context_data_position = 0;\n\t            context_data.push(getCharFromInt(context_data_val));\n\t            context_data_val = 0;\n\t          } else {\n\t            context_data_position++;\n\t          }\n\t          value = value >> 1;\n\t        }\n\t\n\t\n\t      }\n\t      context_enlargeIn--;\n\t      if (context_enlargeIn == 0) {\n\t        context_enlargeIn = Math.pow(2, context_numBits);\n\t        context_numBits++;\n\t      }\n\t    }\n\t\n\t    // Mark the end of the stream\n\t    value = 2;\n\t    for (i=0 ; i<context_numBits ; i++) {\n\t      context_data_val = (context_data_val << 1) | (value&1);\n\t      if (context_data_position == bitsPerChar-1) {\n\t        context_data_position = 0;\n\t        context_data.push(getCharFromInt(context_data_val));\n\t        context_data_val = 0;\n\t      } else {\n\t        context_data_position++;\n\t      }\n\t      value = value >> 1;\n\t    }\n\t\n\t    // Flush the last char\n\t    while (true) {\n\t      context_data_val = (context_data_val << 1);\n\t      if (context_data_position == bitsPerChar-1) {\n\t        context_data.push(getCharFromInt(context_data_val));\n\t        break;\n\t      }\n\t      else context_data_position++;\n\t    }\n\t    return context_data.join('');\n\t  },\n\t\n\t  decompress: function (compressed) {\n\t    if (compressed == null) return \"\";\n\t    if (compressed == \"\") return null;\n\t    return LZString._decompress(compressed.length, 32768, function(index) { return compressed.charCodeAt(index); });\n\t  },\n\t\n\t  _decompress: function (length, resetValue, getNextValue) {\n\t    var dictionary = [],\n\t        next,\n\t        enlargeIn = 4,\n\t        dictSize = 4,\n\t        numBits = 3,\n\t        entry = \"\",\n\t        result = [],\n\t        i,\n\t        w,\n\t        bits, resb, maxpower, power,\n\t        c,\n\t        data = {val:getNextValue(0), position:resetValue, index:1};\n\t\n\t    for (i = 0; i < 3; i += 1) {\n\t      dictionary[i] = i;\n\t    }\n\t\n\t    bits = 0;\n\t    maxpower = Math.pow(2,2);\n\t    power=1;\n\t    while (power!=maxpower) {\n\t      resb = data.val & data.position;\n\t      data.position >>= 1;\n\t      if (data.position == 0) {\n\t        data.position = resetValue;\n\t        data.val = getNextValue(data.index++);\n\t      }\n\t      bits |= (resb>0 ? 1 : 0) * power;\n\t      power <<= 1;\n\t    }\n\t\n\t    switch (next = bits) {\n\t      case 0:\n\t          bits = 0;\n\t          maxpower = Math.pow(2,8);\n\t          power=1;\n\t          while (power!=maxpower) {\n\t            resb = data.val & data.position;\n\t            data.position >>= 1;\n\t            if (data.position == 0) {\n\t              data.position = resetValue;\n\t              data.val = getNextValue(data.index++);\n\t            }\n\t            bits |= (resb>0 ? 1 : 0) * power;\n\t            power <<= 1;\n\t          }\n\t        c = f(bits);\n\t        break;\n\t      case 1:\n\t          bits = 0;\n\t          maxpower = Math.pow(2,16);\n\t          power=1;\n\t          while (power!=maxpower) {\n\t            resb = data.val & data.position;\n\t            data.position >>= 1;\n\t            if (data.position == 0) {\n\t              data.position = resetValue;\n\t              data.val = getNextValue(data.index++);\n\t            }\n\t            bits |= (resb>0 ? 1 : 0) * power;\n\t            power <<= 1;\n\t          }\n\t        c = f(bits);\n\t        break;\n\t      case 2:\n\t        return \"\";\n\t    }\n\t    dictionary[3] = c;\n\t    w = c;\n\t    result.push(c);\n\t    while (true) {\n\t      if (data.index > length) {\n\t        return \"\";\n\t      }\n\t\n\t      bits = 0;\n\t      maxpower = Math.pow(2,numBits);\n\t      power=1;\n\t      while (power!=maxpower) {\n\t        resb = data.val & data.position;\n\t        data.position >>= 1;\n\t        if (data.position == 0) {\n\t          data.position = resetValue;\n\t          data.val = getNextValue(data.index++);\n\t        }\n\t        bits |= (resb>0 ? 1 : 0) * power;\n\t        power <<= 1;\n\t      }\n\t\n\t      switch (c = bits) {\n\t        case 0:\n\t          bits = 0;\n\t          maxpower = Math.pow(2,8);\n\t          power=1;\n\t          while (power!=maxpower) {\n\t            resb = data.val & data.position;\n\t            data.position >>= 1;\n\t            if (data.position == 0) {\n\t              data.position = resetValue;\n\t              data.val = getNextValue(data.index++);\n\t            }\n\t            bits |= (resb>0 ? 1 : 0) * power;\n\t            power <<= 1;\n\t          }\n\t\n\t          dictionary[dictSize++] = f(bits);\n\t          c = dictSize-1;\n\t          enlargeIn--;\n\t          break;\n\t        case 1:\n\t          bits = 0;\n\t          maxpower = Math.pow(2,16);\n\t          power=1;\n\t          while (power!=maxpower) {\n\t            resb = data.val & data.position;\n\t            data.position >>= 1;\n\t            if (data.position == 0) {\n\t              data.position = resetValue;\n\t              data.val = getNextValue(data.index++);\n\t            }\n\t            bits |= (resb>0 ? 1 : 0) * power;\n\t            power <<= 1;\n\t          }\n\t          dictionary[dictSize++] = f(bits);\n\t          c = dictSize-1;\n\t          enlargeIn--;\n\t          break;\n\t        case 2:\n\t          return result.join('');\n\t      }\n\t\n\t      if (enlargeIn == 0) {\n\t        enlargeIn = Math.pow(2, numBits);\n\t        numBits++;\n\t      }\n\t\n\t      if (dictionary[c]) {\n\t        entry = dictionary[c];\n\t      } else {\n\t        if (c === dictSize) {\n\t          entry = w + w.charAt(0);\n\t        } else {\n\t          return null;\n\t        }\n\t      }\n\t      result.push(entry);\n\t\n\t      // Add w+entry[0] to the dictionary.\n\t      dictionary[dictSize++] = w + entry.charAt(0);\n\t      enlargeIn--;\n\t\n\t      w = entry;\n\t\n\t      if (enlargeIn == 0) {\n\t        enlargeIn = Math.pow(2, numBits);\n\t        numBits++;\n\t      }\n\t\n\t    }\n\t  }\n\t};\n\t  return LZString;\n\t})();\n\t\n\tif (true) {\n\t  !(__WEBPACK_AMD_DEFINE_RESULT__ = function () { return LZString; }.call(exports, __webpack_require__, exports, module), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));\n\t} else {}\n\n\n/***/ },\n/* 11 */\n/***/ function(module, exports, __webpack_require__) {\n\n\t;(function (root, factory, undef) {\n\t\tif (true) {\n\t\t\t// CommonJS\n\t\t\tmodule.exports = exports = factory(__webpack_require__(5), __webpack_require__(12), __webpack_require__(13), __webpack_require__(14), __webpack_require__(15));\n\t\t}\n\t\telse {}\n\t}(this, function (CryptoJS) {\n\t\n\t\t(function () {\n\t\t    // Shortcuts\n\t\t    var C = CryptoJS;\n\t\t    var C_lib = C.lib;\n\t\t    var BlockCipher = C_lib.BlockCipher;\n\t\t    var C_algo = C.algo;\n\t\n\t\t    // Lookup tables\n\t\t    var SBOX = [];\n\t\t    var INV_SBOX = [];\n\t\t    var SUB_MIX_0 = [];\n\t\t    var SUB_MIX_1 = [];\n\t\t    var SUB_MIX_2 = [];\n\t\t    var SUB_MIX_3 = [];\n\t\t    var INV_SUB_MIX_0 = [];\n\t\t    var INV_SUB_MIX_1 = [];\n\t\t    var INV_SUB_MIX_2 = [];\n\t\t    var INV_SUB_MIX_3 = [];\n\t\n\t\t    // Compute lookup tables\n\t\t    (function () {\n\t\t        // Compute double table\n\t\t        var d = [];\n\t\t        for (var i = 0; i < 256; i++) {\n\t\t            if (i < 128) {\n\t\t                d[i] = i << 1;\n\t\t            } else {\n\t\t                d[i] = (i << 1) ^ 0x11b;\n\t\t            }\n\t\t        }\n\t\n\t\t        // Walk GF(2^8)\n\t\t        var x = 0;\n\t\t        var xi = 0;\n\t\t        for (var i = 0; i < 256; i++) {\n\t\t            // Compute sbox\n\t\t            var sx = xi ^ (xi << 1) ^ (xi << 2) ^ (xi << 3) ^ (xi << 4);\n\t\t            sx = (sx >>> 8) ^ (sx & 0xff) ^ 0x63;\n\t\t            SBOX[x] = sx;\n\t\t            INV_SBOX[sx] = x;\n\t\n\t\t            // Compute multiplication\n\t\t            var x2 = d[x];\n\t\t            var x4 = d[x2];\n\t\t            var x8 = d[x4];\n\t\n\t\t            // Compute sub bytes, mix columns tables\n\t\t            var t = (d[sx] * 0x101) ^ (sx * 0x1010100);\n\t\t            SUB_MIX_0[x] = (t << 24) | (t >>> 8);\n\t\t            SUB_MIX_1[x] = (t << 16) | (t >>> 16);\n\t\t            SUB_MIX_2[x] = (t << 8)  | (t >>> 24);\n\t\t            SUB_MIX_3[x] = t;\n\t\n\t\t            // Compute inv sub bytes, inv mix columns tables\n\t\t            var t = (x8 * 0x1010101) ^ (x4 * 0x10001) ^ (x2 * 0x101) ^ (x * 0x1010100);\n\t\t            INV_SUB_MIX_0[sx] = (t << 24) | (t >>> 8);\n\t\t            INV_SUB_MIX_1[sx] = (t << 16) | (t >>> 16);\n\t\t            INV_SUB_MIX_2[sx] = (t << 8)  | (t >>> 24);\n\t\t            INV_SUB_MIX_3[sx] = t;\n\t\n\t\t            // Compute next counter\n\t\t            if (!x) {\n\t\t                x = xi = 1;\n\t\t            } else {\n\t\t                x = x2 ^ d[d[d[x8 ^ x2]]];\n\t\t                xi ^= d[d[xi]];\n\t\t            }\n\t\t        }\n\t\t    }());\n\t\n\t\t    // Precomputed Rcon lookup\n\t\t    var RCON = [0x00, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36];\n\t\n\t\t    /**\n\t\t     * AES block cipher algorithm.\n\t\t     */\n\t\t    var AES = C_algo.AES = BlockCipher.extend({\n\t\t        _doReset: function () {\n\t\t            // Skip reset of nRounds has been set before and key did not change\n\t\t            if (this._nRounds && this._keyPriorReset === this._key) {\n\t\t                return;\n\t\t            }\n\t\n\t\t            // Shortcuts\n\t\t            var key = this._keyPriorReset = this._key;\n\t\t            var keyWords = key.words;\n\t\t            var keySize = key.sigBytes / 4;\n\t\n\t\t            // Compute number of rounds\n\t\t            var nRounds = this._nRounds = keySize + 6;\n\t\n\t\t            // Compute number of key schedule rows\n\t\t            var ksRows = (nRounds + 1) * 4;\n\t\n\t\t            // Compute key schedule\n\t\t            var keySchedule = this._keySchedule = [];\n\t\t            for (var ksRow = 0; ksRow < ksRows; ksRow++) {\n\t\t                if (ksRow < keySize) {\n\t\t                    keySchedule[ksRow] = keyWords[ksRow];\n\t\t                } else {\n\t\t                    var t = keySchedule[ksRow - 1];\n\t\n\t\t                    if (!(ksRow % keySize)) {\n\t\t                        // Rot word\n\t\t                        t = (t << 8) | (t >>> 24);\n\t\n\t\t                        // Sub word\n\t\t                        t = (SBOX[t >>> 24] << 24) | (SBOX[(t >>> 16) & 0xff] << 16) | (SBOX[(t >>> 8) & 0xff] << 8) | SBOX[t & 0xff];\n\t\n\t\t                        // Mix Rcon\n\t\t                        t ^= RCON[(ksRow / keySize) | 0] << 24;\n\t\t                    } else if (keySize > 6 && ksRow % keySize == 4) {\n\t\t                        // Sub word\n\t\t                        t = (SBOX[t >>> 24] << 24) | (SBOX[(t >>> 16) & 0xff] << 16) | (SBOX[(t >>> 8) & 0xff] << 8) | SBOX[t & 0xff];\n\t\t                    }\n\t\n\t\t                    keySchedule[ksRow] = keySchedule[ksRow - keySize] ^ t;\n\t\t                }\n\t\t            }\n\t\n\t\t            // Compute inv key schedule\n\t\t            var invKeySchedule = this._invKeySchedule = [];\n\t\t            for (var invKsRow = 0; invKsRow < ksRows; invKsRow++) {\n\t\t                var ksRow = ksRows - invKsRow;\n\t\n\t\t                if (invKsRow % 4) {\n\t\t                    var t = keySchedule[ksRow];\n\t\t                } else {\n\t\t                    var t = keySchedule[ksRow - 4];\n\t\t                }\n\t\n\t\t                if (invKsRow < 4 || ksRow <= 4) {\n\t\t                    invKeySchedule[invKsRow] = t;\n\t\t                } else {\n\t\t                    invKeySchedule[invKsRow] = INV_SUB_MIX_0[SBOX[t >>> 24]] ^ INV_SUB_MIX_1[SBOX[(t >>> 16) & 0xff]] ^\n\t\t                                               INV_SUB_MIX_2[SBOX[(t >>> 8) & 0xff]] ^ INV_SUB_MIX_3[SBOX[t & 0xff]];\n\t\t                }\n\t\t            }\n\t\t        },\n\t\n\t\t        encryptBlock: function (M, offset) {\n\t\t            this._doCryptBlock(M, offset, this._keySchedule, SUB_MIX_0, SUB_MIX_1, SUB_MIX_2, SUB_MIX_3, SBOX);\n\t\t        },\n\t\n\t\t        decryptBlock: function (M, offset) {\n\t\t            // Swap 2nd and 4th rows\n\t\t            var t = M[offset + 1];\n\t\t            M[offset + 1] = M[offset + 3];\n\t\t            M[offset + 3] = t;\n\t\n\t\t            this._doCryptBlock(M, offset, this._invKeySchedule, INV_SUB_MIX_0, INV_SUB_MIX_1, INV_SUB_MIX_2, INV_SUB_MIX_3, INV_SBOX);\n\t\n\t\t            // Inv swap 2nd and 4th rows\n\t\t            var t = M[offset + 1];\n\t\t            M[offset + 1] = M[offset + 3];\n\t\t            M[offset + 3] = t;\n\t\t        },\n\t\n\t\t        _doCryptBlock: function (M, offset, keySchedule, SUB_MIX_0, SUB_MIX_1, SUB_MIX_2, SUB_MIX_3, SBOX) {\n\t\t            // Shortcut\n\t\t            var nRounds = this._nRounds;\n\t\n\t\t            // Get input, add round key\n\t\t            var s0 = M[offset]     ^ keySchedule[0];\n\t\t            var s1 = M[offset + 1] ^ keySchedule[1];\n\t\t            var s2 = M[offset + 2] ^ keySchedule[2];\n\t\t            var s3 = M[offset + 3] ^ keySchedule[3];\n\t\n\t\t            // Key schedule row counter\n\t\t            var ksRow = 4;\n\t\n\t\t            // Rounds\n\t\t            for (var round = 1; round < nRounds; round++) {\n\t\t                // Shift rows, sub bytes, mix columns, add round key\n\t\t                var t0 = SUB_MIX_0[s0 >>> 24] ^ SUB_MIX_1[(s1 >>> 16) & 0xff] ^ SUB_MIX_2[(s2 >>> 8) & 0xff] ^ SUB_MIX_3[s3 & 0xff] ^ keySchedule[ksRow++];\n\t\t                var t1 = SUB_MIX_0[s1 >>> 24] ^ SUB_MIX_1[(s2 >>> 16) & 0xff] ^ SUB_MIX_2[(s3 >>> 8) & 0xff] ^ SUB_MIX_3[s0 & 0xff] ^ keySchedule[ksRow++];\n\t\t                var t2 = SUB_MIX_0[s2 >>> 24] ^ SUB_MIX_1[(s3 >>> 16) & 0xff] ^ SUB_MIX_2[(s0 >>> 8) & 0xff] ^ SUB_MIX_3[s1 & 0xff] ^ keySchedule[ksRow++];\n\t\t                var t3 = SUB_MIX_0[s3 >>> 24] ^ SUB_MIX_1[(s0 >>> 16) & 0xff] ^ SUB_MIX_2[(s1 >>> 8) & 0xff] ^ SUB_MIX_3[s2 & 0xff] ^ keySchedule[ksRow++];\n\t\n\t\t                // Update state\n\t\t                s0 = t0;\n\t\t                s1 = t1;\n\t\t                s2 = t2;\n\t\t                s3 = t3;\n\t\t            }\n\t\n\t\t            // Shift rows, sub bytes, add round key\n\t\t            var t0 = ((SBOX[s0 >>> 24] << 24) | (SBOX[(s1 >>> 16) & 0xff] << 16) | (SBOX[(s2 >>> 8) & 0xff] << 8) | SBOX[s3 & 0xff]) ^ keySchedule[ksRow++];\n\t\t            var t1 = ((SBOX[s1 >>> 24] << 24) | (SBOX[(s2 >>> 16) & 0xff] << 16) | (SBOX[(s3 >>> 8) & 0xff] << 8) | SBOX[s0 & 0xff]) ^ keySchedule[ksRow++];\n\t\t            var t2 = ((SBOX[s2 >>> 24] << 24) | (SBOX[(s3 >>> 16) & 0xff] << 16) | (SBOX[(s0 >>> 8) & 0xff] << 8) | SBOX[s1 & 0xff]) ^ keySchedule[ksRow++];\n\t\t            var t3 = ((SBOX[s3 >>> 24] << 24) | (SBOX[(s0 >>> 16) & 0xff] << 16) | (SBOX[(s1 >>> 8) & 0xff] << 8) | SBOX[s2 & 0xff]) ^ keySchedule[ksRow++];\n\t\n\t\t            // Set output\n\t\t            M[offset]     = t0;\n\t\t            M[offset + 1] = t1;\n\t\t            M[offset + 2] = t2;\n\t\t            M[offset + 3] = t3;\n\t\t        },\n\t\n\t\t        keySize: 256/32\n\t\t    });\n\t\n\t\t    /**\n\t\t     * Shortcut functions to the cipher's object interface.\n\t\t     *\n\t\t     * @example\n\t\t     *\n\t\t     *     var ciphertext = CryptoJS.AES.encrypt(message, key, cfg);\n\t\t     *     var plaintext  = CryptoJS.AES.decrypt(ciphertext, key, cfg);\n\t\t     */\n\t\t    C.AES = BlockCipher._createHelper(AES);\n\t\t}());\n\t\n\t\n\t\treturn CryptoJS.AES;\n\t\n\t}));\n\n/***/ },\n/* 12 */\n/***/ function(module, exports, __webpack_require__) {\n\n\t;(function (root, factory) {\n\t\tif (true) {\n\t\t\t// CommonJS\n\t\t\tmodule.exports = exports = factory(__webpack_require__(5));\n\t\t}\n\t\telse {}\n\t}(this, function (CryptoJS) {\n\t\n\t\t(function () {\n\t\t    // Shortcuts\n\t\t    var C = CryptoJS;\n\t\t    var C_lib = C.lib;\n\t\t    var WordArray = C_lib.WordArray;\n\t\t    var C_enc = C.enc;\n\t\n\t\t    /**\n\t\t     * Base64 encoding strategy.\n\t\t     */\n\t\t    var Base64 = C_enc.Base64 = {\n\t\t        /**\n\t\t         * Converts a word array to a Base64 string.\n\t\t         *\n\t\t         * @param {WordArray} wordArray The word array.\n\t\t         *\n\t\t         * @return {string} The Base64 string.\n\t\t         *\n\t\t         * @static\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var base64String = CryptoJS.enc.Base64.stringify(wordArray);\n\t\t         */\n\t\t        stringify: function (wordArray) {\n\t\t            // Shortcuts\n\t\t            var words = wordArray.words;\n\t\t            var sigBytes = wordArray.sigBytes;\n\t\t            var map = this._map;\n\t\n\t\t            // Clamp excess bits\n\t\t            wordArray.clamp();\n\t\n\t\t            // Convert\n\t\t            var base64Chars = [];\n\t\t            for (var i = 0; i < sigBytes; i += 3) {\n\t\t                var byte1 = (words[i >>> 2]       >>> (24 - (i % 4) * 8))       & 0xff;\n\t\t                var byte2 = (words[(i + 1) >>> 2] >>> (24 - ((i + 1) % 4) * 8)) & 0xff;\n\t\t                var byte3 = (words[(i + 2) >>> 2] >>> (24 - ((i + 2) % 4) * 8)) & 0xff;\n\t\n\t\t                var triplet = (byte1 << 16) | (byte2 << 8) | byte3;\n\t\n\t\t                for (var j = 0; (j < 4) && (i + j * 0.75 < sigBytes); j++) {\n\t\t                    base64Chars.push(map.charAt((triplet >>> (6 * (3 - j))) & 0x3f));\n\t\t                }\n\t\t            }\n\t\n\t\t            // Add padding\n\t\t            var paddingChar = map.charAt(64);\n\t\t            if (paddingChar) {\n\t\t                while (base64Chars.length % 4) {\n\t\t                    base64Chars.push(paddingChar);\n\t\t                }\n\t\t            }\n\t\n\t\t            return base64Chars.join('');\n\t\t        },\n\t\n\t\t        /**\n\t\t         * Converts a Base64 string to a word array.\n\t\t         *\n\t\t         * @param {string} base64Str The Base64 string.\n\t\t         *\n\t\t         * @return {WordArray} The word array.\n\t\t         *\n\t\t         * @static\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var wordArray = CryptoJS.enc.Base64.parse(base64String);\n\t\t         */\n\t\t        parse: function (base64Str) {\n\t\t            // Shortcuts\n\t\t            var base64StrLength = base64Str.length;\n\t\t            var map = this._map;\n\t\t            var reverseMap = this._reverseMap;\n\t\n\t\t            if (!reverseMap) {\n\t\t                    reverseMap = this._reverseMap = [];\n\t\t                    for (var j = 0; j < map.length; j++) {\n\t\t                        reverseMap[map.charCodeAt(j)] = j;\n\t\t                    }\n\t\t            }\n\t\n\t\t            // Ignore padding\n\t\t            var paddingChar = map.charAt(64);\n\t\t            if (paddingChar) {\n\t\t                var paddingIndex = base64Str.indexOf(paddingChar);\n\t\t                if (paddingIndex !== -1) {\n\t\t                    base64StrLength = paddingIndex;\n\t\t                }\n\t\t            }\n\t\n\t\t            // Convert\n\t\t            return parseLoop(base64Str, base64StrLength, reverseMap);\n\t\n\t\t        },\n\t\n\t\t        _map: 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/='\n\t\t    };\n\t\n\t\t    function parseLoop(base64Str, base64StrLength, reverseMap) {\n\t\t      var words = [];\n\t\t      var nBytes = 0;\n\t\t      for (var i = 0; i < base64StrLength; i++) {\n\t\t          if (i % 4) {\n\t\t              var bits1 = reverseMap[base64Str.charCodeAt(i - 1)] << ((i % 4) * 2);\n\t\t              var bits2 = reverseMap[base64Str.charCodeAt(i)] >>> (6 - (i % 4) * 2);\n\t\t              words[nBytes >>> 2] |= (bits1 | bits2) << (24 - (nBytes % 4) * 8);\n\t\t              nBytes++;\n\t\t          }\n\t\t      }\n\t\t      return WordArray.create(words, nBytes);\n\t\t    }\n\t\t}());\n\t\n\t\n\t\treturn CryptoJS.enc.Base64;\n\t\n\t}));\n\n/***/ },\n/* 13 */\n/***/ function(module, exports, __webpack_require__) {\n\n\t;(function (root, factory) {\n\t\tif (true) {\n\t\t\t// CommonJS\n\t\t\tmodule.exports = exports = factory(__webpack_require__(5));\n\t\t}\n\t\telse {}\n\t}(this, function (CryptoJS) {\n\t\n\t\t(function (Math) {\n\t\t    // Shortcuts\n\t\t    var C = CryptoJS;\n\t\t    var C_lib = C.lib;\n\t\t    var WordArray = C_lib.WordArray;\n\t\t    var Hasher = C_lib.Hasher;\n\t\t    var C_algo = C.algo;\n\t\n\t\t    // Constants table\n\t\t    var T = [];\n\t\n\t\t    // Compute constants\n\t\t    (function () {\n\t\t        for (var i = 0; i < 64; i++) {\n\t\t            T[i] = (Math.abs(Math.sin(i + 1)) * 0x100000000) | 0;\n\t\t        }\n\t\t    }());\n\t\n\t\t    /**\n\t\t     * MD5 hash algorithm.\n\t\t     */\n\t\t    var MD5 = C_algo.MD5 = Hasher.extend({\n\t\t        _doReset: function () {\n\t\t            this._hash = new WordArray.init([\n\t\t                0x67452301, 0xefcdab89,\n\t\t                0x98badcfe, 0x10325476\n\t\t            ]);\n\t\t        },\n\t\n\t\t        _doProcessBlock: function (M, offset) {\n\t\t            // Swap endian\n\t\t            for (var i = 0; i < 16; i++) {\n\t\t                // Shortcuts\n\t\t                var offset_i = offset + i;\n\t\t                var M_offset_i = M[offset_i];\n\t\n\t\t                M[offset_i] = (\n\t\t                    (((M_offset_i << 8)  | (M_offset_i >>> 24)) & 0x00ff00ff) |\n\t\t                    (((M_offset_i << 24) | (M_offset_i >>> 8))  & 0xff00ff00)\n\t\t                );\n\t\t            }\n\t\n\t\t            // Shortcuts\n\t\t            var H = this._hash.words;\n\t\n\t\t            var M_offset_0  = M[offset + 0];\n\t\t            var M_offset_1  = M[offset + 1];\n\t\t            var M_offset_2  = M[offset + 2];\n\t\t            var M_offset_3  = M[offset + 3];\n\t\t            var M_offset_4  = M[offset + 4];\n\t\t            var M_offset_5  = M[offset + 5];\n\t\t            var M_offset_6  = M[offset + 6];\n\t\t            var M_offset_7  = M[offset + 7];\n\t\t            var M_offset_8  = M[offset + 8];\n\t\t            var M_offset_9  = M[offset + 9];\n\t\t            var M_offset_10 = M[offset + 10];\n\t\t            var M_offset_11 = M[offset + 11];\n\t\t            var M_offset_12 = M[offset + 12];\n\t\t            var M_offset_13 = M[offset + 13];\n\t\t            var M_offset_14 = M[offset + 14];\n\t\t            var M_offset_15 = M[offset + 15];\n\t\n\t\t            // Working varialbes\n\t\t            var a = H[0];\n\t\t            var b = H[1];\n\t\t            var c = H[2];\n\t\t            var d = H[3];\n\t\n\t\t            // Computation\n\t\t            a = FF(a, b, c, d, M_offset_0,  7,  T[0]);\n\t\t            d = FF(d, a, b, c, M_offset_1,  12, T[1]);\n\t\t            c = FF(c, d, a, b, M_offset_2,  17, T[2]);\n\t\t            b = FF(b, c, d, a, M_offset_3,  22, T[3]);\n\t\t            a = FF(a, b, c, d, M_offset_4,  7,  T[4]);\n\t\t            d = FF(d, a, b, c, M_offset_5,  12, T[5]);\n\t\t            c = FF(c, d, a, b, M_offset_6,  17, T[6]);\n\t\t            b = FF(b, c, d, a, M_offset_7,  22, T[7]);\n\t\t            a = FF(a, b, c, d, M_offset_8,  7,  T[8]);\n\t\t            d = FF(d, a, b, c, M_offset_9,  12, T[9]);\n\t\t            c = FF(c, d, a, b, M_offset_10, 17, T[10]);\n\t\t            b = FF(b, c, d, a, M_offset_11, 22, T[11]);\n\t\t            a = FF(a, b, c, d, M_offset_12, 7,  T[12]);\n\t\t            d = FF(d, a, b, c, M_offset_13, 12, T[13]);\n\t\t            c = FF(c, d, a, b, M_offset_14, 17, T[14]);\n\t\t            b = FF(b, c, d, a, M_offset_15, 22, T[15]);\n\t\n\t\t            a = GG(a, b, c, d, M_offset_1,  5,  T[16]);\n\t\t            d = GG(d, a, b, c, M_offset_6,  9,  T[17]);\n\t\t            c = GG(c, d, a, b, M_offset_11, 14, T[18]);\n\t\t            b = GG(b, c, d, a, M_offset_0,  20, T[19]);\n\t\t            a = GG(a, b, c, d, M_offset_5,  5,  T[20]);\n\t\t            d = GG(d, a, b, c, M_offset_10, 9,  T[21]);\n\t\t            c = GG(c, d, a, b, M_offset_15, 14, T[22]);\n\t\t            b = GG(b, c, d, a, M_offset_4,  20, T[23]);\n\t\t            a = GG(a, b, c, d, M_offset_9,  5,  T[24]);\n\t\t            d = GG(d, a, b, c, M_offset_14, 9,  T[25]);\n\t\t            c = GG(c, d, a, b, M_offset_3,  14, T[26]);\n\t\t            b = GG(b, c, d, a, M_offset_8,  20, T[27]);\n\t\t            a = GG(a, b, c, d, M_offset_13, 5,  T[28]);\n\t\t            d = GG(d, a, b, c, M_offset_2,  9,  T[29]);\n\t\t            c = GG(c, d, a, b, M_offset_7,  14, T[30]);\n\t\t            b = GG(b, c, d, a, M_offset_12, 20, T[31]);\n\t\n\t\t            a = HH(a, b, c, d, M_offset_5,  4,  T[32]);\n\t\t            d = HH(d, a, b, c, M_offset_8,  11, T[33]);\n\t\t            c = HH(c, d, a, b, M_offset_11, 16, T[34]);\n\t\t            b = HH(b, c, d, a, M_offset_14, 23, T[35]);\n\t\t            a = HH(a, b, c, d, M_offset_1,  4,  T[36]);\n\t\t            d = HH(d, a, b, c, M_offset_4,  11, T[37]);\n\t\t            c = HH(c, d, a, b, M_offset_7,  16, T[38]);\n\t\t            b = HH(b, c, d, a, M_offset_10, 23, T[39]);\n\t\t            a = HH(a, b, c, d, M_offset_13, 4,  T[40]);\n\t\t            d = HH(d, a, b, c, M_offset_0,  11, T[41]);\n\t\t            c = HH(c, d, a, b, M_offset_3,  16, T[42]);\n\t\t            b = HH(b, c, d, a, M_offset_6,  23, T[43]);\n\t\t            a = HH(a, b, c, d, M_offset_9,  4,  T[44]);\n\t\t            d = HH(d, a, b, c, M_offset_12, 11, T[45]);\n\t\t            c = HH(c, d, a, b, M_offset_15, 16, T[46]);\n\t\t            b = HH(b, c, d, a, M_offset_2,  23, T[47]);\n\t\n\t\t            a = II(a, b, c, d, M_offset_0,  6,  T[48]);\n\t\t            d = II(d, a, b, c, M_offset_7,  10, T[49]);\n\t\t            c = II(c, d, a, b, M_offset_14, 15, T[50]);\n\t\t            b = II(b, c, d, a, M_offset_5,  21, T[51]);\n\t\t            a = II(a, b, c, d, M_offset_12, 6,  T[52]);\n\t\t            d = II(d, a, b, c, M_offset_3,  10, T[53]);\n\t\t            c = II(c, d, a, b, M_offset_10, 15, T[54]);\n\t\t            b = II(b, c, d, a, M_offset_1,  21, T[55]);\n\t\t            a = II(a, b, c, d, M_offset_8,  6,  T[56]);\n\t\t            d = II(d, a, b, c, M_offset_15, 10, T[57]);\n\t\t            c = II(c, d, a, b, M_offset_6,  15, T[58]);\n\t\t            b = II(b, c, d, a, M_offset_13, 21, T[59]);\n\t\t            a = II(a, b, c, d, M_offset_4,  6,  T[60]);\n\t\t            d = II(d, a, b, c, M_offset_11, 10, T[61]);\n\t\t            c = II(c, d, a, b, M_offset_2,  15, T[62]);\n\t\t            b = II(b, c, d, a, M_offset_9,  21, T[63]);\n\t\n\t\t            // Intermediate hash value\n\t\t            H[0] = (H[0] + a) | 0;\n\t\t            H[1] = (H[1] + b) | 0;\n\t\t            H[2] = (H[2] + c) | 0;\n\t\t            H[3] = (H[3] + d) | 0;\n\t\t        },\n\t\n\t\t        _doFinalize: function () {\n\t\t            // Shortcuts\n\t\t            var data = this._data;\n\t\t            var dataWords = data.words;\n\t\n\t\t            var nBitsTotal = this._nDataBytes * 8;\n\t\t            var nBitsLeft = data.sigBytes * 8;\n\t\n\t\t            // Add padding\n\t\t            dataWords[nBitsLeft >>> 5] |= 0x80 << (24 - nBitsLeft % 32);\n\t\n\t\t            var nBitsTotalH = Math.floor(nBitsTotal / 0x100000000);\n\t\t            var nBitsTotalL = nBitsTotal;\n\t\t            dataWords[(((nBitsLeft + 64) >>> 9) << 4) + 15] = (\n\t\t                (((nBitsTotalH << 8)  | (nBitsTotalH >>> 24)) & 0x00ff00ff) |\n\t\t                (((nBitsTotalH << 24) | (nBitsTotalH >>> 8))  & 0xff00ff00)\n\t\t            );\n\t\t            dataWords[(((nBitsLeft + 64) >>> 9) << 4) + 14] = (\n\t\t                (((nBitsTotalL << 8)  | (nBitsTotalL >>> 24)) & 0x00ff00ff) |\n\t\t                (((nBitsTotalL << 24) | (nBitsTotalL >>> 8))  & 0xff00ff00)\n\t\t            );\n\t\n\t\t            data.sigBytes = (dataWords.length + 1) * 4;\n\t\n\t\t            // Hash final blocks\n\t\t            this._process();\n\t\n\t\t            // Shortcuts\n\t\t            var hash = this._hash;\n\t\t            var H = hash.words;\n\t\n\t\t            // Swap endian\n\t\t            for (var i = 0; i < 4; i++) {\n\t\t                // Shortcut\n\t\t                var H_i = H[i];\n\t\n\t\t                H[i] = (((H_i << 8)  | (H_i >>> 24)) & 0x00ff00ff) |\n\t\t                       (((H_i << 24) | (H_i >>> 8))  & 0xff00ff00);\n\t\t            }\n\t\n\t\t            // Return final computed hash\n\t\t            return hash;\n\t\t        },\n\t\n\t\t        clone: function () {\n\t\t            var clone = Hasher.clone.call(this);\n\t\t            clone._hash = this._hash.clone();\n\t\n\t\t            return clone;\n\t\t        }\n\t\t    });\n\t\n\t\t    function FF(a, b, c, d, x, s, t) {\n\t\t        var n = a + ((b & c) | (~b & d)) + x + t;\n\t\t        return ((n << s) | (n >>> (32 - s))) + b;\n\t\t    }\n\t\n\t\t    function GG(a, b, c, d, x, s, t) {\n\t\t        var n = a + ((b & d) | (c & ~d)) + x + t;\n\t\t        return ((n << s) | (n >>> (32 - s))) + b;\n\t\t    }\n\t\n\t\t    function HH(a, b, c, d, x, s, t) {\n\t\t        var n = a + (b ^ c ^ d) + x + t;\n\t\t        return ((n << s) | (n >>> (32 - s))) + b;\n\t\t    }\n\t\n\t\t    function II(a, b, c, d, x, s, t) {\n\t\t        var n = a + (c ^ (b | ~d)) + x + t;\n\t\t        return ((n << s) | (n >>> (32 - s))) + b;\n\t\t    }\n\t\n\t\t    /**\n\t\t     * Shortcut function to the hasher's object interface.\n\t\t     *\n\t\t     * @param {WordArray|string} message The message to hash.\n\t\t     *\n\t\t     * @return {WordArray} The hash.\n\t\t     *\n\t\t     * @static\n\t\t     *\n\t\t     * @example\n\t\t     *\n\t\t     *     var hash = CryptoJS.MD5('message');\n\t\t     *     var hash = CryptoJS.MD5(wordArray);\n\t\t     */\n\t\t    C.MD5 = Hasher._createHelper(MD5);\n\t\n\t\t    /**\n\t\t     * Shortcut function to the HMAC's object interface.\n\t\t     *\n\t\t     * @param {WordArray|string} message The message to hash.\n\t\t     * @param {WordArray|string} key The secret key.\n\t\t     *\n\t\t     * @return {WordArray} The HMAC.\n\t\t     *\n\t\t     * @static\n\t\t     *\n\t\t     * @example\n\t\t     *\n\t\t     *     var hmac = CryptoJS.HmacMD5(message, key);\n\t\t     */\n\t\t    C.HmacMD5 = Hasher._createHmacHelper(MD5);\n\t\t}(Math));\n\t\n\t\n\t\treturn CryptoJS.MD5;\n\t\n\t}));\n\n/***/ },\n/* 14 */\n/***/ function(module, exports, __webpack_require__) {\n\n\t;(function (root, factory, undef) {\n\t\tif (true) {\n\t\t\t// CommonJS\n\t\t\tmodule.exports = exports = factory(__webpack_require__(5), __webpack_require__(6), __webpack_require__(7));\n\t\t}\n\t\telse {}\n\t}(this, function (CryptoJS) {\n\t\n\t\t(function () {\n\t\t    // Shortcuts\n\t\t    var C = CryptoJS;\n\t\t    var C_lib = C.lib;\n\t\t    var Base = C_lib.Base;\n\t\t    var WordArray = C_lib.WordArray;\n\t\t    var C_algo = C.algo;\n\t\t    var MD5 = C_algo.MD5;\n\t\n\t\t    /**\n\t\t     * This key derivation function is meant to conform with EVP_BytesToKey.\n\t\t     * www.openssl.org/docs/crypto/EVP_BytesToKey.html\n\t\t     */\n\t\t    var EvpKDF = C_algo.EvpKDF = Base.extend({\n\t\t        /**\n\t\t         * Configuration options.\n\t\t         *\n\t\t         * @property {number} keySize The key size in words to generate. Default: 4 (128 bits)\n\t\t         * @property {Hasher} hasher The hash algorithm to use. Default: MD5\n\t\t         * @property {number} iterations The number of iterations to perform. Default: 1\n\t\t         */\n\t\t        cfg: Base.extend({\n\t\t            keySize: 128/32,\n\t\t            hasher: MD5,\n\t\t            iterations: 1\n\t\t        }),\n\t\n\t\t        /**\n\t\t         * Initializes a newly created key derivation function.\n\t\t         *\n\t\t         * @param {Object} cfg (Optional) The configuration options to use for the derivation.\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var kdf = CryptoJS.algo.EvpKDF.create();\n\t\t         *     var kdf = CryptoJS.algo.EvpKDF.create({ keySize: 8 });\n\t\t         *     var kdf = CryptoJS.algo.EvpKDF.create({ keySize: 8, iterations: 1000 });\n\t\t         */\n\t\t        init: function (cfg) {\n\t\t            this.cfg = this.cfg.extend(cfg);\n\t\t        },\n\t\n\t\t        /**\n\t\t         * Derives a key from a password.\n\t\t         *\n\t\t         * @param {WordArray|string} password The password.\n\t\t         * @param {WordArray|string} salt A salt.\n\t\t         *\n\t\t         * @return {WordArray} The derived key.\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var key = kdf.compute(password, salt);\n\t\t         */\n\t\t        compute: function (password, salt) {\n\t\t            // Shortcut\n\t\t            var cfg = this.cfg;\n\t\n\t\t            // Init hasher\n\t\t            var hasher = cfg.hasher.create();\n\t\n\t\t            // Initial values\n\t\t            var derivedKey = WordArray.create();\n\t\n\t\t            // Shortcuts\n\t\t            var derivedKeyWords = derivedKey.words;\n\t\t            var keySize = cfg.keySize;\n\t\t            var iterations = cfg.iterations;\n\t\n\t\t            // Generate key\n\t\t            while (derivedKeyWords.length < keySize) {\n\t\t                if (block) {\n\t\t                    hasher.update(block);\n\t\t                }\n\t\t                var block = hasher.update(password).finalize(salt);\n\t\t                hasher.reset();\n\t\n\t\t                // Iterations\n\t\t                for (var i = 1; i < iterations; i++) {\n\t\t                    block = hasher.finalize(block);\n\t\t                    hasher.reset();\n\t\t                }\n\t\n\t\t                derivedKey.concat(block);\n\t\t            }\n\t\t            derivedKey.sigBytes = keySize * 4;\n\t\n\t\t            return derivedKey;\n\t\t        }\n\t\t    });\n\t\n\t\t    /**\n\t\t     * Derives a key from a password.\n\t\t     *\n\t\t     * @param {WordArray|string} password The password.\n\t\t     * @param {WordArray|string} salt A salt.\n\t\t     * @param {Object} cfg (Optional) The configuration options to use for this computation.\n\t\t     *\n\t\t     * @return {WordArray} The derived key.\n\t\t     *\n\t\t     * @static\n\t\t     *\n\t\t     * @example\n\t\t     *\n\t\t     *     var key = CryptoJS.EvpKDF(password, salt);\n\t\t     *     var key = CryptoJS.EvpKDF(password, salt, { keySize: 8 });\n\t\t     *     var key = CryptoJS.EvpKDF(password, salt, { keySize: 8, iterations: 1000 });\n\t\t     */\n\t\t    C.EvpKDF = function (password, salt, cfg) {\n\t\t        return EvpKDF.create(cfg).compute(password, salt);\n\t\t    };\n\t\t}());\n\t\n\t\n\t\treturn CryptoJS.EvpKDF;\n\t\n\t}));\n\n/***/ },\n/* 15 */\n/***/ function(module, exports, __webpack_require__) {\n\n\t;(function (root, factory) {\n\t\tif (true) {\n\t\t\t// CommonJS\n\t\t\tmodule.exports = exports = factory(__webpack_require__(5));\n\t\t}\n\t\telse {}\n\t}(this, function (CryptoJS) {\n\t\n\t\t/**\n\t\t * Cipher core components.\n\t\t */\n\t\tCryptoJS.lib.Cipher || (function (undefined) {\n\t\t    // Shortcuts\n\t\t    var C = CryptoJS;\n\t\t    var C_lib = C.lib;\n\t\t    var Base = C_lib.Base;\n\t\t    var WordArray = C_lib.WordArray;\n\t\t    var BufferedBlockAlgorithm = C_lib.BufferedBlockAlgorithm;\n\t\t    var C_enc = C.enc;\n\t\t    var Utf8 = C_enc.Utf8;\n\t\t    var Base64 = C_enc.Base64;\n\t\t    var C_algo = C.algo;\n\t\t    var EvpKDF = C_algo.EvpKDF;\n\t\n\t\t    /**\n\t\t     * Abstract base cipher template.\n\t\t     *\n\t\t     * @property {number} keySize This cipher's key size. Default: 4 (128 bits)\n\t\t     * @property {number} ivSize This cipher's IV size. Default: 4 (128 bits)\n\t\t     * @property {number} _ENC_XFORM_MODE A constant representing encryption mode.\n\t\t     * @property {number} _DEC_XFORM_MODE A constant representing decryption mode.\n\t\t     */\n\t\t    var Cipher = C_lib.Cipher = BufferedBlockAlgorithm.extend({\n\t\t        /**\n\t\t         * Configuration options.\n\t\t         *\n\t\t         * @property {WordArray} iv The IV to use for this operation.\n\t\t         */\n\t\t        cfg: Base.extend(),\n\t\n\t\t        /**\n\t\t         * Creates this cipher in encryption mode.\n\t\t         *\n\t\t         * @param {WordArray} key The key.\n\t\t         * @param {Object} cfg (Optional) The configuration options to use for this operation.\n\t\t         *\n\t\t         * @return {Cipher} A cipher instance.\n\t\t         *\n\t\t         * @static\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var cipher = CryptoJS.algo.AES.createEncryptor(keyWordArray, { iv: ivWordArray });\n\t\t         */\n\t\t        createEncryptor: function (key, cfg) {\n\t\t            return this.create(this._ENC_XFORM_MODE, key, cfg);\n\t\t        },\n\t\n\t\t        /**\n\t\t         * Creates this cipher in decryption mode.\n\t\t         *\n\t\t         * @param {WordArray} key The key.\n\t\t         * @param {Object} cfg (Optional) The configuration options to use for this operation.\n\t\t         *\n\t\t         * @return {Cipher} A cipher instance.\n\t\t         *\n\t\t         * @static\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var cipher = CryptoJS.algo.AES.createDecryptor(keyWordArray, { iv: ivWordArray });\n\t\t         */\n\t\t        createDecryptor: function (key, cfg) {\n\t\t            return this.create(this._DEC_XFORM_MODE, key, cfg);\n\t\t        },\n\t\n\t\t        /**\n\t\t         * Initializes a newly created cipher.\n\t\t         *\n\t\t         * @param {number} xformMode Either the encryption or decryption transormation mode constant.\n\t\t         * @param {WordArray} key The key.\n\t\t         * @param {Object} cfg (Optional) The configuration options to use for this operation.\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var cipher = CryptoJS.algo.AES.create(CryptoJS.algo.AES._ENC_XFORM_MODE, keyWordArray, { iv: ivWordArray });\n\t\t         */\n\t\t        init: function (xformMode, key, cfg) {\n\t\t            // Apply config defaults\n\t\t            this.cfg = this.cfg.extend(cfg);\n\t\n\t\t            // Store transform mode and key\n\t\t            this._xformMode = xformMode;\n\t\t            this._key = key;\n\t\n\t\t            // Set initial values\n\t\t            this.reset();\n\t\t        },\n\t\n\t\t        /**\n\t\t         * Resets this cipher to its initial state.\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     cipher.reset();\n\t\t         */\n\t\t        reset: function () {\n\t\t            // Reset data buffer\n\t\t            BufferedBlockAlgorithm.reset.call(this);\n\t\n\t\t            // Perform concrete-cipher logic\n\t\t            this._doReset();\n\t\t        },\n\t\n\t\t        /**\n\t\t         * Adds data to be encrypted or decrypted.\n\t\t         *\n\t\t         * @param {WordArray|string} dataUpdate The data to encrypt or decrypt.\n\t\t         *\n\t\t         * @return {WordArray} The data after processing.\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var encrypted = cipher.process('data');\n\t\t         *     var encrypted = cipher.process(wordArray);\n\t\t         */\n\t\t        process: function (dataUpdate) {\n\t\t            // Append\n\t\t            this._append(dataUpdate);\n\t\n\t\t            // Process available blocks\n\t\t            return this._process();\n\t\t        },\n\t\n\t\t        /**\n\t\t         * Finalizes the encryption or decryption process.\n\t\t         * Note that the finalize operation is effectively a destructive, read-once operation.\n\t\t         *\n\t\t         * @param {WordArray|string} dataUpdate The final data to encrypt or decrypt.\n\t\t         *\n\t\t         * @return {WordArray} The data after final processing.\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var encrypted = cipher.finalize();\n\t\t         *     var encrypted = cipher.finalize('data');\n\t\t         *     var encrypted = cipher.finalize(wordArray);\n\t\t         */\n\t\t        finalize: function (dataUpdate) {\n\t\t            // Final data update\n\t\t            if (dataUpdate) {\n\t\t                this._append(dataUpdate);\n\t\t            }\n\t\n\t\t            // Perform concrete-cipher logic\n\t\t            var finalProcessedData = this._doFinalize();\n\t\n\t\t            return finalProcessedData;\n\t\t        },\n\t\n\t\t        keySize: 128/32,\n\t\n\t\t        ivSize: 128/32,\n\t\n\t\t        _ENC_XFORM_MODE: 1,\n\t\n\t\t        _DEC_XFORM_MODE: 2,\n\t\n\t\t        /**\n\t\t         * Creates shortcut functions to a cipher's object interface.\n\t\t         *\n\t\t         * @param {Cipher} cipher The cipher to create a helper for.\n\t\t         *\n\t\t         * @return {Object} An object with encrypt and decrypt shortcut functions.\n\t\t         *\n\t\t         * @static\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var AES = CryptoJS.lib.Cipher._createHelper(CryptoJS.algo.AES);\n\t\t         */\n\t\t        _createHelper: (function () {\n\t\t            function selectCipherStrategy(key) {\n\t\t                if (typeof key == 'string') {\n\t\t                    return PasswordBasedCipher;\n\t\t                } else {\n\t\t                    return SerializableCipher;\n\t\t                }\n\t\t            }\n\t\n\t\t            return function (cipher) {\n\t\t                return {\n\t\t                    encrypt: function (message, key, cfg) {\n\t\t                        return selectCipherStrategy(key).encrypt(cipher, message, key, cfg);\n\t\t                    },\n\t\n\t\t                    decrypt: function (ciphertext, key, cfg) {\n\t\t                        return selectCipherStrategy(key).decrypt(cipher, ciphertext, key, cfg);\n\t\t                    }\n\t\t                };\n\t\t            };\n\t\t        }())\n\t\t    });\n\t\n\t\t    /**\n\t\t     * Abstract base stream cipher template.\n\t\t     *\n\t\t     * @property {number} blockSize The number of 32-bit words this cipher operates on. Default: 1 (32 bits)\n\t\t     */\n\t\t    var StreamCipher = C_lib.StreamCipher = Cipher.extend({\n\t\t        _doFinalize: function () {\n\t\t            // Process partial blocks\n\t\t            var finalProcessedBlocks = this._process(!!'flush');\n\t\n\t\t            return finalProcessedBlocks;\n\t\t        },\n\t\n\t\t        blockSize: 1\n\t\t    });\n\t\n\t\t    /**\n\t\t     * Mode namespace.\n\t\t     */\n\t\t    var C_mode = C.mode = {};\n\t\n\t\t    /**\n\t\t     * Abstract base block cipher mode template.\n\t\t     */\n\t\t    var BlockCipherMode = C_lib.BlockCipherMode = Base.extend({\n\t\t        /**\n\t\t         * Creates this mode for encryption.\n\t\t         *\n\t\t         * @param {Cipher} cipher A block cipher instance.\n\t\t         * @param {Array} iv The IV words.\n\t\t         *\n\t\t         * @static\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var mode = CryptoJS.mode.CBC.createEncryptor(cipher, iv.words);\n\t\t         */\n\t\t        createEncryptor: function (cipher, iv) {\n\t\t            return this.Encryptor.create(cipher, iv);\n\t\t        },\n\t\n\t\t        /**\n\t\t         * Creates this mode for decryption.\n\t\t         *\n\t\t         * @param {Cipher} cipher A block cipher instance.\n\t\t         * @param {Array} iv The IV words.\n\t\t         *\n\t\t         * @static\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var mode = CryptoJS.mode.CBC.createDecryptor(cipher, iv.words);\n\t\t         */\n\t\t        createDecryptor: function (cipher, iv) {\n\t\t            return this.Decryptor.create(cipher, iv);\n\t\t        },\n\t\n\t\t        /**\n\t\t         * Initializes a newly created mode.\n\t\t         *\n\t\t         * @param {Cipher} cipher A block cipher instance.\n\t\t         * @param {Array} iv The IV words.\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var mode = CryptoJS.mode.CBC.Encryptor.create(cipher, iv.words);\n\t\t         */\n\t\t        init: function (cipher, iv) {\n\t\t            this._cipher = cipher;\n\t\t            this._iv = iv;\n\t\t        }\n\t\t    });\n\t\n\t\t    /**\n\t\t     * Cipher Block Chaining mode.\n\t\t     */\n\t\t    var CBC = C_mode.CBC = (function () {\n\t\t        /**\n\t\t         * Abstract base CBC mode.\n\t\t         */\n\t\t        var CBC = BlockCipherMode.extend();\n\t\n\t\t        /**\n\t\t         * CBC encryptor.\n\t\t         */\n\t\t        CBC.Encryptor = CBC.extend({\n\t\t            /**\n\t\t             * Processes the data block at offset.\n\t\t             *\n\t\t             * @param {Array} words The data words to operate on.\n\t\t             * @param {number} offset The offset where the block starts.\n\t\t             *\n\t\t             * @example\n\t\t             *\n\t\t             *     mode.processBlock(data.words, offset);\n\t\t             */\n\t\t            processBlock: function (words, offset) {\n\t\t                // Shortcuts\n\t\t                var cipher = this._cipher;\n\t\t                var blockSize = cipher.blockSize;\n\t\n\t\t                // XOR and encrypt\n\t\t                xorBlock.call(this, words, offset, blockSize);\n\t\t                cipher.encryptBlock(words, offset);\n\t\n\t\t                // Remember this block to use with next block\n\t\t                this._prevBlock = words.slice(offset, offset + blockSize);\n\t\t            }\n\t\t        });\n\t\n\t\t        /**\n\t\t         * CBC decryptor.\n\t\t         */\n\t\t        CBC.Decryptor = CBC.extend({\n\t\t            /**\n\t\t             * Processes the data block at offset.\n\t\t             *\n\t\t             * @param {Array} words The data words to operate on.\n\t\t             * @param {number} offset The offset where the block starts.\n\t\t             *\n\t\t             * @example\n\t\t             *\n\t\t             *     mode.processBlock(data.words, offset);\n\t\t             */\n\t\t            processBlock: function (words, offset) {\n\t\t                // Shortcuts\n\t\t                var cipher = this._cipher;\n\t\t                var blockSize = cipher.blockSize;\n\t\n\t\t                // Remember this block to use with next block\n\t\t                var thisBlock = words.slice(offset, offset + blockSize);\n\t\n\t\t                // Decrypt and XOR\n\t\t                cipher.decryptBlock(words, offset);\n\t\t                xorBlock.call(this, words, offset, blockSize);\n\t\n\t\t                // This block becomes the previous block\n\t\t                this._prevBlock = thisBlock;\n\t\t            }\n\t\t        });\n\t\n\t\t        function xorBlock(words, offset, blockSize) {\n\t\t            // Shortcut\n\t\t            var iv = this._iv;\n\t\n\t\t            // Choose mixing block\n\t\t            if (iv) {\n\t\t                var block = iv;\n\t\n\t\t                // Remove IV for subsequent blocks\n\t\t                this._iv = undefined;\n\t\t            } else {\n\t\t                var block = this._prevBlock;\n\t\t            }\n\t\n\t\t            // XOR blocks\n\t\t            for (var i = 0; i < blockSize; i++) {\n\t\t                words[offset + i] ^= block[i];\n\t\t            }\n\t\t        }\n\t\n\t\t        return CBC;\n\t\t    }());\n\t\n\t\t    /**\n\t\t     * Padding namespace.\n\t\t     */\n\t\t    var C_pad = C.pad = {};\n\t\n\t\t    /**\n\t\t     * PKCS #5/7 padding strategy.\n\t\t     */\n\t\t    var Pkcs7 = C_pad.Pkcs7 = {\n\t\t        /**\n\t\t         * Pads data using the algorithm defined in PKCS #5/7.\n\t\t         *\n\t\t         * @param {WordArray} data The data to pad.\n\t\t         * @param {number} blockSize The multiple that the data should be padded to.\n\t\t         *\n\t\t         * @static\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     CryptoJS.pad.Pkcs7.pad(wordArray, 4);\n\t\t         */\n\t\t        pad: function (data, blockSize) {\n\t\t            // Shortcut\n\t\t            var blockSizeBytes = blockSize * 4;\n\t\n\t\t            // Count padding bytes\n\t\t            var nPaddingBytes = blockSizeBytes - data.sigBytes % blockSizeBytes;\n\t\n\t\t            // Create padding word\n\t\t            var paddingWord = (nPaddingBytes << 24) | (nPaddingBytes << 16) | (nPaddingBytes << 8) | nPaddingBytes;\n\t\n\t\t            // Create padding\n\t\t            var paddingWords = [];\n\t\t            for (var i = 0; i < nPaddingBytes; i += 4) {\n\t\t                paddingWords.push(paddingWord);\n\t\t            }\n\t\t            var padding = WordArray.create(paddingWords, nPaddingBytes);\n\t\n\t\t            // Add padding\n\t\t            data.concat(padding);\n\t\t        },\n\t\n\t\t        /**\n\t\t         * Unpads data that had been padded using the algorithm defined in PKCS #5/7.\n\t\t         *\n\t\t         * @param {WordArray} data The data to unpad.\n\t\t         *\n\t\t         * @static\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     CryptoJS.pad.Pkcs7.unpad(wordArray);\n\t\t         */\n\t\t        unpad: function (data) {\n\t\t            // Get number of padding bytes from last byte\n\t\t            var nPaddingBytes = data.words[(data.sigBytes - 1) >>> 2] & 0xff;\n\t\n\t\t            // Remove padding\n\t\t            data.sigBytes -= nPaddingBytes;\n\t\t        }\n\t\t    };\n\t\n\t\t    /**\n\t\t     * Abstract base block cipher template.\n\t\t     *\n\t\t     * @property {number} blockSize The number of 32-bit words this cipher operates on. Default: 4 (128 bits)\n\t\t     */\n\t\t    var BlockCipher = C_lib.BlockCipher = Cipher.extend({\n\t\t        /**\n\t\t         * Configuration options.\n\t\t         *\n\t\t         * @property {Mode} mode The block mode to use. Default: CBC\n\t\t         * @property {Padding} padding The padding strategy to use. Default: Pkcs7\n\t\t         */\n\t\t        cfg: Cipher.cfg.extend({\n\t\t            mode: CBC,\n\t\t            padding: Pkcs7\n\t\t        }),\n\t\n\t\t        reset: function () {\n\t\t            // Reset cipher\n\t\t            Cipher.reset.call(this);\n\t\n\t\t            // Shortcuts\n\t\t            var cfg = this.cfg;\n\t\t            var iv = cfg.iv;\n\t\t            var mode = cfg.mode;\n\t\n\t\t            // Reset block mode\n\t\t            if (this._xformMode == this._ENC_XFORM_MODE) {\n\t\t                var modeCreator = mode.createEncryptor;\n\t\t            } else /* if (this._xformMode == this._DEC_XFORM_MODE) */ {\n\t\t                var modeCreator = mode.createDecryptor;\n\t\n\t\t                // Keep at least one block in the buffer for unpadding\n\t\t                this._minBufferSize = 1;\n\t\t            }\n\t\t            this._mode = modeCreator.call(mode, this, iv && iv.words);\n\t\t        },\n\t\n\t\t        _doProcessBlock: function (words, offset) {\n\t\t            this._mode.processBlock(words, offset);\n\t\t        },\n\t\n\t\t        _doFinalize: function () {\n\t\t            // Shortcut\n\t\t            var padding = this.cfg.padding;\n\t\n\t\t            // Finalize\n\t\t            if (this._xformMode == this._ENC_XFORM_MODE) {\n\t\t                // Pad data\n\t\t                padding.pad(this._data, this.blockSize);\n\t\n\t\t                // Process final blocks\n\t\t                var finalProcessedBlocks = this._process(!!'flush');\n\t\t            } else /* if (this._xformMode == this._DEC_XFORM_MODE) */ {\n\t\t                // Process final blocks\n\t\t                var finalProcessedBlocks = this._process(!!'flush');\n\t\n\t\t                // Unpad data\n\t\t                padding.unpad(finalProcessedBlocks);\n\t\t            }\n\t\n\t\t            return finalProcessedBlocks;\n\t\t        },\n\t\n\t\t        blockSize: 128/32\n\t\t    });\n\t\n\t\t    /**\n\t\t     * A collection of cipher parameters.\n\t\t     *\n\t\t     * @property {WordArray} ciphertext The raw ciphertext.\n\t\t     * @property {WordArray} key The key to this ciphertext.\n\t\t     * @property {WordArray} iv The IV used in the ciphering operation.\n\t\t     * @property {WordArray} salt The salt used with a key derivation function.\n\t\t     * @property {Cipher} algorithm The cipher algorithm.\n\t\t     * @property {Mode} mode The block mode used in the ciphering operation.\n\t\t     * @property {Padding} padding The padding scheme used in the ciphering operation.\n\t\t     * @property {number} blockSize The block size of the cipher.\n\t\t     * @property {Format} formatter The default formatting strategy to convert this cipher params object to a string.\n\t\t     */\n\t\t    var CipherParams = C_lib.CipherParams = Base.extend({\n\t\t        /**\n\t\t         * Initializes a newly created cipher params object.\n\t\t         *\n\t\t         * @param {Object} cipherParams An object with any of the possible cipher parameters.\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var cipherParams = CryptoJS.lib.CipherParams.create({\n\t\t         *         ciphertext: ciphertextWordArray,\n\t\t         *         key: keyWordArray,\n\t\t         *         iv: ivWordArray,\n\t\t         *         salt: saltWordArray,\n\t\t         *         algorithm: CryptoJS.algo.AES,\n\t\t         *         mode: CryptoJS.mode.CBC,\n\t\t         *         padding: CryptoJS.pad.PKCS7,\n\t\t         *         blockSize: 4,\n\t\t         *         formatter: CryptoJS.format.OpenSSL\n\t\t         *     });\n\t\t         */\n\t\t        init: function (cipherParams) {\n\t\t            this.mixIn(cipherParams);\n\t\t        },\n\t\n\t\t        /**\n\t\t         * Converts this cipher params object to a string.\n\t\t         *\n\t\t         * @param {Format} formatter (Optional) The formatting strategy to use.\n\t\t         *\n\t\t         * @return {string} The stringified cipher params.\n\t\t         *\n\t\t         * @throws Error If neither the formatter nor the default formatter is set.\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var string = cipherParams + '';\n\t\t         *     var string = cipherParams.toString();\n\t\t         *     var string = cipherParams.toString(CryptoJS.format.OpenSSL);\n\t\t         */\n\t\t        toString: function (formatter) {\n\t\t            return (formatter || this.formatter).stringify(this);\n\t\t        }\n\t\t    });\n\t\n\t\t    /**\n\t\t     * Format namespace.\n\t\t     */\n\t\t    var C_format = C.format = {};\n\t\n\t\t    /**\n\t\t     * OpenSSL formatting strategy.\n\t\t     */\n\t\t    var OpenSSLFormatter = C_format.OpenSSL = {\n\t\t        /**\n\t\t         * Converts a cipher params object to an OpenSSL-compatible string.\n\t\t         *\n\t\t         * @param {CipherParams} cipherParams The cipher params object.\n\t\t         *\n\t\t         * @return {string} The OpenSSL-compatible string.\n\t\t         *\n\t\t         * @static\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var openSSLString = CryptoJS.format.OpenSSL.stringify(cipherParams);\n\t\t         */\n\t\t        stringify: function (cipherParams) {\n\t\t            // Shortcuts\n\t\t            var ciphertext = cipherParams.ciphertext;\n\t\t            var salt = cipherParams.salt;\n\t\n\t\t            // Format\n\t\t            if (salt) {\n\t\t                var wordArray = WordArray.create([0x53616c74, 0x65645f5f]).concat(salt).concat(ciphertext);\n\t\t            } else {\n\t\t                var wordArray = ciphertext;\n\t\t            }\n\t\n\t\t            return wordArray.toString(Base64);\n\t\t        },\n\t\n\t\t        /**\n\t\t         * Converts an OpenSSL-compatible string to a cipher params object.\n\t\t         *\n\t\t         * @param {string} openSSLStr The OpenSSL-compatible string.\n\t\t         *\n\t\t         * @return {CipherParams} The cipher params object.\n\t\t         *\n\t\t         * @static\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var cipherParams = CryptoJS.format.OpenSSL.parse(openSSLString);\n\t\t         */\n\t\t        parse: function (openSSLStr) {\n\t\t            // Parse base64\n\t\t            var ciphertext = Base64.parse(openSSLStr);\n\t\n\t\t            // Shortcut\n\t\t            var ciphertextWords = ciphertext.words;\n\t\n\t\t            // Test for salt\n\t\t            if (ciphertextWords[0] == 0x53616c74 && ciphertextWords[1] == 0x65645f5f) {\n\t\t                // Extract salt\n\t\t                var salt = WordArray.create(ciphertextWords.slice(2, 4));\n\t\n\t\t                // Remove salt from ciphertext\n\t\t                ciphertextWords.splice(0, 4);\n\t\t                ciphertext.sigBytes -= 16;\n\t\t            }\n\t\n\t\t            return CipherParams.create({ ciphertext: ciphertext, salt: salt });\n\t\t        }\n\t\t    };\n\t\n\t\t    /**\n\t\t     * A cipher wrapper that returns ciphertext as a serializable cipher params object.\n\t\t     */\n\t\t    var SerializableCipher = C_lib.SerializableCipher = Base.extend({\n\t\t        /**\n\t\t         * Configuration options.\n\t\t         *\n\t\t         * @property {Formatter} format The formatting strategy to convert cipher param objects to and from a string. Default: OpenSSL\n\t\t         */\n\t\t        cfg: Base.extend({\n\t\t            format: OpenSSLFormatter\n\t\t        }),\n\t\n\t\t        /**\n\t\t         * Encrypts a message.\n\t\t         *\n\t\t         * @param {Cipher} cipher The cipher algorithm to use.\n\t\t         * @param {WordArray|string} message The message to encrypt.\n\t\t         * @param {WordArray} key The key.\n\t\t         * @param {Object} cfg (Optional) The configuration options to use for this operation.\n\t\t         *\n\t\t         * @return {CipherParams} A cipher params object.\n\t\t         *\n\t\t         * @static\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var ciphertextParams = CryptoJS.lib.SerializableCipher.encrypt(CryptoJS.algo.AES, message, key);\n\t\t         *     var ciphertextParams = CryptoJS.lib.SerializableCipher.encrypt(CryptoJS.algo.AES, message, key, { iv: iv });\n\t\t         *     var ciphertextParams = CryptoJS.lib.SerializableCipher.encrypt(CryptoJS.algo.AES, message, key, { iv: iv, format: CryptoJS.format.OpenSSL });\n\t\t         */\n\t\t        encrypt: function (cipher, message, key, cfg) {\n\t\t            // Apply config defaults\n\t\t            cfg = this.cfg.extend(cfg);\n\t\n\t\t            // Encrypt\n\t\t            var encryptor = cipher.createEncryptor(key, cfg);\n\t\t            var ciphertext = encryptor.finalize(message);\n\t\n\t\t            // Shortcut\n\t\t            var cipherCfg = encryptor.cfg;\n\t\n\t\t            // Create and return serializable cipher params\n\t\t            return CipherParams.create({\n\t\t                ciphertext: ciphertext,\n\t\t                key: key,\n\t\t                iv: cipherCfg.iv,\n\t\t                algorithm: cipher,\n\t\t                mode: cipherCfg.mode,\n\t\t                padding: cipherCfg.padding,\n\t\t                blockSize: cipher.blockSize,\n\t\t                formatter: cfg.format\n\t\t            });\n\t\t        },\n\t\n\t\t        /**\n\t\t         * Decrypts serialized ciphertext.\n\t\t         *\n\t\t         * @param {Cipher} cipher The cipher algorithm to use.\n\t\t         * @param {CipherParams|string} ciphertext The ciphertext to decrypt.\n\t\t         * @param {WordArray} key The key.\n\t\t         * @param {Object} cfg (Optional) The configuration options to use for this operation.\n\t\t         *\n\t\t         * @return {WordArray} The plaintext.\n\t\t         *\n\t\t         * @static\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var plaintext = CryptoJS.lib.SerializableCipher.decrypt(CryptoJS.algo.AES, formattedCiphertext, key, { iv: iv, format: CryptoJS.format.OpenSSL });\n\t\t         *     var plaintext = CryptoJS.lib.SerializableCipher.decrypt(CryptoJS.algo.AES, ciphertextParams, key, { iv: iv, format: CryptoJS.format.OpenSSL });\n\t\t         */\n\t\t        decrypt: function (cipher, ciphertext, key, cfg) {\n\t\t            // Apply config defaults\n\t\t            cfg = this.cfg.extend(cfg);\n\t\n\t\t            // Convert string to CipherParams\n\t\t            ciphertext = this._parse(ciphertext, cfg.format);\n\t\n\t\t            // Decrypt\n\t\t            var plaintext = cipher.createDecryptor(key, cfg).finalize(ciphertext.ciphertext);\n\t\n\t\t            return plaintext;\n\t\t        },\n\t\n\t\t        /**\n\t\t         * Converts serialized ciphertext to CipherParams,\n\t\t         * else assumed CipherParams already and returns ciphertext unchanged.\n\t\t         *\n\t\t         * @param {CipherParams|string} ciphertext The ciphertext.\n\t\t         * @param {Formatter} format The formatting strategy to use to parse serialized ciphertext.\n\t\t         *\n\t\t         * @return {CipherParams} The unserialized ciphertext.\n\t\t         *\n\t\t         * @static\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var ciphertextParams = CryptoJS.lib.SerializableCipher._parse(ciphertextStringOrParams, format);\n\t\t         */\n\t\t        _parse: function (ciphertext, format) {\n\t\t            if (typeof ciphertext == 'string') {\n\t\t                return format.parse(ciphertext, this);\n\t\t            } else {\n\t\t                return ciphertext;\n\t\t            }\n\t\t        }\n\t\t    });\n\t\n\t\t    /**\n\t\t     * Key derivation function namespace.\n\t\t     */\n\t\t    var C_kdf = C.kdf = {};\n\t\n\t\t    /**\n\t\t     * OpenSSL key derivation function.\n\t\t     */\n\t\t    var OpenSSLKdf = C_kdf.OpenSSL = {\n\t\t        /**\n\t\t         * Derives a key and IV from a password.\n\t\t         *\n\t\t         * @param {string} password The password to derive from.\n\t\t         * @param {number} keySize The size in words of the key to generate.\n\t\t         * @param {number} ivSize The size in words of the IV to generate.\n\t\t         * @param {WordArray|string} salt (Optional) A 64-bit salt to use. If omitted, a salt will be generated randomly.\n\t\t         *\n\t\t         * @return {CipherParams} A cipher params object with the key, IV, and salt.\n\t\t         *\n\t\t         * @static\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var derivedParams = CryptoJS.kdf.OpenSSL.execute('Password', 256/32, 128/32);\n\t\t         *     var derivedParams = CryptoJS.kdf.OpenSSL.execute('Password', 256/32, 128/32, 'saltsalt');\n\t\t         */\n\t\t        execute: function (password, keySize, ivSize, salt) {\n\t\t            // Generate random salt\n\t\t            if (!salt) {\n\t\t                salt = WordArray.random(64/8);\n\t\t            }\n\t\n\t\t            // Derive key and IV\n\t\t            var key = EvpKDF.create({ keySize: keySize + ivSize }).compute(password, salt);\n\t\n\t\t            // Separate key and IV\n\t\t            var iv = WordArray.create(key.words.slice(keySize), ivSize * 4);\n\t\t            key.sigBytes = keySize * 4;\n\t\n\t\t            // Return params\n\t\t            return CipherParams.create({ key: key, iv: iv, salt: salt });\n\t\t        }\n\t\t    };\n\t\n\t\t    /**\n\t\t     * A serializable cipher wrapper that derives the key from a password,\n\t\t     * and returns ciphertext as a serializable cipher params object.\n\t\t     */\n\t\t    var PasswordBasedCipher = C_lib.PasswordBasedCipher = SerializableCipher.extend({\n\t\t        /**\n\t\t         * Configuration options.\n\t\t         *\n\t\t         * @property {KDF} kdf The key derivation function to use to generate a key and IV from a password. Default: OpenSSL\n\t\t         */\n\t\t        cfg: SerializableCipher.cfg.extend({\n\t\t            kdf: OpenSSLKdf\n\t\t        }),\n\t\n\t\t        /**\n\t\t         * Encrypts a message using a password.\n\t\t         *\n\t\t         * @param {Cipher} cipher The cipher algorithm to use.\n\t\t         * @param {WordArray|string} message The message to encrypt.\n\t\t         * @param {string} password The password.\n\t\t         * @param {Object} cfg (Optional) The configuration options to use for this operation.\n\t\t         *\n\t\t         * @return {CipherParams} A cipher params object.\n\t\t         *\n\t\t         * @static\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var ciphertextParams = CryptoJS.lib.PasswordBasedCipher.encrypt(CryptoJS.algo.AES, message, 'password');\n\t\t         *     var ciphertextParams = CryptoJS.lib.PasswordBasedCipher.encrypt(CryptoJS.algo.AES, message, 'password', { format: CryptoJS.format.OpenSSL });\n\t\t         */\n\t\t        encrypt: function (cipher, message, password, cfg) {\n\t\t            // Apply config defaults\n\t\t            cfg = this.cfg.extend(cfg);\n\t\n\t\t            // Derive key and other params\n\t\t            var derivedParams = cfg.kdf.execute(password, cipher.keySize, cipher.ivSize);\n\t\n\t\t            // Add IV to config\n\t\t            cfg.iv = derivedParams.iv;\n\t\n\t\t            // Encrypt\n\t\t            var ciphertext = SerializableCipher.encrypt.call(this, cipher, message, derivedParams.key, cfg);\n\t\n\t\t            // Mix in derived params\n\t\t            ciphertext.mixIn(derivedParams);\n\t\n\t\t            return ciphertext;\n\t\t        },\n\t\n\t\t        /**\n\t\t         * Decrypts serialized ciphertext using a password.\n\t\t         *\n\t\t         * @param {Cipher} cipher The cipher algorithm to use.\n\t\t         * @param {CipherParams|string} ciphertext The ciphertext to decrypt.\n\t\t         * @param {string} password The password.\n\t\t         * @param {Object} cfg (Optional) The configuration options to use for this operation.\n\t\t         *\n\t\t         * @return {WordArray} The plaintext.\n\t\t         *\n\t\t         * @static\n\t\t         *\n\t\t         * @example\n\t\t         *\n\t\t         *     var plaintext = CryptoJS.lib.PasswordBasedCipher.decrypt(CryptoJS.algo.AES, formattedCiphertext, 'password', { format: CryptoJS.format.OpenSSL });\n\t\t         *     var plaintext = CryptoJS.lib.PasswordBasedCipher.decrypt(CryptoJS.algo.AES, ciphertextParams, 'password', { format: CryptoJS.format.OpenSSL });\n\t\t         */\n\t\t        decrypt: function (cipher, ciphertext, password, cfg) {\n\t\t            // Apply config defaults\n\t\t            cfg = this.cfg.extend(cfg);\n\t\n\t\t            // Convert string to CipherParams\n\t\t            ciphertext = this._parse(ciphertext, cfg.format);\n\t\n\t\t            // Derive key and other params\n\t\t            var derivedParams = cfg.kdf.execute(password, cipher.keySize, cipher.ivSize, ciphertext.salt);\n\t\n\t\t            // Add IV to config\n\t\t            cfg.iv = derivedParams.iv;\n\t\n\t\t            // Decrypt\n\t\t            var plaintext = SerializableCipher.decrypt.call(this, cipher, ciphertext, derivedParams.key, cfg);\n\t\n\t\t            return plaintext;\n\t\t        }\n\t\t    });\n\t\t}());\n\t\n\t\n\t}));\n\n/***/ },\n/* 16 */\n/***/ function(module, exports, __webpack_require__) {\n\n\t;(function (root, factory, undef) {\n\t\tif (true) {\n\t\t\t// CommonJS\n\t\t\tmodule.exports = exports = factory(__webpack_require__(5), __webpack_require__(12), __webpack_require__(13), __webpack_require__(14), __webpack_require__(15));\n\t\t}\n\t\telse {}\n\t}(this, function (CryptoJS) {\n\t\n\t\t(function () {\n\t\t    // Shortcuts\n\t\t    var C = CryptoJS;\n\t\t    var C_lib = C.lib;\n\t\t    var WordArray = C_lib.WordArray;\n\t\t    var BlockCipher = C_lib.BlockCipher;\n\t\t    var C_algo = C.algo;\n\t\n\t\t    // Permuted Choice 1 constants\n\t\t    var PC1 = [\n\t\t        57, 49, 41, 33, 25, 17, 9,  1,\n\t\t        58, 50, 42, 34, 26, 18, 10, 2,\n\t\t        59, 51, 43, 35, 27, 19, 11, 3,\n\t\t        60, 52, 44, 36, 63, 55, 47, 39,\n\t\t        31, 23, 15, 7,  62, 54, 46, 38,\n\t\t        30, 22, 14, 6,  61, 53, 45, 37,\n\t\t        29, 21, 13, 5,  28, 20, 12, 4\n\t\t    ];\n\t\n\t\t    // Permuted Choice 2 constants\n\t\t    var PC2 = [\n\t\t        14, 17, 11, 24, 1,  5,\n\t\t        3,  28, 15, 6,  21, 10,\n\t\t        23, 19, 12, 4,  26, 8,\n\t\t        16, 7,  27, 20, 13, 2,\n\t\t        41, 52, 31, 37, 47, 55,\n\t\t        30, 40, 51, 45, 33, 48,\n\t\t        44, 49, 39, 56, 34, 53,\n\t\t        46, 42, 50, 36, 29, 32\n\t\t    ];\n\t\n\t\t    // Cumulative bit shift constants\n\t\t    var BIT_SHIFTS = [1,  2,  4,  6,  8,  10, 12, 14, 15, 17, 19, 21, 23, 25, 27, 28];\n\t\n\t\t    // SBOXes and round permutation constants\n\t\t    var SBOX_P = [\n\t\t        {\n\t\t            0x0: 0x808200,\n\t\t            0x10000000: 0x8000,\n\t\t            0x20000000: 0x808002,\n\t\t            0x30000000: 0x2,\n\t\t            0x40000000: 0x200,\n\t\t            0x50000000: 0x808202,\n\t\t            0x60000000: 0x800202,\n\t\t            0x70000000: 0x800000,\n\t\t            0x80000000: 0x202,\n\t\t            0x90000000: 0x800200,\n\t\t            0xa0000000: 0x8200,\n\t\t            0xb0000000: 0x808000,\n\t\t            0xc0000000: 0x8002,\n\t\t            0xd0000000: 0x800002,\n\t\t            0xe0000000: 0x0,\n\t\t            0xf0000000: 0x8202,\n\t\t            0x8000000: 0x0,\n\t\t            0x18000000: 0x808202,\n\t\t            0x28000000: 0x8202,\n\t\t            0x38000000: 0x8000,\n\t\t            0x48000000: 0x808200,\n\t\t            0x58000000: 0x200,\n\t\t            0x68000000: 0x808002,\n\t\t            0x78000000: 0x2,\n\t\t            0x88000000: 0x800200,\n\t\t            0x98000000: 0x8200,\n\t\t            0xa8000000: 0x808000,\n\t\t            0xb8000000: 0x800202,\n\t\t            0xc8000000: 0x800002,\n\t\t            0xd8000000: 0x8002,\n\t\t            0xe8000000: 0x202,\n\t\t            0xf8000000: 0x800000,\n\t\t            0x1: 0x8000,\n\t\t            0x10000001: 0x2,\n\t\t            0x20000001: 0x808200,\n\t\t            0x30000001: 0x800000,\n\t\t            0x40000001: 0x808002,\n\t\t            0x50000001: 0x8200,\n\t\t            0x60000001: 0x200,\n\t\t            0x70000001: 0x800202,\n\t\t            0x80000001: 0x808202,\n\t\t            0x90000001: 0x808000,\n\t\t            0xa0000001: 0x800002,\n\t\t            0xb0000001: 0x8202,\n\t\t            0xc0000001: 0x202,\n\t\t            0xd0000001: 0x800200,\n\t\t            0xe0000001: 0x8002,\n\t\t            0xf0000001: 0x0,\n\t\t            0x8000001: 0x808202,\n\t\t            0x18000001: 0x808000,\n\t\t            0x28000001: 0x800000,\n\t\t            0x38000001: 0x200,\n\t\t            0x48000001: 0x8000,\n\t\t            0x58000001: 0x800002,\n\t\t            0x68000001: 0x2,\n\t\t            0x78000001: 0x8202,\n\t\t            0x88000001: 0x8002,\n\t\t            0x98000001: 0x800202,\n\t\t            0xa8000001: 0x202,\n\t\t            0xb8000001: 0x808200,\n\t\t            0xc8000001: 0x800200,\n\t\t            0xd8000001: 0x0,\n\t\t            0xe8000001: 0x8200,\n\t\t            0xf8000001: 0x808002\n\t\t        },\n\t\t        {\n\t\t            0x0: 0x40084010,\n\t\t            0x1000000: 0x4000,\n\t\t            0x2000000: 0x80000,\n\t\t            0x3000000: 0x40080010,\n\t\t            0x4000000: 0x40000010,\n\t\t            0x5000000: 0x40084000,\n\t\t            0x6000000: 0x40004000,\n\t\t            0x7000000: 0x10,\n\t\t            0x8000000: 0x84000,\n\t\t            0x9000000: 0x40004010,\n\t\t            0xa000000: 0x40000000,\n\t\t            0xb000000: 0x84010,\n\t\t            0xc000000: 0x80010,\n\t\t            0xd000000: 0x0,\n\t\t            0xe000000: 0x4010,\n\t\t            0xf000000: 0x40080000,\n\t\t            0x800000: 0x40004000,\n\t\t            0x1800000: 0x84010,\n\t\t            0x2800000: 0x10,\n\t\t            0x3800000: 0x40004010,\n\t\t            0x4800000: 0x40084010,\n\t\t            0x5800000: 0x40000000,\n\t\t            0x6800000: 0x80000,\n\t\t            0x7800000: 0x40080010,\n\t\t            0x8800000: 0x80010,\n\t\t            0x9800000: 0x0,\n\t\t            0xa800000: 0x4000,\n\t\t            0xb800000: 0x40080000,\n\t\t            0xc800000: 0x40000010,\n\t\t            0xd800000: 0x84000,\n\t\t            0xe800000: 0x40084000,\n\t\t            0xf800000: 0x4010,\n\t\t            0x10000000: 0x0,\n\t\t            0x11000000: 0x40080010,\n\t\t            0x12000000: 0x40004010,\n\t\t            0x13000000: 0x40084000,\n\t\t            0x14000000: 0x40080000,\n\t\t            0x15000000: 0x10,\n\t\t            0x16000000: 0x84010,\n\t\t            0x17000000: 0x4000,\n\t\t            0x18000000: 0x4010,\n\t\t            0x19000000: 0x80000,\n\t\t            0x1a000000: 0x80010,\n\t\t            0x1b000000: 0x40000010,\n\t\t            0x1c000000: 0x84000,\n\t\t            0x1d000000: 0x40004000,\n\t\t            0x1e000000: 0x40000000,\n\t\t            0x1f000000: 0x40084010,\n\t\t            0x10800000: 0x84010,\n\t\t            0x11800000: 0x80000,\n\t\t            0x12800000: 0x40080000,\n\t\t            0x13800000: 0x4000,\n\t\t            0x14800000: 0x40004000,\n\t\t            0x15800000: 0x40084010,\n\t\t            0x16800000: 0x10,\n\t\t            0x17800000: 0x40000000,\n\t\t            0x18800000: 0x40084000,\n\t\t            0x19800000: 0x40000010,\n\t\t            0x1a800000: 0x40004010,\n\t\t            0x1b800000: 0x80010,\n\t\t            0x1c800000: 0x0,\n\t\t            0x1d800000: 0x4010,\n\t\t            0x1e800000: 0x40080010,\n\t\t            0x1f800000: 0x84000\n\t\t        },\n\t\t        {\n\t\t            0x0: 0x104,\n\t\t            0x100000: 0x0,\n\t\t            0x200000: 0x4000100,\n\t\t            0x300000: 0x10104,\n\t\t            0x400000: 0x10004,\n\t\t            0x500000: 0x4000004,\n\t\t            0x600000: 0x4010104,\n\t\t            0x700000: 0x4010000,\n\t\t            0x800000: 0x4000000,\n\t\t            0x900000: 0x4010100,\n\t\t            0xa00000: 0x10100,\n\t\t            0xb00000: 0x4010004,\n\t\t            0xc00000: 0x4000104,\n\t\t            0xd00000: 0x10000,\n\t\t            0xe00000: 0x4,\n\t\t            0xf00000: 0x100,\n\t\t            0x80000: 0x4010100,\n\t\t            0x180000: 0x4010004,\n\t\t            0x280000: 0x0,\n\t\t            0x380000: 0x4000100,\n\t\t            0x480000: 0x4000004,\n\t\t            0x580000: 0x10000,\n\t\t            0x680000: 0x10004,\n\t\t            0x780000: 0x104,\n\t\t            0x880000: 0x4,\n\t\t            0x980000: 0x100,\n\t\t            0xa80000: 0x4010000,\n\t\t            0xb80000: 0x10104,\n\t\t            0xc80000: 0x10100,\n\t\t            0xd80000: 0x4000104,\n\t\t            0xe80000: 0x4010104,\n\t\t            0xf80000: 0x4000000,\n\t\t            0x1000000: 0x4010100,\n\t\t            0x1100000: 0x10004,\n\t\t            0x1200000: 0x10000,\n\t\t            0x1300000: 0x4000100,\n\t\t            0x1400000: 0x100,\n\t\t            0x1500000: 0x4010104,\n\t\t            0x1600000: 0x4000004,\n\t\t            0x1700000: 0x0,\n\t\t            0x1800000: 0x4000104,\n\t\t            0x1900000: 0x4000000,\n\t\t            0x1a00000: 0x4,\n\t\t            0x1b00000: 0x10100,\n\t\t            0x1c00000: 0x4010000,\n\t\t            0x1d00000: 0x104,\n\t\t            0x1e00000: 0x10104,\n\t\t            0x1f00000: 0x4010004,\n\t\t            0x1080000: 0x4000000,\n\t\t            0x1180000: 0x104,\n\t\t            0x1280000: 0x4010100,\n\t\t            0x1380000: 0x0,\n\t\t            0x1480000: 0x10004,\n\t\t            0x1580000: 0x4000100,\n\t\t            0x1680000: 0x100,\n\t\t            0x1780000: 0x4010004,\n\t\t            0x1880000: 0x10000,\n\t\t            0x1980000: 0x4010104,\n\t\t            0x1a80000: 0x10104,\n\t\t            0x1b80000: 0x4000004,\n\t\t            0x1c80000: 0x4000104,\n\t\t            0x1d80000: 0x4010000,\n\t\t            0x1e80000: 0x4,\n\t\t            0x1f80000: 0x10100\n\t\t        },\n\t\t        {\n\t\t            0x0: 0x80401000,\n\t\t            0x10000: 0x80001040,\n\t\t            0x20000: 0x401040,\n\t\t            0x30000: 0x80400000,\n\t\t            0x40000: 0x0,\n\t\t            0x50000: 0x401000,\n\t\t            0x60000: 0x80000040,\n\t\t            0x70000: 0x400040,\n\t\t            0x80000: 0x80000000,\n\t\t            0x90000: 0x400000,\n\t\t            0xa0000: 0x40,\n\t\t            0xb0000: 0x80001000,\n\t\t            0xc0000: 0x80400040,\n\t\t            0xd0000: 0x1040,\n\t\t            0xe0000: 0x1000,\n\t\t            0xf0000: 0x80401040,\n\t\t            0x8000: 0x80001040,\n\t\t            0x18000: 0x40,\n\t\t            0x28000: 0x80400040,\n\t\t            0x38000: 0x80001000,\n\t\t            0x48000: 0x401000,\n\t\t            0x58000: 0x80401040,\n\t\t            0x68000: 0x0,\n\t\t            0x78000: 0x80400000,\n\t\t            0x88000: 0x1000,\n\t\t            0x98000: 0x80401000,\n\t\t            0xa8000: 0x400000,\n\t\t            0xb8000: 0x1040,\n\t\t            0xc8000: 0x80000000,\n\t\t            0xd8000: 0x400040,\n\t\t            0xe8000: 0x401040,\n\t\t            0xf8000: 0x80000040,\n\t\t            0x100000: 0x400040,\n\t\t            0x110000: 0x401000,\n\t\t            0x120000: 0x80000040,\n\t\t            0x130000: 0x0,\n\t\t            0x140000: 0x1040,\n\t\t            0x150000: 0x80400040,\n\t\t            0x160000: 0x80401000,\n\t\t            0x170000: 0x80001040,\n\t\t            0x180000: 0x80401040,\n\t\t            0x190000: 0x80000000,\n\t\t            0x1a0000: 0x80400000,\n\t\t            0x1b0000: 0x401040,\n\t\t            0x1c0000: 0x80001000,\n\t\t            0x1d0000: 0x400000,\n\t\t            0x1e0000: 0x40,\n\t\t            0x1f0000: 0x1000,\n\t\t            0x108000: 0x80400000,\n\t\t            0x118000: 0x80401040,\n\t\t            0x128000: 0x0,\n\t\t            0x138000: 0x401000,\n\t\t            0x148000: 0x400040,\n\t\t            0x158000: 0x80000000,\n\t\t            0x168000: 0x80001040,\n\t\t            0x178000: 0x40,\n\t\t            0x188000: 0x80000040,\n\t\t            0x198000: 0x1000,\n\t\t            0x1a8000: 0x80001000,\n\t\t            0x1b8000: 0x80400040,\n\t\t            0x1c8000: 0x1040,\n\t\t            0x1d8000: 0x80401000,\n\t\t            0x1e8000: 0x400000,\n\t\t            0x1f8000: 0x401040\n\t\t        },\n\t\t        {\n\t\t            0x0: 0x80,\n\t\t            0x1000: 0x1040000,\n\t\t            0x2000: 0x40000,\n\t\t            0x3000: 0x20000000,\n\t\t            0x4000: 0x20040080,\n\t\t            0x5000: 0x1000080,\n\t\t            0x6000: 0x21000080,\n\t\t            0x7000: 0x40080,\n\t\t            0x8000: 0x1000000,\n\t\t            0x9000: 0x20040000,\n\t\t            0xa000: 0x20000080,\n\t\t            0xb000: 0x21040080,\n\t\t            0xc000: 0x21040000,\n\t\t            0xd000: 0x0,\n\t\t            0xe000: 0x1040080,\n\t\t            0xf000: 0x21000000,\n\t\t            0x800: 0x1040080,\n\t\t            0x1800: 0x21000080,\n\t\t            0x2800: 0x80,\n\t\t            0x3800: 0x1040000,\n\t\t            0x4800: 0x40000,\n\t\t            0x5800: 0x20040080,\n\t\t            0x6800: 0x21040000,\n\t\t            0x7800: 0x20000000,\n\t\t            0x8800: 0x20040000,\n\t\t            0x9800: 0x0,\n\t\t            0xa800: 0x21040080,\n\t\t            0xb800: 0x1000080,\n\t\t            0xc800: 0x20000080,\n\t\t            0xd800: 0x21000000,\n\t\t            0xe800: 0x1000000,\n\t\t            0xf800: 0x40080,\n\t\t            0x10000: 0x40000,\n\t\t            0x11000: 0x80,\n\t\t            0x12000: 0x20000000,\n\t\t            0x13000: 0x21000080,\n\t\t            0x14000: 0x1000080,\n\t\t            0x15000: 0x21040000,\n\t\t            0x16000: 0x20040080,\n\t\t            0x17000: 0x1000000,\n\t\t            0x18000: 0x21040080,\n\t\t            0x19000: 0x21000000,\n\t\t            0x1a000: 0x1040000,\n\t\t            0x1b000: 0x20040000,\n\t\t            0x1c000: 0x40080,\n\t\t            0x1d000: 0x20000080,\n\t\t            0x1e000: 0x0,\n\t\t            0x1f000: 0x1040080,\n\t\t            0x10800: 0x21000080,\n\t\t            0x11800: 0x1000000,\n\t\t            0x12800: 0x1040000,\n\t\t            0x13800: 0x20040080,\n\t\t            0x14800: 0x20000000,\n\t\t            0x15800: 0x1040080,\n\t\t            0x16800: 0x80,\n\t\t            0x17800: 0x21040000,\n\t\t            0x18800: 0x40080,\n\t\t            0x19800: 0x21040080,\n\t\t            0x1a800: 0x0,\n\t\t            0x1b800: 0x21000000,\n\t\t            0x1c800: 0x1000080,\n\t\t            0x1d800: 0x40000,\n\t\t            0x1e800: 0x20040000,\n\t\t            0x1f800: 0x20000080\n\t\t        },\n\t\t        {\n\t\t            0x0: 0x10000008,\n\t\t            0x100: 0x2000,\n\t\t            0x200: 0x10200000,\n\t\t            0x300: 0x10202008,\n\t\t            0x400: 0x10002000,\n\t\t            0x500: 0x200000,\n\t\t            0x600: 0x200008,\n\t\t            0x700: 0x10000000,\n\t\t            0x800: 0x0,\n\t\t            0x900: 0x10002008,\n\t\t            0xa00: 0x202000,\n\t\t            0xb00: 0x8,\n\t\t            0xc00: 0x10200008,\n\t\t            0xd00: 0x202008,\n\t\t            0xe00: 0x2008,\n\t\t            0xf00: 0x10202000,\n\t\t            0x80: 0x10200000,\n\t\t            0x180: 0x10202008,\n\t\t            0x280: 0x8,\n\t\t            0x380: 0x200000,\n\t\t            0x480: 0x202008,\n\t\t            0x580: 0x10000008,\n\t\t            0x680: 0x10002000,\n\t\t            0x780: 0x2008,\n\t\t            0x880: 0x200008,\n\t\t            0x980: 0x2000,\n\t\t            0xa80: 0x10002008,\n\t\t            0xb80: 0x10200008,\n\t\t            0xc80: 0x0,\n\t\t            0xd80: 0x10202000,\n\t\t            0xe80: 0x202000,\n\t\t            0xf80: 0x10000000,\n\t\t            0x1000: 0x10002000,\n\t\t            0x1100: 0x10200008,\n\t\t            0x1200: 0x10202008,\n\t\t            0x1300: 0x2008,\n\t\t            0x1400: 0x200000,\n\t\t            0x1500: 0x10000000,\n\t\t            0x1600: 0x10000008,\n\t\t            0x1700: 0x202000,\n\t\t            0x1800: 0x202008,\n\t\t            0x1900: 0x0,\n\t\t            0x1a00: 0x8,\n\t\t            0x1b00: 0x10200000,\n\t\t            0x1c00: 0x2000,\n\t\t            0x1d00: 0x10002008,\n\t\t            0x1e00: 0x10202000,\n\t\t            0x1f00: 0x200008,\n\t\t            0x1080: 0x8,\n\t\t            0x1180: 0x202000,\n\t\t            0x1280: 0x200000,\n\t\t            0x1380: 0x10000008,\n\t\t            0x1480: 0x10002000,\n\t\t            0x1580: 0x2008,\n\t\t            0x1680: 0x10202008,\n\t\t            0x1780: 0x10200000,\n\t\t            0x1880: 0x10202000,\n\t\t            0x1980: 0x10200008,\n\t\t            0x1a80: 0x2000,\n\t\t            0x1b80: 0x202008,\n\t\t            0x1c80: 0x200008,\n\t\t            0x1d80: 0x0,\n\t\t            0x1e80: 0x10000000,\n\t\t            0x1f80: 0x10002008\n\t\t        },\n\t\t        {\n\t\t            0x0: 0x100000,\n\t\t            0x10: 0x2000401,\n\t\t            0x20: 0x400,\n\t\t            0x30: 0x100401,\n\t\t            0x40: 0x2100401,\n\t\t            0x50: 0x0,\n\t\t            0x60: 0x1,\n\t\t            0x70: 0x2100001,\n\t\t            0x80: 0x2000400,\n\t\t            0x90: 0x100001,\n\t\t            0xa0: 0x2000001,\n\t\t            0xb0: 0x2100400,\n\t\t            0xc0: 0x2100000,\n\t\t            0xd0: 0x401,\n\t\t            0xe0: 0x100400,\n\t\t            0xf0: 0x2000000,\n\t\t            0x8: 0x2100001,\n\t\t            0x18: 0x0,\n\t\t            0x28: 0x2000401,\n\t\t            0x38: 0x2100400,\n\t\t            0x48: 0x100000,\n\t\t            0x58: 0x2000001,\n\t\t            0x68: 0x2000000,\n\t\t            0x78: 0x401,\n\t\t            0x88: 0x100401,\n\t\t            0x98: 0x2000400,\n\t\t            0xa8: 0x2100000,\n\t\t            0xb8: 0x100001,\n\t\t            0xc8: 0x400,\n\t\t            0xd8: 0x2100401,\n\t\t            0xe8: 0x1,\n\t\t            0xf8: 0x100400,\n\t\t            0x100: 0x2000000,\n\t\t            0x110: 0x100000,\n\t\t            0x120: 0x2000401,\n\t\t            0x130: 0x2100001,\n\t\t            0x140: 0x100001,\n\t\t            0x150: 0x2000400,\n\t\t            0x160: 0x2100400,\n\t\t            0x170: 0x100401,\n\t\t            0x180: 0x401,\n\t\t            0x190: 0x2100401,\n\t\t            0x1a0: 0x100400,\n\t\t            0x1b0: 0x1,\n\t\t            0x1c0: 0x0,\n\t\t            0x1d0: 0x2100000,\n\t\t            0x1e0: 0x2000001,\n\t\t            0x1f0: 0x400,\n\t\t            0x108: 0x100400,\n\t\t            0x118: 0x2000401,\n\t\t            0x128: 0x2100001,\n\t\t            0x138: 0x1,\n\t\t            0x148: 0x2000000,\n\t\t            0x158: 0x100000,\n\t\t            0x168: 0x401,\n\t\t            0x178: 0x2100400,\n\t\t            0x188: 0x2000001,\n\t\t            0x198: 0x2100000,\n\t\t            0x1a8: 0x0,\n\t\t            0x1b8: 0x2100401,\n\t\t            0x1c8: 0x100401,\n\t\t            0x1d8: 0x400,\n\t\t            0x1e8: 0x2000400,\n\t\t            0x1f8: 0x100001\n\t\t        },\n\t\t        {\n\t\t            0x0: 0x8000820,\n\t\t            0x1: 0x20000,\n\t\t            0x2: 0x8000000,\n\t\t            0x3: 0x20,\n\t\t            0x4: 0x20020,\n\t\t            0x5: 0x8020820,\n\t\t            0x6: 0x8020800,\n\t\t            0x7: 0x800,\n\t\t            0x8: 0x8020000,\n\t\t            0x9: 0x8000800,\n\t\t            0xa: 0x20800,\n\t\t            0xb: 0x8020020,\n\t\t            0xc: 0x820,\n\t\t            0xd: 0x0,\n\t\t            0xe: 0x8000020,\n\t\t            0xf: 0x20820,\n\t\t            0x80000000: 0x800,\n\t\t            0x80000001: 0x8020820,\n\t\t            0x80000002: 0x8000820,\n\t\t            0x80000003: 0x8000000,\n\t\t            0x80000004: 0x8020000,\n\t\t            0x80000005: 0x20800,\n\t\t            0x80000006: 0x20820,\n\t\t            0x80000007: 0x20,\n\t\t            0x80000008: 0x8000020,\n\t\t            0x80000009: 0x820,\n\t\t            0x8000000a: 0x20020,\n\t\t            0x8000000b: 0x8020800,\n\t\t            0x8000000c: 0x0,\n\t\t            0x8000000d: 0x8020020,\n\t\t            0x8000000e: 0x8000800,\n\t\t            0x8000000f: 0x20000,\n\t\t            0x10: 0x20820,\n\t\t            0x11: 0x8020800,\n\t\t            0x12: 0x20,\n\t\t            0x13: 0x800,\n\t\t            0x14: 0x8000800,\n\t\t            0x15: 0x8000020,\n\t\t            0x16: 0x8020020,\n\t\t            0x17: 0x20000,\n\t\t            0x18: 0x0,\n\t\t            0x19: 0x20020,\n\t\t            0x1a: 0x8020000,\n\t\t            0x1b: 0x8000820,\n\t\t            0x1c: 0x8020820,\n\t\t            0x1d: 0x20800,\n\t\t            0x1e: 0x820,\n\t\t            0x1f: 0x8000000,\n\t\t            0x80000010: 0x20000,\n\t\t            0x80000011: 0x800,\n\t\t            0x80000012: 0x8020020,\n\t\t            0x80000013: 0x20820,\n\t\t            0x80000014: 0x20,\n\t\t            0x80000015: 0x8020000,\n\t\t            0x80000016: 0x8000000,\n\t\t            0x80000017: 0x8000820,\n\t\t            0x80000018: 0x8020820,\n\t\t            0x80000019: 0x8000020,\n\t\t            0x8000001a: 0x8000800,\n\t\t            0x8000001b: 0x0,\n\t\t            0x8000001c: 0x20800,\n\t\t            0x8000001d: 0x820,\n\t\t            0x8000001e: 0x20020,\n\t\t            0x8000001f: 0x8020800\n\t\t        }\n\t\t    ];\n\t\n\t\t    // Masks that select the SBOX input\n\t\t    var SBOX_MASK = [\n\t\t        0xf8000001, 0x1f800000, 0x01f80000, 0x001f8000,\n\t\t        0x0001f800, 0x00001f80, 0x000001f8, 0x8000001f\n\t\t    ];\n\t\n\t\t    /**\n\t\t     * DES block cipher algorithm.\n\t\t     */\n\t\t    var DES = C_algo.DES = BlockCipher.extend({\n\t\t        _doReset: function () {\n\t\t            // Shortcuts\n\t\t            var key = this._key;\n\t\t            var keyWords = key.words;\n\t\n\t\t            // Select 56 bits according to PC1\n\t\t            var keyBits = [];\n\t\t            for (var i = 0; i < 56; i++) {\n\t\t                var keyBitPos = PC1[i] - 1;\n\t\t                keyBits[i] = (keyWords[keyBitPos >>> 5] >>> (31 - keyBitPos % 32)) & 1;\n\t\t            }\n\t\n\t\t            // Assemble 16 subkeys\n\t\t            var subKeys = this._subKeys = [];\n\t\t            for (var nSubKey = 0; nSubKey < 16; nSubKey++) {\n\t\t                // Create subkey\n\t\t                var subKey = subKeys[nSubKey] = [];\n\t\n\t\t                // Shortcut\n\t\t                var bitShift = BIT_SHIFTS[nSubKey];\n\t\n\t\t                // Select 48 bits according to PC2\n\t\t                for (var i = 0; i < 24; i++) {\n\t\t                    // Select from the left 28 key bits\n\t\t                    subKey[(i / 6) | 0] |= keyBits[((PC2[i] - 1) + bitShift) % 28] << (31 - i % 6);\n\t\n\t\t                    // Select from the right 28 key bits\n\t\t                    subKey[4 + ((i / 6) | 0)] |= keyBits[28 + (((PC2[i + 24] - 1) + bitShift) % 28)] << (31 - i % 6);\n\t\t                }\n\t\n\t\t                // Since each subkey is applied to an expanded 32-bit input,\n\t\t                // the subkey can be broken into 8 values scaled to 32-bits,\n\t\t                // which allows the key to be used without expansion\n\t\t                subKey[0] = (subKey[0] << 1) | (subKey[0] >>> 31);\n\t\t                for (var i = 1; i < 7; i++) {\n\t\t                    subKey[i] = subKey[i] >>> ((i - 1) * 4 + 3);\n\t\t                }\n\t\t                subKey[7] = (subKey[7] << 5) | (subKey[7] >>> 27);\n\t\t            }\n\t\n\t\t            // Compute inverse subkeys\n\t\t            var invSubKeys = this._invSubKeys = [];\n\t\t            for (var i = 0; i < 16; i++) {\n\t\t                invSubKeys[i] = subKeys[15 - i];\n\t\t            }\n\t\t        },\n\t\n\t\t        encryptBlock: function (M, offset) {\n\t\t            this._doCryptBlock(M, offset, this._subKeys);\n\t\t        },\n\t\n\t\t        decryptBlock: function (M, offset) {\n\t\t            this._doCryptBlock(M, offset, this._invSubKeys);\n\t\t        },\n\t\n\t\t        _doCryptBlock: function (M, offset, subKeys) {\n\t\t            // Get input\n\t\t            this._lBlock = M[offset];\n\t\t            this._rBlock = M[offset + 1];\n\t\n\t\t            // Initial permutation\n\t\t            exchangeLR.call(this, 4,  0x0f0f0f0f);\n\t\t            exchangeLR.call(this, 16, 0x0000ffff);\n\t\t            exchangeRL.call(this, 2,  0x33333333);\n\t\t            exchangeRL.call(this, 8,  0x00ff00ff);\n\t\t            exchangeLR.call(this, 1,  0x55555555);\n\t\n\t\t            // Rounds\n\t\t            for (var round = 0; round < 16; round++) {\n\t\t                // Shortcuts\n\t\t                var subKey = subKeys[round];\n\t\t                var lBlock = this._lBlock;\n\t\t                var rBlock = this._rBlock;\n\t\n\t\t                // Feistel function\n\t\t                var f = 0;\n\t\t                for (var i = 0; i < 8; i++) {\n\t\t                    f |= SBOX_P[i][((rBlock ^ subKey[i]) & SBOX_MASK[i]) >>> 0];\n\t\t                }\n\t\t                this._lBlock = rBlock;\n\t\t                this._rBlock = lBlock ^ f;\n\t\t            }\n\t\n\t\t            // Undo swap from last round\n\t\t            var t = this._lBlock;\n\t\t            this._lBlock = this._rBlock;\n\t\t            this._rBlock = t;\n\t\n\t\t            // Final permutation\n\t\t            exchangeLR.call(this, 1,  0x55555555);\n\t\t            exchangeRL.call(this, 8,  0x00ff00ff);\n\t\t            exchangeRL.call(this, 2,  0x33333333);\n\t\t            exchangeLR.call(this, 16, 0x0000ffff);\n\t\t            exchangeLR.call(this, 4,  0x0f0f0f0f);\n\t\n\t\t            // Set output\n\t\t            M[offset] = this._lBlock;\n\t\t            M[offset + 1] = this._rBlock;\n\t\t        },\n\t\n\t\t        keySize: 64/32,\n\t\n\t\t        ivSize: 64/32,\n\t\n\t\t        blockSize: 64/32\n\t\t    });\n\t\n\t\t    // Swap bits across the left and right words\n\t\t    function exchangeLR(offset, mask) {\n\t\t        var t = ((this._lBlock >>> offset) ^ this._rBlock) & mask;\n\t\t        this._rBlock ^= t;\n\t\t        this._lBlock ^= t << offset;\n\t\t    }\n\t\n\t\t    function exchangeRL(offset, mask) {\n\t\t        var t = ((this._rBlock >>> offset) ^ this._lBlock) & mask;\n\t\t        this._lBlock ^= t;\n\t\t        this._rBlock ^= t << offset;\n\t\t    }\n\t\n\t\t    /**\n\t\t     * Shortcut functions to the cipher's object interface.\n\t\t     *\n\t\t     * @example\n\t\t     *\n\t\t     *     var ciphertext = CryptoJS.DES.encrypt(message, key, cfg);\n\t\t     *     var plaintext  = CryptoJS.DES.decrypt(ciphertext, key, cfg);\n\t\t     */\n\t\t    C.DES = BlockCipher._createHelper(DES);\n\t\n\t\t    /**\n\t\t     * Triple-DES block cipher algorithm.\n\t\t     */\n\t\t    var TripleDES = C_algo.TripleDES = BlockCipher.extend({\n\t\t        _doReset: function () {\n\t\t            // Shortcuts\n\t\t            var key = this._key;\n\t\t            var keyWords = key.words;\n\t\n\t\t            // Create DES instances\n\t\t            this._des1 = DES.createEncryptor(WordArray.create(keyWords.slice(0, 2)));\n\t\t            this._des2 = DES.createEncryptor(WordArray.create(keyWords.slice(2, 4)));\n\t\t            this._des3 = DES.createEncryptor(WordArray.create(keyWords.slice(4, 6)));\n\t\t        },\n\t\n\t\t        encryptBlock: function (M, offset) {\n\t\t            this._des1.encryptBlock(M, offset);\n\t\t            this._des2.decryptBlock(M, offset);\n\t\t            this._des3.encryptBlock(M, offset);\n\t\t        },\n\t\n\t\t        decryptBlock: function (M, offset) {\n\t\t            this._des3.decryptBlock(M, offset);\n\t\t            this._des2.encryptBlock(M, offset);\n\t\t            this._des1.decryptBlock(M, offset);\n\t\t        },\n\t\n\t\t        keySize: 192/32,\n\t\n\t\t        ivSize: 64/32,\n\t\n\t\t        blockSize: 64/32\n\t\t    });\n\t\n\t\t    /**\n\t\t     * Shortcut functions to the cipher's object interface.\n\t\t     *\n\t\t     * @example\n\t\t     *\n\t\t     *     var ciphertext = CryptoJS.TripleDES.encrypt(message, key, cfg);\n\t\t     *     var plaintext  = CryptoJS.TripleDES.decrypt(ciphertext, key, cfg);\n\t\t     */\n\t\t    C.TripleDES = BlockCipher._createHelper(TripleDES);\n\t\t}());\n\t\n\t\n\t\treturn CryptoJS.TripleDES;\n\t\n\t}));\n\n/***/ },\n/* 17 */\n/***/ function(module, exports, __webpack_require__) {\n\n\t;(function (root, factory, undef) {\n\t\tif (true) {\n\t\t\t// CommonJS\n\t\t\tmodule.exports = exports = factory(__webpack_require__(5), __webpack_require__(12), __webpack_require__(13), __webpack_require__(14), __webpack_require__(15));\n\t\t}\n\t\telse {}\n\t}(this, function (CryptoJS) {\n\t\n\t\t(function () {\n\t\t    // Shortcuts\n\t\t    var C = CryptoJS;\n\t\t    var C_lib = C.lib;\n\t\t    var StreamCipher = C_lib.StreamCipher;\n\t\t    var C_algo = C.algo;\n\t\n\t\t    // Reusable objects\n\t\t    var S  = [];\n\t\t    var C_ = [];\n\t\t    var G  = [];\n\t\n\t\t    /**\n\t\t     * Rabbit stream cipher algorithm\n\t\t     */\n\t\t    var Rabbit = C_algo.Rabbit = StreamCipher.extend({\n\t\t        _doReset: function () {\n\t\t            // Shortcuts\n\t\t            var K = this._key.words;\n\t\t            var iv = this.cfg.iv;\n\t\n\t\t            // Swap endian\n\t\t            for (var i = 0; i < 4; i++) {\n\t\t                K[i] = (((K[i] << 8)  | (K[i] >>> 24)) & 0x00ff00ff) |\n\t\t                       (((K[i] << 24) | (K[i] >>> 8))  & 0xff00ff00);\n\t\t            }\n\t\n\t\t            // Generate initial state values\n\t\t            var X = this._X = [\n\t\t                K[0], (K[3] << 16) | (K[2] >>> 16),\n\t\t                K[1], (K[0] << 16) | (K[3] >>> 16),\n\t\t                K[2], (K[1] << 16) | (K[0] >>> 16),\n\t\t                K[3], (K[2] << 16) | (K[1] >>> 16)\n\t\t            ];\n\t\n\t\t            // Generate initial counter values\n\t\t            var C = this._C = [\n\t\t                (K[2] << 16) | (K[2] >>> 16), (K[0] & 0xffff0000) | (K[1] & 0x0000ffff),\n\t\t                (K[3] << 16) | (K[3] >>> 16), (K[1] & 0xffff0000) | (K[2] & 0x0000ffff),\n\t\t                (K[0] << 16) | (K[0] >>> 16), (K[2] & 0xffff0000) | (K[3] & 0x0000ffff),\n\t\t                (K[1] << 16) | (K[1] >>> 16), (K[3] & 0xffff0000) | (K[0] & 0x0000ffff)\n\t\t            ];\n\t\n\t\t            // Carry bit\n\t\t            this._b = 0;\n\t\n\t\t            // Iterate the system four times\n\t\t            for (var i = 0; i < 4; i++) {\n\t\t                nextState.call(this);\n\t\t            }\n\t\n\t\t            // Modify the counters\n\t\t            for (var i = 0; i < 8; i++) {\n\t\t                C[i] ^= X[(i + 4) & 7];\n\t\t            }\n\t\n\t\t            // IV setup\n\t\t            if (iv) {\n\t\t                // Shortcuts\n\t\t                var IV = iv.words;\n\t\t                var IV_0 = IV[0];\n\t\t                var IV_1 = IV[1];\n\t\n\t\t                // Generate four subvectors\n\t\t                var i0 = (((IV_0 << 8) | (IV_0 >>> 24)) & 0x00ff00ff) | (((IV_0 << 24) | (IV_0 >>> 8)) & 0xff00ff00);\n\t\t                var i2 = (((IV_1 << 8) | (IV_1 >>> 24)) & 0x00ff00ff) | (((IV_1 << 24) | (IV_1 >>> 8)) & 0xff00ff00);\n\t\t                var i1 = (i0 >>> 16) | (i2 & 0xffff0000);\n\t\t                var i3 = (i2 << 16)  | (i0 & 0x0000ffff);\n\t\n\t\t                // Modify counter values\n\t\t                C[0] ^= i0;\n\t\t                C[1] ^= i1;\n\t\t                C[2] ^= i2;\n\t\t                C[3] ^= i3;\n\t\t                C[4] ^= i0;\n\t\t                C[5] ^= i1;\n\t\t                C[6] ^= i2;\n\t\t                C[7] ^= i3;\n\t\n\t\t                // Iterate the system four times\n\t\t                for (var i = 0; i < 4; i++) {\n\t\t                    nextState.call(this);\n\t\t                }\n\t\t            }\n\t\t        },\n\t\n\t\t        _doProcessBlock: function (M, offset) {\n\t\t            // Shortcut\n\t\t            var X = this._X;\n\t\n\t\t            // Iterate the system\n\t\t            nextState.call(this);\n\t\n\t\t            // Generate four keystream words\n\t\t            S[0] = X[0] ^ (X[5] >>> 16) ^ (X[3] << 16);\n\t\t            S[1] = X[2] ^ (X[7] >>> 16) ^ (X[5] << 16);\n\t\t            S[2] = X[4] ^ (X[1] >>> 16) ^ (X[7] << 16);\n\t\t            S[3] = X[6] ^ (X[3] >>> 16) ^ (X[1] << 16);\n\t\n\t\t            for (var i = 0; i < 4; i++) {\n\t\t                // Swap endian\n\t\t                S[i] = (((S[i] << 8)  | (S[i] >>> 24)) & 0x00ff00ff) |\n\t\t                       (((S[i] << 24) | (S[i] >>> 8))  & 0xff00ff00);\n\t\n\t\t                // Encrypt\n\t\t                M[offset + i] ^= S[i];\n\t\t            }\n\t\t        },\n\t\n\t\t        blockSize: 128/32,\n\t\n\t\t        ivSize: 64/32\n\t\t    });\n\t\n\t\t    function nextState() {\n\t\t        // Shortcuts\n\t\t        var X = this._X;\n\t\t        var C = this._C;\n\t\n\t\t        // Save old counter values\n\t\t        for (var i = 0; i < 8; i++) {\n\t\t            C_[i] = C[i];\n\t\t        }\n\t\n\t\t        // Calculate new counter values\n\t\t        C[0] = (C[0] + 0x4d34d34d + this._b) | 0;\n\t\t        C[1] = (C[1] + 0xd34d34d3 + ((C[0] >>> 0) < (C_[0] >>> 0) ? 1 : 0)) | 0;\n\t\t        C[2] = (C[2] + 0x34d34d34 + ((C[1] >>> 0) < (C_[1] >>> 0) ? 1 : 0)) | 0;\n\t\t        C[3] = (C[3] + 0x4d34d34d + ((C[2] >>> 0) < (C_[2] >>> 0) ? 1 : 0)) | 0;\n\t\t        C[4] = (C[4] + 0xd34d34d3 + ((C[3] >>> 0) < (C_[3] >>> 0) ? 1 : 0)) | 0;\n\t\t        C[5] = (C[5] + 0x34d34d34 + ((C[4] >>> 0) < (C_[4] >>> 0) ? 1 : 0)) | 0;\n\t\t        C[6] = (C[6] + 0x4d34d34d + ((C[5] >>> 0) < (C_[5] >>> 0) ? 1 : 0)) | 0;\n\t\t        C[7] = (C[7] + 0xd34d34d3 + ((C[6] >>> 0) < (C_[6] >>> 0) ? 1 : 0)) | 0;\n\t\t        this._b = (C[7] >>> 0) < (C_[7] >>> 0) ? 1 : 0;\n\t\n\t\t        // Calculate the g-values\n\t\t        for (var i = 0; i < 8; i++) {\n\t\t            var gx = X[i] + C[i];\n\t\n\t\t            // Construct high and low argument for squaring\n\t\t            var ga = gx & 0xffff;\n\t\t            var gb = gx >>> 16;\n\t\n\t\t            // Calculate high and low result of squaring\n\t\t            var gh = ((((ga * ga) >>> 17) + ga * gb) >>> 15) + gb * gb;\n\t\t            var gl = (((gx & 0xffff0000) * gx) | 0) + (((gx & 0x0000ffff) * gx) | 0);\n\t\n\t\t            // High XOR low\n\t\t            G[i] = gh ^ gl;\n\t\t        }\n\t\n\t\t        // Calculate new state values\n\t\t        X[0] = (G[0] + ((G[7] << 16) | (G[7] >>> 16)) + ((G[6] << 16) | (G[6] >>> 16))) | 0;\n\t\t        X[1] = (G[1] + ((G[0] << 8)  | (G[0] >>> 24)) + G[7]) | 0;\n\t\t        X[2] = (G[2] + ((G[1] << 16) | (G[1] >>> 16)) + ((G[0] << 16) | (G[0] >>> 16))) | 0;\n\t\t        X[3] = (G[3] + ((G[2] << 8)  | (G[2] >>> 24)) + G[1]) | 0;\n\t\t        X[4] = (G[4] + ((G[3] << 16) | (G[3] >>> 16)) + ((G[2] << 16) | (G[2] >>> 16))) | 0;\n\t\t        X[5] = (G[5] + ((G[4] << 8)  | (G[4] >>> 24)) + G[3]) | 0;\n\t\t        X[6] = (G[6] + ((G[5] << 16) | (G[5] >>> 16)) + ((G[4] << 16) | (G[4] >>> 16))) | 0;\n\t\t        X[7] = (G[7] + ((G[6] << 8)  | (G[6] >>> 24)) + G[5]) | 0;\n\t\t    }\n\t\n\t\t    /**\n\t\t     * Shortcut functions to the cipher's object interface.\n\t\t     *\n\t\t     * @example\n\t\t     *\n\t\t     *     var ciphertext = CryptoJS.Rabbit.encrypt(message, key, cfg);\n\t\t     *     var plaintext  = CryptoJS.Rabbit.decrypt(ciphertext, key, cfg);\n\t\t     */\n\t\t    C.Rabbit = StreamCipher._createHelper(Rabbit);\n\t\t}());\n\t\n\t\n\t\treturn CryptoJS.Rabbit;\n\t\n\t}));\n\n/***/ },\n/* 18 */\n/***/ function(module, exports, __webpack_require__) {\n\n\t;(function (root, factory, undef) {\n\t\tif (true) {\n\t\t\t// CommonJS\n\t\t\tmodule.exports = exports = factory(__webpack_require__(5), __webpack_require__(12), __webpack_require__(13), __webpack_require__(14), __webpack_require__(15));\n\t\t}\n\t\telse {}\n\t}(this, function (CryptoJS) {\n\t\n\t\t(function () {\n\t\t    // Shortcuts\n\t\t    var C = CryptoJS;\n\t\t    var C_lib = C.lib;\n\t\t    var StreamCipher = C_lib.StreamCipher;\n\t\t    var C_algo = C.algo;\n\t\n\t\t    /**\n\t\t     * RC4 stream cipher algorithm.\n\t\t     */\n\t\t    var RC4 = C_algo.RC4 = StreamCipher.extend({\n\t\t        _doReset: function () {\n\t\t            // Shortcuts\n\t\t            var key = this._key;\n\t\t            var keyWords = key.words;\n\t\t            var keySigBytes = key.sigBytes;\n\t\n\t\t            // Init sbox\n\t\t            var S = this._S = [];\n\t\t            for (var i = 0; i < 256; i++) {\n\t\t                S[i] = i;\n\t\t            }\n\t\n\t\t            // Key setup\n\t\t            for (var i = 0, j = 0; i < 256; i++) {\n\t\t                var keyByteIndex = i % keySigBytes;\n\t\t                var keyByte = (keyWords[keyByteIndex >>> 2] >>> (24 - (keyByteIndex % 4) * 8)) & 0xff;\n\t\n\t\t                j = (j + S[i] + keyByte) % 256;\n\t\n\t\t                // Swap\n\t\t                var t = S[i];\n\t\t                S[i] = S[j];\n\t\t                S[j] = t;\n\t\t            }\n\t\n\t\t            // Counters\n\t\t            this._i = this._j = 0;\n\t\t        },\n\t\n\t\t        _doProcessBlock: function (M, offset) {\n\t\t            M[offset] ^= generateKeystreamWord.call(this);\n\t\t        },\n\t\n\t\t        keySize: 256/32,\n\t\n\t\t        ivSize: 0\n\t\t    });\n\t\n\t\t    function generateKeystreamWord() {\n\t\t        // Shortcuts\n\t\t        var S = this._S;\n\t\t        var i = this._i;\n\t\t        var j = this._j;\n\t\n\t\t        // Generate keystream word\n\t\t        var keystreamWord = 0;\n\t\t        for (var n = 0; n < 4; n++) {\n\t\t            i = (i + 1) % 256;\n\t\t            j = (j + S[i]) % 256;\n\t\n\t\t            // Swap\n\t\t            var t = S[i];\n\t\t            S[i] = S[j];\n\t\t            S[j] = t;\n\t\n\t\t            keystreamWord |= S[(S[i] + S[j]) % 256] << (24 - n * 8);\n\t\t        }\n\t\n\t\t        // Update counters\n\t\t        this._i = i;\n\t\t        this._j = j;\n\t\n\t\t        return keystreamWord;\n\t\t    }\n\t\n\t\t    /**\n\t\t     * Shortcut functions to the cipher's object interface.\n\t\t     *\n\t\t     * @example\n\t\t     *\n\t\t     *     var ciphertext = CryptoJS.RC4.encrypt(message, key, cfg);\n\t\t     *     var plaintext  = CryptoJS.RC4.decrypt(ciphertext, key, cfg);\n\t\t     */\n\t\t    C.RC4 = StreamCipher._createHelper(RC4);\n\t\n\t\t    /**\n\t\t     * Modified RC4 stream cipher algorithm.\n\t\t     */\n\t\t    var RC4Drop = C_algo.RC4Drop = RC4.extend({\n\t\t        /**\n\t\t         * Configuration options.\n\t\t         *\n\t\t         * @property {number} drop The number of keystream words to drop. Default 192\n\t\t         */\n\t\t        cfg: RC4.cfg.extend({\n\t\t            drop: 192\n\t\t        }),\n\t\n\t\t        _doReset: function () {\n\t\t            RC4._doReset.call(this);\n\t\n\t\t            // Drop\n\t\t            for (var i = this.cfg.drop; i > 0; i--) {\n\t\t                generateKeystreamWord.call(this);\n\t\t            }\n\t\t        }\n\t\t    });\n\t\n\t\t    /**\n\t\t     * Shortcut functions to the cipher's object interface.\n\t\t     *\n\t\t     * @example\n\t\t     *\n\t\t     *     var ciphertext = CryptoJS.RC4Drop.encrypt(message, key, cfg);\n\t\t     *     var plaintext  = CryptoJS.RC4Drop.decrypt(ciphertext, key, cfg);\n\t\t     */\n\t\t    C.RC4Drop = StreamCipher._createHelper(RC4Drop);\n\t\t}());\n\t\n\t\n\t\treturn CryptoJS.RC4;\n\t\n\t}));\n\n/***/ }\n/******/ ])\n});\n;\n//# sourceMappingURL=secure-ls.js.map\n\n//# sourceURL=webpack:///../node_modules/secure-ls/dist/secure-ls.js?"
        );

        /***/
      },

    /***/ "../node_modules/tweetnacl/nacl-fast.js":
      /*!**********************************************!*\
  !*** ../node_modules/tweetnacl/nacl-fast.js ***!
  \**********************************************/
      /*! no static exports found */
      /***/ function(module, exports, __webpack_require__) {
        eval(
          "(function(nacl) {\n'use strict';\n\n// Ported in 2014 by Dmitry Chestnykh and Devi Mandiri.\n// Public domain.\n//\n// Implementation derived from TweetNaCl version 20140427.\n// See for details: http://tweetnacl.cr.yp.to/\n\nvar gf = function(init) {\n  var i, r = new Float64Array(16);\n  if (init) for (i = 0; i < init.length; i++) r[i] = init[i];\n  return r;\n};\n\n//  Pluggable, initialized in high-level API below.\nvar randombytes = function(/* x, n */) { throw new Error('no PRNG'); };\n\nvar _0 = new Uint8Array(16);\nvar _9 = new Uint8Array(32); _9[0] = 9;\n\nvar gf0 = gf(),\n    gf1 = gf([1]),\n    _121665 = gf([0xdb41, 1]),\n    D = gf([0x78a3, 0x1359, 0x4dca, 0x75eb, 0xd8ab, 0x4141, 0x0a4d, 0x0070, 0xe898, 0x7779, 0x4079, 0x8cc7, 0xfe73, 0x2b6f, 0x6cee, 0x5203]),\n    D2 = gf([0xf159, 0x26b2, 0x9b94, 0xebd6, 0xb156, 0x8283, 0x149a, 0x00e0, 0xd130, 0xeef3, 0x80f2, 0x198e, 0xfce7, 0x56df, 0xd9dc, 0x2406]),\n    X = gf([0xd51a, 0x8f25, 0x2d60, 0xc956, 0xa7b2, 0x9525, 0xc760, 0x692c, 0xdc5c, 0xfdd6, 0xe231, 0xc0a4, 0x53fe, 0xcd6e, 0x36d3, 0x2169]),\n    Y = gf([0x6658, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666]),\n    I = gf([0xa0b0, 0x4a0e, 0x1b27, 0xc4ee, 0xe478, 0xad2f, 0x1806, 0x2f43, 0xd7a7, 0x3dfb, 0x0099, 0x2b4d, 0xdf0b, 0x4fc1, 0x2480, 0x2b83]);\n\nfunction ts64(x, i, h, l) {\n  x[i]   = (h >> 24) & 0xff;\n  x[i+1] = (h >> 16) & 0xff;\n  x[i+2] = (h >>  8) & 0xff;\n  x[i+3] = h & 0xff;\n  x[i+4] = (l >> 24)  & 0xff;\n  x[i+5] = (l >> 16)  & 0xff;\n  x[i+6] = (l >>  8)  & 0xff;\n  x[i+7] = l & 0xff;\n}\n\nfunction vn(x, xi, y, yi, n) {\n  var i,d = 0;\n  for (i = 0; i < n; i++) d |= x[xi+i]^y[yi+i];\n  return (1 & ((d - 1) >>> 8)) - 1;\n}\n\nfunction crypto_verify_16(x, xi, y, yi) {\n  return vn(x,xi,y,yi,16);\n}\n\nfunction crypto_verify_32(x, xi, y, yi) {\n  return vn(x,xi,y,yi,32);\n}\n\nfunction core_salsa20(o, p, k, c) {\n  var j0  = c[ 0] & 0xff | (c[ 1] & 0xff)<<8 | (c[ 2] & 0xff)<<16 | (c[ 3] & 0xff)<<24,\n      j1  = k[ 0] & 0xff | (k[ 1] & 0xff)<<8 | (k[ 2] & 0xff)<<16 | (k[ 3] & 0xff)<<24,\n      j2  = k[ 4] & 0xff | (k[ 5] & 0xff)<<8 | (k[ 6] & 0xff)<<16 | (k[ 7] & 0xff)<<24,\n      j3  = k[ 8] & 0xff | (k[ 9] & 0xff)<<8 | (k[10] & 0xff)<<16 | (k[11] & 0xff)<<24,\n      j4  = k[12] & 0xff | (k[13] & 0xff)<<8 | (k[14] & 0xff)<<16 | (k[15] & 0xff)<<24,\n      j5  = c[ 4] & 0xff | (c[ 5] & 0xff)<<8 | (c[ 6] & 0xff)<<16 | (c[ 7] & 0xff)<<24,\n      j6  = p[ 0] & 0xff | (p[ 1] & 0xff)<<8 | (p[ 2] & 0xff)<<16 | (p[ 3] & 0xff)<<24,\n      j7  = p[ 4] & 0xff | (p[ 5] & 0xff)<<8 | (p[ 6] & 0xff)<<16 | (p[ 7] & 0xff)<<24,\n      j8  = p[ 8] & 0xff | (p[ 9] & 0xff)<<8 | (p[10] & 0xff)<<16 | (p[11] & 0xff)<<24,\n      j9  = p[12] & 0xff | (p[13] & 0xff)<<8 | (p[14] & 0xff)<<16 | (p[15] & 0xff)<<24,\n      j10 = c[ 8] & 0xff | (c[ 9] & 0xff)<<8 | (c[10] & 0xff)<<16 | (c[11] & 0xff)<<24,\n      j11 = k[16] & 0xff | (k[17] & 0xff)<<8 | (k[18] & 0xff)<<16 | (k[19] & 0xff)<<24,\n      j12 = k[20] & 0xff | (k[21] & 0xff)<<8 | (k[22] & 0xff)<<16 | (k[23] & 0xff)<<24,\n      j13 = k[24] & 0xff | (k[25] & 0xff)<<8 | (k[26] & 0xff)<<16 | (k[27] & 0xff)<<24,\n      j14 = k[28] & 0xff | (k[29] & 0xff)<<8 | (k[30] & 0xff)<<16 | (k[31] & 0xff)<<24,\n      j15 = c[12] & 0xff | (c[13] & 0xff)<<8 | (c[14] & 0xff)<<16 | (c[15] & 0xff)<<24;\n\n  var x0 = j0, x1 = j1, x2 = j2, x3 = j3, x4 = j4, x5 = j5, x6 = j6, x7 = j7,\n      x8 = j8, x9 = j9, x10 = j10, x11 = j11, x12 = j12, x13 = j13, x14 = j14,\n      x15 = j15, u;\n\n  for (var i = 0; i < 20; i += 2) {\n    u = x0 + x12 | 0;\n    x4 ^= u<<7 | u>>>(32-7);\n    u = x4 + x0 | 0;\n    x8 ^= u<<9 | u>>>(32-9);\n    u = x8 + x4 | 0;\n    x12 ^= u<<13 | u>>>(32-13);\n    u = x12 + x8 | 0;\n    x0 ^= u<<18 | u>>>(32-18);\n\n    u = x5 + x1 | 0;\n    x9 ^= u<<7 | u>>>(32-7);\n    u = x9 + x5 | 0;\n    x13 ^= u<<9 | u>>>(32-9);\n    u = x13 + x9 | 0;\n    x1 ^= u<<13 | u>>>(32-13);\n    u = x1 + x13 | 0;\n    x5 ^= u<<18 | u>>>(32-18);\n\n    u = x10 + x6 | 0;\n    x14 ^= u<<7 | u>>>(32-7);\n    u = x14 + x10 | 0;\n    x2 ^= u<<9 | u>>>(32-9);\n    u = x2 + x14 | 0;\n    x6 ^= u<<13 | u>>>(32-13);\n    u = x6 + x2 | 0;\n    x10 ^= u<<18 | u>>>(32-18);\n\n    u = x15 + x11 | 0;\n    x3 ^= u<<7 | u>>>(32-7);\n    u = x3 + x15 | 0;\n    x7 ^= u<<9 | u>>>(32-9);\n    u = x7 + x3 | 0;\n    x11 ^= u<<13 | u>>>(32-13);\n    u = x11 + x7 | 0;\n    x15 ^= u<<18 | u>>>(32-18);\n\n    u = x0 + x3 | 0;\n    x1 ^= u<<7 | u>>>(32-7);\n    u = x1 + x0 | 0;\n    x2 ^= u<<9 | u>>>(32-9);\n    u = x2 + x1 | 0;\n    x3 ^= u<<13 | u>>>(32-13);\n    u = x3 + x2 | 0;\n    x0 ^= u<<18 | u>>>(32-18);\n\n    u = x5 + x4 | 0;\n    x6 ^= u<<7 | u>>>(32-7);\n    u = x6 + x5 | 0;\n    x7 ^= u<<9 | u>>>(32-9);\n    u = x7 + x6 | 0;\n    x4 ^= u<<13 | u>>>(32-13);\n    u = x4 + x7 | 0;\n    x5 ^= u<<18 | u>>>(32-18);\n\n    u = x10 + x9 | 0;\n    x11 ^= u<<7 | u>>>(32-7);\n    u = x11 + x10 | 0;\n    x8 ^= u<<9 | u>>>(32-9);\n    u = x8 + x11 | 0;\n    x9 ^= u<<13 | u>>>(32-13);\n    u = x9 + x8 | 0;\n    x10 ^= u<<18 | u>>>(32-18);\n\n    u = x15 + x14 | 0;\n    x12 ^= u<<7 | u>>>(32-7);\n    u = x12 + x15 | 0;\n    x13 ^= u<<9 | u>>>(32-9);\n    u = x13 + x12 | 0;\n    x14 ^= u<<13 | u>>>(32-13);\n    u = x14 + x13 | 0;\n    x15 ^= u<<18 | u>>>(32-18);\n  }\n   x0 =  x0 +  j0 | 0;\n   x1 =  x1 +  j1 | 0;\n   x2 =  x2 +  j2 | 0;\n   x3 =  x3 +  j3 | 0;\n   x4 =  x4 +  j4 | 0;\n   x5 =  x5 +  j5 | 0;\n   x6 =  x6 +  j6 | 0;\n   x7 =  x7 +  j7 | 0;\n   x8 =  x8 +  j8 | 0;\n   x9 =  x9 +  j9 | 0;\n  x10 = x10 + j10 | 0;\n  x11 = x11 + j11 | 0;\n  x12 = x12 + j12 | 0;\n  x13 = x13 + j13 | 0;\n  x14 = x14 + j14 | 0;\n  x15 = x15 + j15 | 0;\n\n  o[ 0] = x0 >>>  0 & 0xff;\n  o[ 1] = x0 >>>  8 & 0xff;\n  o[ 2] = x0 >>> 16 & 0xff;\n  o[ 3] = x0 >>> 24 & 0xff;\n\n  o[ 4] = x1 >>>  0 & 0xff;\n  o[ 5] = x1 >>>  8 & 0xff;\n  o[ 6] = x1 >>> 16 & 0xff;\n  o[ 7] = x1 >>> 24 & 0xff;\n\n  o[ 8] = x2 >>>  0 & 0xff;\n  o[ 9] = x2 >>>  8 & 0xff;\n  o[10] = x2 >>> 16 & 0xff;\n  o[11] = x2 >>> 24 & 0xff;\n\n  o[12] = x3 >>>  0 & 0xff;\n  o[13] = x3 >>>  8 & 0xff;\n  o[14] = x3 >>> 16 & 0xff;\n  o[15] = x3 >>> 24 & 0xff;\n\n  o[16] = x4 >>>  0 & 0xff;\n  o[17] = x4 >>>  8 & 0xff;\n  o[18] = x4 >>> 16 & 0xff;\n  o[19] = x4 >>> 24 & 0xff;\n\n  o[20] = x5 >>>  0 & 0xff;\n  o[21] = x5 >>>  8 & 0xff;\n  o[22] = x5 >>> 16 & 0xff;\n  o[23] = x5 >>> 24 & 0xff;\n\n  o[24] = x6 >>>  0 & 0xff;\n  o[25] = x6 >>>  8 & 0xff;\n  o[26] = x6 >>> 16 & 0xff;\n  o[27] = x6 >>> 24 & 0xff;\n\n  o[28] = x7 >>>  0 & 0xff;\n  o[29] = x7 >>>  8 & 0xff;\n  o[30] = x7 >>> 16 & 0xff;\n  o[31] = x7 >>> 24 & 0xff;\n\n  o[32] = x8 >>>  0 & 0xff;\n  o[33] = x8 >>>  8 & 0xff;\n  o[34] = x8 >>> 16 & 0xff;\n  o[35] = x8 >>> 24 & 0xff;\n\n  o[36] = x9 >>>  0 & 0xff;\n  o[37] = x9 >>>  8 & 0xff;\n  o[38] = x9 >>> 16 & 0xff;\n  o[39] = x9 >>> 24 & 0xff;\n\n  o[40] = x10 >>>  0 & 0xff;\n  o[41] = x10 >>>  8 & 0xff;\n  o[42] = x10 >>> 16 & 0xff;\n  o[43] = x10 >>> 24 & 0xff;\n\n  o[44] = x11 >>>  0 & 0xff;\n  o[45] = x11 >>>  8 & 0xff;\n  o[46] = x11 >>> 16 & 0xff;\n  o[47] = x11 >>> 24 & 0xff;\n\n  o[48] = x12 >>>  0 & 0xff;\n  o[49] = x12 >>>  8 & 0xff;\n  o[50] = x12 >>> 16 & 0xff;\n  o[51] = x12 >>> 24 & 0xff;\n\n  o[52] = x13 >>>  0 & 0xff;\n  o[53] = x13 >>>  8 & 0xff;\n  o[54] = x13 >>> 16 & 0xff;\n  o[55] = x13 >>> 24 & 0xff;\n\n  o[56] = x14 >>>  0 & 0xff;\n  o[57] = x14 >>>  8 & 0xff;\n  o[58] = x14 >>> 16 & 0xff;\n  o[59] = x14 >>> 24 & 0xff;\n\n  o[60] = x15 >>>  0 & 0xff;\n  o[61] = x15 >>>  8 & 0xff;\n  o[62] = x15 >>> 16 & 0xff;\n  o[63] = x15 >>> 24 & 0xff;\n}\n\nfunction core_hsalsa20(o,p,k,c) {\n  var j0  = c[ 0] & 0xff | (c[ 1] & 0xff)<<8 | (c[ 2] & 0xff)<<16 | (c[ 3] & 0xff)<<24,\n      j1  = k[ 0] & 0xff | (k[ 1] & 0xff)<<8 | (k[ 2] & 0xff)<<16 | (k[ 3] & 0xff)<<24,\n      j2  = k[ 4] & 0xff | (k[ 5] & 0xff)<<8 | (k[ 6] & 0xff)<<16 | (k[ 7] & 0xff)<<24,\n      j3  = k[ 8] & 0xff | (k[ 9] & 0xff)<<8 | (k[10] & 0xff)<<16 | (k[11] & 0xff)<<24,\n      j4  = k[12] & 0xff | (k[13] & 0xff)<<8 | (k[14] & 0xff)<<16 | (k[15] & 0xff)<<24,\n      j5  = c[ 4] & 0xff | (c[ 5] & 0xff)<<8 | (c[ 6] & 0xff)<<16 | (c[ 7] & 0xff)<<24,\n      j6  = p[ 0] & 0xff | (p[ 1] & 0xff)<<8 | (p[ 2] & 0xff)<<16 | (p[ 3] & 0xff)<<24,\n      j7  = p[ 4] & 0xff | (p[ 5] & 0xff)<<8 | (p[ 6] & 0xff)<<16 | (p[ 7] & 0xff)<<24,\n      j8  = p[ 8] & 0xff | (p[ 9] & 0xff)<<8 | (p[10] & 0xff)<<16 | (p[11] & 0xff)<<24,\n      j9  = p[12] & 0xff | (p[13] & 0xff)<<8 | (p[14] & 0xff)<<16 | (p[15] & 0xff)<<24,\n      j10 = c[ 8] & 0xff | (c[ 9] & 0xff)<<8 | (c[10] & 0xff)<<16 | (c[11] & 0xff)<<24,\n      j11 = k[16] & 0xff | (k[17] & 0xff)<<8 | (k[18] & 0xff)<<16 | (k[19] & 0xff)<<24,\n      j12 = k[20] & 0xff | (k[21] & 0xff)<<8 | (k[22] & 0xff)<<16 | (k[23] & 0xff)<<24,\n      j13 = k[24] & 0xff | (k[25] & 0xff)<<8 | (k[26] & 0xff)<<16 | (k[27] & 0xff)<<24,\n      j14 = k[28] & 0xff | (k[29] & 0xff)<<8 | (k[30] & 0xff)<<16 | (k[31] & 0xff)<<24,\n      j15 = c[12] & 0xff | (c[13] & 0xff)<<8 | (c[14] & 0xff)<<16 | (c[15] & 0xff)<<24;\n\n  var x0 = j0, x1 = j1, x2 = j2, x3 = j3, x4 = j4, x5 = j5, x6 = j6, x7 = j7,\n      x8 = j8, x9 = j9, x10 = j10, x11 = j11, x12 = j12, x13 = j13, x14 = j14,\n      x15 = j15, u;\n\n  for (var i = 0; i < 20; i += 2) {\n    u = x0 + x12 | 0;\n    x4 ^= u<<7 | u>>>(32-7);\n    u = x4 + x0 | 0;\n    x8 ^= u<<9 | u>>>(32-9);\n    u = x8 + x4 | 0;\n    x12 ^= u<<13 | u>>>(32-13);\n    u = x12 + x8 | 0;\n    x0 ^= u<<18 | u>>>(32-18);\n\n    u = x5 + x1 | 0;\n    x9 ^= u<<7 | u>>>(32-7);\n    u = x9 + x5 | 0;\n    x13 ^= u<<9 | u>>>(32-9);\n    u = x13 + x9 | 0;\n    x1 ^= u<<13 | u>>>(32-13);\n    u = x1 + x13 | 0;\n    x5 ^= u<<18 | u>>>(32-18);\n\n    u = x10 + x6 | 0;\n    x14 ^= u<<7 | u>>>(32-7);\n    u = x14 + x10 | 0;\n    x2 ^= u<<9 | u>>>(32-9);\n    u = x2 + x14 | 0;\n    x6 ^= u<<13 | u>>>(32-13);\n    u = x6 + x2 | 0;\n    x10 ^= u<<18 | u>>>(32-18);\n\n    u = x15 + x11 | 0;\n    x3 ^= u<<7 | u>>>(32-7);\n    u = x3 + x15 | 0;\n    x7 ^= u<<9 | u>>>(32-9);\n    u = x7 + x3 | 0;\n    x11 ^= u<<13 | u>>>(32-13);\n    u = x11 + x7 | 0;\n    x15 ^= u<<18 | u>>>(32-18);\n\n    u = x0 + x3 | 0;\n    x1 ^= u<<7 | u>>>(32-7);\n    u = x1 + x0 | 0;\n    x2 ^= u<<9 | u>>>(32-9);\n    u = x2 + x1 | 0;\n    x3 ^= u<<13 | u>>>(32-13);\n    u = x3 + x2 | 0;\n    x0 ^= u<<18 | u>>>(32-18);\n\n    u = x5 + x4 | 0;\n    x6 ^= u<<7 | u>>>(32-7);\n    u = x6 + x5 | 0;\n    x7 ^= u<<9 | u>>>(32-9);\n    u = x7 + x6 | 0;\n    x4 ^= u<<13 | u>>>(32-13);\n    u = x4 + x7 | 0;\n    x5 ^= u<<18 | u>>>(32-18);\n\n    u = x10 + x9 | 0;\n    x11 ^= u<<7 | u>>>(32-7);\n    u = x11 + x10 | 0;\n    x8 ^= u<<9 | u>>>(32-9);\n    u = x8 + x11 | 0;\n    x9 ^= u<<13 | u>>>(32-13);\n    u = x9 + x8 | 0;\n    x10 ^= u<<18 | u>>>(32-18);\n\n    u = x15 + x14 | 0;\n    x12 ^= u<<7 | u>>>(32-7);\n    u = x12 + x15 | 0;\n    x13 ^= u<<9 | u>>>(32-9);\n    u = x13 + x12 | 0;\n    x14 ^= u<<13 | u>>>(32-13);\n    u = x14 + x13 | 0;\n    x15 ^= u<<18 | u>>>(32-18);\n  }\n\n  o[ 0] = x0 >>>  0 & 0xff;\n  o[ 1] = x0 >>>  8 & 0xff;\n  o[ 2] = x0 >>> 16 & 0xff;\n  o[ 3] = x0 >>> 24 & 0xff;\n\n  o[ 4] = x5 >>>  0 & 0xff;\n  o[ 5] = x5 >>>  8 & 0xff;\n  o[ 6] = x5 >>> 16 & 0xff;\n  o[ 7] = x5 >>> 24 & 0xff;\n\n  o[ 8] = x10 >>>  0 & 0xff;\n  o[ 9] = x10 >>>  8 & 0xff;\n  o[10] = x10 >>> 16 & 0xff;\n  o[11] = x10 >>> 24 & 0xff;\n\n  o[12] = x15 >>>  0 & 0xff;\n  o[13] = x15 >>>  8 & 0xff;\n  o[14] = x15 >>> 16 & 0xff;\n  o[15] = x15 >>> 24 & 0xff;\n\n  o[16] = x6 >>>  0 & 0xff;\n  o[17] = x6 >>>  8 & 0xff;\n  o[18] = x6 >>> 16 & 0xff;\n  o[19] = x6 >>> 24 & 0xff;\n\n  o[20] = x7 >>>  0 & 0xff;\n  o[21] = x7 >>>  8 & 0xff;\n  o[22] = x7 >>> 16 & 0xff;\n  o[23] = x7 >>> 24 & 0xff;\n\n  o[24] = x8 >>>  0 & 0xff;\n  o[25] = x8 >>>  8 & 0xff;\n  o[26] = x8 >>> 16 & 0xff;\n  o[27] = x8 >>> 24 & 0xff;\n\n  o[28] = x9 >>>  0 & 0xff;\n  o[29] = x9 >>>  8 & 0xff;\n  o[30] = x9 >>> 16 & 0xff;\n  o[31] = x9 >>> 24 & 0xff;\n}\n\nfunction crypto_core_salsa20(out,inp,k,c) {\n  core_salsa20(out,inp,k,c);\n}\n\nfunction crypto_core_hsalsa20(out,inp,k,c) {\n  core_hsalsa20(out,inp,k,c);\n}\n\nvar sigma = new Uint8Array([101, 120, 112, 97, 110, 100, 32, 51, 50, 45, 98, 121, 116, 101, 32, 107]);\n            // \"expand 32-byte k\"\n\nfunction crypto_stream_salsa20_xor(c,cpos,m,mpos,b,n,k) {\n  var z = new Uint8Array(16), x = new Uint8Array(64);\n  var u, i;\n  for (i = 0; i < 16; i++) z[i] = 0;\n  for (i = 0; i < 8; i++) z[i] = n[i];\n  while (b >= 64) {\n    crypto_core_salsa20(x,z,k,sigma);\n    for (i = 0; i < 64; i++) c[cpos+i] = m[mpos+i] ^ x[i];\n    u = 1;\n    for (i = 8; i < 16; i++) {\n      u = u + (z[i] & 0xff) | 0;\n      z[i] = u & 0xff;\n      u >>>= 8;\n    }\n    b -= 64;\n    cpos += 64;\n    mpos += 64;\n  }\n  if (b > 0) {\n    crypto_core_salsa20(x,z,k,sigma);\n    for (i = 0; i < b; i++) c[cpos+i] = m[mpos+i] ^ x[i];\n  }\n  return 0;\n}\n\nfunction crypto_stream_salsa20(c,cpos,b,n,k) {\n  var z = new Uint8Array(16), x = new Uint8Array(64);\n  var u, i;\n  for (i = 0; i < 16; i++) z[i] = 0;\n  for (i = 0; i < 8; i++) z[i] = n[i];\n  while (b >= 64) {\n    crypto_core_salsa20(x,z,k,sigma);\n    for (i = 0; i < 64; i++) c[cpos+i] = x[i];\n    u = 1;\n    for (i = 8; i < 16; i++) {\n      u = u + (z[i] & 0xff) | 0;\n      z[i] = u & 0xff;\n      u >>>= 8;\n    }\n    b -= 64;\n    cpos += 64;\n  }\n  if (b > 0) {\n    crypto_core_salsa20(x,z,k,sigma);\n    for (i = 0; i < b; i++) c[cpos+i] = x[i];\n  }\n  return 0;\n}\n\nfunction crypto_stream(c,cpos,d,n,k) {\n  var s = new Uint8Array(32);\n  crypto_core_hsalsa20(s,n,k,sigma);\n  var sn = new Uint8Array(8);\n  for (var i = 0; i < 8; i++) sn[i] = n[i+16];\n  return crypto_stream_salsa20(c,cpos,d,sn,s);\n}\n\nfunction crypto_stream_xor(c,cpos,m,mpos,d,n,k) {\n  var s = new Uint8Array(32);\n  crypto_core_hsalsa20(s,n,k,sigma);\n  var sn = new Uint8Array(8);\n  for (var i = 0; i < 8; i++) sn[i] = n[i+16];\n  return crypto_stream_salsa20_xor(c,cpos,m,mpos,d,sn,s);\n}\n\n/*\n* Port of Andrew Moon's Poly1305-donna-16. Public domain.\n* https://github.com/floodyberry/poly1305-donna\n*/\n\nvar poly1305 = function(key) {\n  this.buffer = new Uint8Array(16);\n  this.r = new Uint16Array(10);\n  this.h = new Uint16Array(10);\n  this.pad = new Uint16Array(8);\n  this.leftover = 0;\n  this.fin = 0;\n\n  var t0, t1, t2, t3, t4, t5, t6, t7;\n\n  t0 = key[ 0] & 0xff | (key[ 1] & 0xff) << 8; this.r[0] = ( t0                     ) & 0x1fff;\n  t1 = key[ 2] & 0xff | (key[ 3] & 0xff) << 8; this.r[1] = ((t0 >>> 13) | (t1 <<  3)) & 0x1fff;\n  t2 = key[ 4] & 0xff | (key[ 5] & 0xff) << 8; this.r[2] = ((t1 >>> 10) | (t2 <<  6)) & 0x1f03;\n  t3 = key[ 6] & 0xff | (key[ 7] & 0xff) << 8; this.r[3] = ((t2 >>>  7) | (t3 <<  9)) & 0x1fff;\n  t4 = key[ 8] & 0xff | (key[ 9] & 0xff) << 8; this.r[4] = ((t3 >>>  4) | (t4 << 12)) & 0x00ff;\n  this.r[5] = ((t4 >>>  1)) & 0x1ffe;\n  t5 = key[10] & 0xff | (key[11] & 0xff) << 8; this.r[6] = ((t4 >>> 14) | (t5 <<  2)) & 0x1fff;\n  t6 = key[12] & 0xff | (key[13] & 0xff) << 8; this.r[7] = ((t5 >>> 11) | (t6 <<  5)) & 0x1f81;\n  t7 = key[14] & 0xff | (key[15] & 0xff) << 8; this.r[8] = ((t6 >>>  8) | (t7 <<  8)) & 0x1fff;\n  this.r[9] = ((t7 >>>  5)) & 0x007f;\n\n  this.pad[0] = key[16] & 0xff | (key[17] & 0xff) << 8;\n  this.pad[1] = key[18] & 0xff | (key[19] & 0xff) << 8;\n  this.pad[2] = key[20] & 0xff | (key[21] & 0xff) << 8;\n  this.pad[3] = key[22] & 0xff | (key[23] & 0xff) << 8;\n  this.pad[4] = key[24] & 0xff | (key[25] & 0xff) << 8;\n  this.pad[5] = key[26] & 0xff | (key[27] & 0xff) << 8;\n  this.pad[6] = key[28] & 0xff | (key[29] & 0xff) << 8;\n  this.pad[7] = key[30] & 0xff | (key[31] & 0xff) << 8;\n};\n\npoly1305.prototype.blocks = function(m, mpos, bytes) {\n  var hibit = this.fin ? 0 : (1 << 11);\n  var t0, t1, t2, t3, t4, t5, t6, t7, c;\n  var d0, d1, d2, d3, d4, d5, d6, d7, d8, d9;\n\n  var h0 = this.h[0],\n      h1 = this.h[1],\n      h2 = this.h[2],\n      h3 = this.h[3],\n      h4 = this.h[4],\n      h5 = this.h[5],\n      h6 = this.h[6],\n      h7 = this.h[7],\n      h8 = this.h[8],\n      h9 = this.h[9];\n\n  var r0 = this.r[0],\n      r1 = this.r[1],\n      r2 = this.r[2],\n      r3 = this.r[3],\n      r4 = this.r[4],\n      r5 = this.r[5],\n      r6 = this.r[6],\n      r7 = this.r[7],\n      r8 = this.r[8],\n      r9 = this.r[9];\n\n  while (bytes >= 16) {\n    t0 = m[mpos+ 0] & 0xff | (m[mpos+ 1] & 0xff) << 8; h0 += ( t0                     ) & 0x1fff;\n    t1 = m[mpos+ 2] & 0xff | (m[mpos+ 3] & 0xff) << 8; h1 += ((t0 >>> 13) | (t1 <<  3)) & 0x1fff;\n    t2 = m[mpos+ 4] & 0xff | (m[mpos+ 5] & 0xff) << 8; h2 += ((t1 >>> 10) | (t2 <<  6)) & 0x1fff;\n    t3 = m[mpos+ 6] & 0xff | (m[mpos+ 7] & 0xff) << 8; h3 += ((t2 >>>  7) | (t3 <<  9)) & 0x1fff;\n    t4 = m[mpos+ 8] & 0xff | (m[mpos+ 9] & 0xff) << 8; h4 += ((t3 >>>  4) | (t4 << 12)) & 0x1fff;\n    h5 += ((t4 >>>  1)) & 0x1fff;\n    t5 = m[mpos+10] & 0xff | (m[mpos+11] & 0xff) << 8; h6 += ((t4 >>> 14) | (t5 <<  2)) & 0x1fff;\n    t6 = m[mpos+12] & 0xff | (m[mpos+13] & 0xff) << 8; h7 += ((t5 >>> 11) | (t6 <<  5)) & 0x1fff;\n    t7 = m[mpos+14] & 0xff | (m[mpos+15] & 0xff) << 8; h8 += ((t6 >>>  8) | (t7 <<  8)) & 0x1fff;\n    h9 += ((t7 >>> 5)) | hibit;\n\n    c = 0;\n\n    d0 = c;\n    d0 += h0 * r0;\n    d0 += h1 * (5 * r9);\n    d0 += h2 * (5 * r8);\n    d0 += h3 * (5 * r7);\n    d0 += h4 * (5 * r6);\n    c = (d0 >>> 13); d0 &= 0x1fff;\n    d0 += h5 * (5 * r5);\n    d0 += h6 * (5 * r4);\n    d0 += h7 * (5 * r3);\n    d0 += h8 * (5 * r2);\n    d0 += h9 * (5 * r1);\n    c += (d0 >>> 13); d0 &= 0x1fff;\n\n    d1 = c;\n    d1 += h0 * r1;\n    d1 += h1 * r0;\n    d1 += h2 * (5 * r9);\n    d1 += h3 * (5 * r8);\n    d1 += h4 * (5 * r7);\n    c = (d1 >>> 13); d1 &= 0x1fff;\n    d1 += h5 * (5 * r6);\n    d1 += h6 * (5 * r5);\n    d1 += h7 * (5 * r4);\n    d1 += h8 * (5 * r3);\n    d1 += h9 * (5 * r2);\n    c += (d1 >>> 13); d1 &= 0x1fff;\n\n    d2 = c;\n    d2 += h0 * r2;\n    d2 += h1 * r1;\n    d2 += h2 * r0;\n    d2 += h3 * (5 * r9);\n    d2 += h4 * (5 * r8);\n    c = (d2 >>> 13); d2 &= 0x1fff;\n    d2 += h5 * (5 * r7);\n    d2 += h6 * (5 * r6);\n    d2 += h7 * (5 * r5);\n    d2 += h8 * (5 * r4);\n    d2 += h9 * (5 * r3);\n    c += (d2 >>> 13); d2 &= 0x1fff;\n\n    d3 = c;\n    d3 += h0 * r3;\n    d3 += h1 * r2;\n    d3 += h2 * r1;\n    d3 += h3 * r0;\n    d3 += h4 * (5 * r9);\n    c = (d3 >>> 13); d3 &= 0x1fff;\n    d3 += h5 * (5 * r8);\n    d3 += h6 * (5 * r7);\n    d3 += h7 * (5 * r6);\n    d3 += h8 * (5 * r5);\n    d3 += h9 * (5 * r4);\n    c += (d3 >>> 13); d3 &= 0x1fff;\n\n    d4 = c;\n    d4 += h0 * r4;\n    d4 += h1 * r3;\n    d4 += h2 * r2;\n    d4 += h3 * r1;\n    d4 += h4 * r0;\n    c = (d4 >>> 13); d4 &= 0x1fff;\n    d4 += h5 * (5 * r9);\n    d4 += h6 * (5 * r8);\n    d4 += h7 * (5 * r7);\n    d4 += h8 * (5 * r6);\n    d4 += h9 * (5 * r5);\n    c += (d4 >>> 13); d4 &= 0x1fff;\n\n    d5 = c;\n    d5 += h0 * r5;\n    d5 += h1 * r4;\n    d5 += h2 * r3;\n    d5 += h3 * r2;\n    d5 += h4 * r1;\n    c = (d5 >>> 13); d5 &= 0x1fff;\n    d5 += h5 * r0;\n    d5 += h6 * (5 * r9);\n    d5 += h7 * (5 * r8);\n    d5 += h8 * (5 * r7);\n    d5 += h9 * (5 * r6);\n    c += (d5 >>> 13); d5 &= 0x1fff;\n\n    d6 = c;\n    d6 += h0 * r6;\n    d6 += h1 * r5;\n    d6 += h2 * r4;\n    d6 += h3 * r3;\n    d6 += h4 * r2;\n    c = (d6 >>> 13); d6 &= 0x1fff;\n    d6 += h5 * r1;\n    d6 += h6 * r0;\n    d6 += h7 * (5 * r9);\n    d6 += h8 * (5 * r8);\n    d6 += h9 * (5 * r7);\n    c += (d6 >>> 13); d6 &= 0x1fff;\n\n    d7 = c;\n    d7 += h0 * r7;\n    d7 += h1 * r6;\n    d7 += h2 * r5;\n    d7 += h3 * r4;\n    d7 += h4 * r3;\n    c = (d7 >>> 13); d7 &= 0x1fff;\n    d7 += h5 * r2;\n    d7 += h6 * r1;\n    d7 += h7 * r0;\n    d7 += h8 * (5 * r9);\n    d7 += h9 * (5 * r8);\n    c += (d7 >>> 13); d7 &= 0x1fff;\n\n    d8 = c;\n    d8 += h0 * r8;\n    d8 += h1 * r7;\n    d8 += h2 * r6;\n    d8 += h3 * r5;\n    d8 += h4 * r4;\n    c = (d8 >>> 13); d8 &= 0x1fff;\n    d8 += h5 * r3;\n    d8 += h6 * r2;\n    d8 += h7 * r1;\n    d8 += h8 * r0;\n    d8 += h9 * (5 * r9);\n    c += (d8 >>> 13); d8 &= 0x1fff;\n\n    d9 = c;\n    d9 += h0 * r9;\n    d9 += h1 * r8;\n    d9 += h2 * r7;\n    d9 += h3 * r6;\n    d9 += h4 * r5;\n    c = (d9 >>> 13); d9 &= 0x1fff;\n    d9 += h5 * r4;\n    d9 += h6 * r3;\n    d9 += h7 * r2;\n    d9 += h8 * r1;\n    d9 += h9 * r0;\n    c += (d9 >>> 13); d9 &= 0x1fff;\n\n    c = (((c << 2) + c)) | 0;\n    c = (c + d0) | 0;\n    d0 = c & 0x1fff;\n    c = (c >>> 13);\n    d1 += c;\n\n    h0 = d0;\n    h1 = d1;\n    h2 = d2;\n    h3 = d3;\n    h4 = d4;\n    h5 = d5;\n    h6 = d6;\n    h7 = d7;\n    h8 = d8;\n    h9 = d9;\n\n    mpos += 16;\n    bytes -= 16;\n  }\n  this.h[0] = h0;\n  this.h[1] = h1;\n  this.h[2] = h2;\n  this.h[3] = h3;\n  this.h[4] = h4;\n  this.h[5] = h5;\n  this.h[6] = h6;\n  this.h[7] = h7;\n  this.h[8] = h8;\n  this.h[9] = h9;\n};\n\npoly1305.prototype.finish = function(mac, macpos) {\n  var g = new Uint16Array(10);\n  var c, mask, f, i;\n\n  if (this.leftover) {\n    i = this.leftover;\n    this.buffer[i++] = 1;\n    for (; i < 16; i++) this.buffer[i] = 0;\n    this.fin = 1;\n    this.blocks(this.buffer, 0, 16);\n  }\n\n  c = this.h[1] >>> 13;\n  this.h[1] &= 0x1fff;\n  for (i = 2; i < 10; i++) {\n    this.h[i] += c;\n    c = this.h[i] >>> 13;\n    this.h[i] &= 0x1fff;\n  }\n  this.h[0] += (c * 5);\n  c = this.h[0] >>> 13;\n  this.h[0] &= 0x1fff;\n  this.h[1] += c;\n  c = this.h[1] >>> 13;\n  this.h[1] &= 0x1fff;\n  this.h[2] += c;\n\n  g[0] = this.h[0] + 5;\n  c = g[0] >>> 13;\n  g[0] &= 0x1fff;\n  for (i = 1; i < 10; i++) {\n    g[i] = this.h[i] + c;\n    c = g[i] >>> 13;\n    g[i] &= 0x1fff;\n  }\n  g[9] -= (1 << 13);\n\n  mask = (c ^ 1) - 1;\n  for (i = 0; i < 10; i++) g[i] &= mask;\n  mask = ~mask;\n  for (i = 0; i < 10; i++) this.h[i] = (this.h[i] & mask) | g[i];\n\n  this.h[0] = ((this.h[0]       ) | (this.h[1] << 13)                    ) & 0xffff;\n  this.h[1] = ((this.h[1] >>>  3) | (this.h[2] << 10)                    ) & 0xffff;\n  this.h[2] = ((this.h[2] >>>  6) | (this.h[3] <<  7)                    ) & 0xffff;\n  this.h[3] = ((this.h[3] >>>  9) | (this.h[4] <<  4)                    ) & 0xffff;\n  this.h[4] = ((this.h[4] >>> 12) | (this.h[5] <<  1) | (this.h[6] << 14)) & 0xffff;\n  this.h[5] = ((this.h[6] >>>  2) | (this.h[7] << 11)                    ) & 0xffff;\n  this.h[6] = ((this.h[7] >>>  5) | (this.h[8] <<  8)                    ) & 0xffff;\n  this.h[7] = ((this.h[8] >>>  8) | (this.h[9] <<  5)                    ) & 0xffff;\n\n  f = this.h[0] + this.pad[0];\n  this.h[0] = f & 0xffff;\n  for (i = 1; i < 8; i++) {\n    f = (((this.h[i] + this.pad[i]) | 0) + (f >>> 16)) | 0;\n    this.h[i] = f & 0xffff;\n  }\n\n  mac[macpos+ 0] = (this.h[0] >>> 0) & 0xff;\n  mac[macpos+ 1] = (this.h[0] >>> 8) & 0xff;\n  mac[macpos+ 2] = (this.h[1] >>> 0) & 0xff;\n  mac[macpos+ 3] = (this.h[1] >>> 8) & 0xff;\n  mac[macpos+ 4] = (this.h[2] >>> 0) & 0xff;\n  mac[macpos+ 5] = (this.h[2] >>> 8) & 0xff;\n  mac[macpos+ 6] = (this.h[3] >>> 0) & 0xff;\n  mac[macpos+ 7] = (this.h[3] >>> 8) & 0xff;\n  mac[macpos+ 8] = (this.h[4] >>> 0) & 0xff;\n  mac[macpos+ 9] = (this.h[4] >>> 8) & 0xff;\n  mac[macpos+10] = (this.h[5] >>> 0) & 0xff;\n  mac[macpos+11] = (this.h[5] >>> 8) & 0xff;\n  mac[macpos+12] = (this.h[6] >>> 0) & 0xff;\n  mac[macpos+13] = (this.h[6] >>> 8) & 0xff;\n  mac[macpos+14] = (this.h[7] >>> 0) & 0xff;\n  mac[macpos+15] = (this.h[7] >>> 8) & 0xff;\n};\n\npoly1305.prototype.update = function(m, mpos, bytes) {\n  var i, want;\n\n  if (this.leftover) {\n    want = (16 - this.leftover);\n    if (want > bytes)\n      want = bytes;\n    for (i = 0; i < want; i++)\n      this.buffer[this.leftover + i] = m[mpos+i];\n    bytes -= want;\n    mpos += want;\n    this.leftover += want;\n    if (this.leftover < 16)\n      return;\n    this.blocks(this.buffer, 0, 16);\n    this.leftover = 0;\n  }\n\n  if (bytes >= 16) {\n    want = bytes - (bytes % 16);\n    this.blocks(m, mpos, want);\n    mpos += want;\n    bytes -= want;\n  }\n\n  if (bytes) {\n    for (i = 0; i < bytes; i++)\n      this.buffer[this.leftover + i] = m[mpos+i];\n    this.leftover += bytes;\n  }\n};\n\nfunction crypto_onetimeauth(out, outpos, m, mpos, n, k) {\n  var s = new poly1305(k);\n  s.update(m, mpos, n);\n  s.finish(out, outpos);\n  return 0;\n}\n\nfunction crypto_onetimeauth_verify(h, hpos, m, mpos, n, k) {\n  var x = new Uint8Array(16);\n  crypto_onetimeauth(x,0,m,mpos,n,k);\n  return crypto_verify_16(h,hpos,x,0);\n}\n\nfunction crypto_secretbox(c,m,d,n,k) {\n  var i;\n  if (d < 32) return -1;\n  crypto_stream_xor(c,0,m,0,d,n,k);\n  crypto_onetimeauth(c, 16, c, 32, d - 32, c);\n  for (i = 0; i < 16; i++) c[i] = 0;\n  return 0;\n}\n\nfunction crypto_secretbox_open(m,c,d,n,k) {\n  var i;\n  var x = new Uint8Array(32);\n  if (d < 32) return -1;\n  crypto_stream(x,0,32,n,k);\n  if (crypto_onetimeauth_verify(c, 16,c, 32,d - 32,x) !== 0) return -1;\n  crypto_stream_xor(m,0,c,0,d,n,k);\n  for (i = 0; i < 32; i++) m[i] = 0;\n  return 0;\n}\n\nfunction set25519(r, a) {\n  var i;\n  for (i = 0; i < 16; i++) r[i] = a[i]|0;\n}\n\nfunction car25519(o) {\n  var i, v, c = 1;\n  for (i = 0; i < 16; i++) {\n    v = o[i] + c + 65535;\n    c = Math.floor(v / 65536);\n    o[i] = v - c * 65536;\n  }\n  o[0] += c-1 + 37 * (c-1);\n}\n\nfunction sel25519(p, q, b) {\n  var t, c = ~(b-1);\n  for (var i = 0; i < 16; i++) {\n    t = c & (p[i] ^ q[i]);\n    p[i] ^= t;\n    q[i] ^= t;\n  }\n}\n\nfunction pack25519(o, n) {\n  var i, j, b;\n  var m = gf(), t = gf();\n  for (i = 0; i < 16; i++) t[i] = n[i];\n  car25519(t);\n  car25519(t);\n  car25519(t);\n  for (j = 0; j < 2; j++) {\n    m[0] = t[0] - 0xffed;\n    for (i = 1; i < 15; i++) {\n      m[i] = t[i] - 0xffff - ((m[i-1]>>16) & 1);\n      m[i-1] &= 0xffff;\n    }\n    m[15] = t[15] - 0x7fff - ((m[14]>>16) & 1);\n    b = (m[15]>>16) & 1;\n    m[14] &= 0xffff;\n    sel25519(t, m, 1-b);\n  }\n  for (i = 0; i < 16; i++) {\n    o[2*i] = t[i] & 0xff;\n    o[2*i+1] = t[i]>>8;\n  }\n}\n\nfunction neq25519(a, b) {\n  var c = new Uint8Array(32), d = new Uint8Array(32);\n  pack25519(c, a);\n  pack25519(d, b);\n  return crypto_verify_32(c, 0, d, 0);\n}\n\nfunction par25519(a) {\n  var d = new Uint8Array(32);\n  pack25519(d, a);\n  return d[0] & 1;\n}\n\nfunction unpack25519(o, n) {\n  var i;\n  for (i = 0; i < 16; i++) o[i] = n[2*i] + (n[2*i+1] << 8);\n  o[15] &= 0x7fff;\n}\n\nfunction A(o, a, b) {\n  for (var i = 0; i < 16; i++) o[i] = a[i] + b[i];\n}\n\nfunction Z(o, a, b) {\n  for (var i = 0; i < 16; i++) o[i] = a[i] - b[i];\n}\n\nfunction M(o, a, b) {\n  var v, c,\n     t0 = 0,  t1 = 0,  t2 = 0,  t3 = 0,  t4 = 0,  t5 = 0,  t6 = 0,  t7 = 0,\n     t8 = 0,  t9 = 0, t10 = 0, t11 = 0, t12 = 0, t13 = 0, t14 = 0, t15 = 0,\n    t16 = 0, t17 = 0, t18 = 0, t19 = 0, t20 = 0, t21 = 0, t22 = 0, t23 = 0,\n    t24 = 0, t25 = 0, t26 = 0, t27 = 0, t28 = 0, t29 = 0, t30 = 0,\n    b0 = b[0],\n    b1 = b[1],\n    b2 = b[2],\n    b3 = b[3],\n    b4 = b[4],\n    b5 = b[5],\n    b6 = b[6],\n    b7 = b[7],\n    b8 = b[8],\n    b9 = b[9],\n    b10 = b[10],\n    b11 = b[11],\n    b12 = b[12],\n    b13 = b[13],\n    b14 = b[14],\n    b15 = b[15];\n\n  v = a[0];\n  t0 += v * b0;\n  t1 += v * b1;\n  t2 += v * b2;\n  t3 += v * b3;\n  t4 += v * b4;\n  t5 += v * b5;\n  t6 += v * b6;\n  t7 += v * b7;\n  t8 += v * b8;\n  t9 += v * b9;\n  t10 += v * b10;\n  t11 += v * b11;\n  t12 += v * b12;\n  t13 += v * b13;\n  t14 += v * b14;\n  t15 += v * b15;\n  v = a[1];\n  t1 += v * b0;\n  t2 += v * b1;\n  t3 += v * b2;\n  t4 += v * b3;\n  t5 += v * b4;\n  t6 += v * b5;\n  t7 += v * b6;\n  t8 += v * b7;\n  t9 += v * b8;\n  t10 += v * b9;\n  t11 += v * b10;\n  t12 += v * b11;\n  t13 += v * b12;\n  t14 += v * b13;\n  t15 += v * b14;\n  t16 += v * b15;\n  v = a[2];\n  t2 += v * b0;\n  t3 += v * b1;\n  t4 += v * b2;\n  t5 += v * b3;\n  t6 += v * b4;\n  t7 += v * b5;\n  t8 += v * b6;\n  t9 += v * b7;\n  t10 += v * b8;\n  t11 += v * b9;\n  t12 += v * b10;\n  t13 += v * b11;\n  t14 += v * b12;\n  t15 += v * b13;\n  t16 += v * b14;\n  t17 += v * b15;\n  v = a[3];\n  t3 += v * b0;\n  t4 += v * b1;\n  t5 += v * b2;\n  t6 += v * b3;\n  t7 += v * b4;\n  t8 += v * b5;\n  t9 += v * b6;\n  t10 += v * b7;\n  t11 += v * b8;\n  t12 += v * b9;\n  t13 += v * b10;\n  t14 += v * b11;\n  t15 += v * b12;\n  t16 += v * b13;\n  t17 += v * b14;\n  t18 += v * b15;\n  v = a[4];\n  t4 += v * b0;\n  t5 += v * b1;\n  t6 += v * b2;\n  t7 += v * b3;\n  t8 += v * b4;\n  t9 += v * b5;\n  t10 += v * b6;\n  t11 += v * b7;\n  t12 += v * b8;\n  t13 += v * b9;\n  t14 += v * b10;\n  t15 += v * b11;\n  t16 += v * b12;\n  t17 += v * b13;\n  t18 += v * b14;\n  t19 += v * b15;\n  v = a[5];\n  t5 += v * b0;\n  t6 += v * b1;\n  t7 += v * b2;\n  t8 += v * b3;\n  t9 += v * b4;\n  t10 += v * b5;\n  t11 += v * b6;\n  t12 += v * b7;\n  t13 += v * b8;\n  t14 += v * b9;\n  t15 += v * b10;\n  t16 += v * b11;\n  t17 += v * b12;\n  t18 += v * b13;\n  t19 += v * b14;\n  t20 += v * b15;\n  v = a[6];\n  t6 += v * b0;\n  t7 += v * b1;\n  t8 += v * b2;\n  t9 += v * b3;\n  t10 += v * b4;\n  t11 += v * b5;\n  t12 += v * b6;\n  t13 += v * b7;\n  t14 += v * b8;\n  t15 += v * b9;\n  t16 += v * b10;\n  t17 += v * b11;\n  t18 += v * b12;\n  t19 += v * b13;\n  t20 += v * b14;\n  t21 += v * b15;\n  v = a[7];\n  t7 += v * b0;\n  t8 += v * b1;\n  t9 += v * b2;\n  t10 += v * b3;\n  t11 += v * b4;\n  t12 += v * b5;\n  t13 += v * b6;\n  t14 += v * b7;\n  t15 += v * b8;\n  t16 += v * b9;\n  t17 += v * b10;\n  t18 += v * b11;\n  t19 += v * b12;\n  t20 += v * b13;\n  t21 += v * b14;\n  t22 += v * b15;\n  v = a[8];\n  t8 += v * b0;\n  t9 += v * b1;\n  t10 += v * b2;\n  t11 += v * b3;\n  t12 += v * b4;\n  t13 += v * b5;\n  t14 += v * b6;\n  t15 += v * b7;\n  t16 += v * b8;\n  t17 += v * b9;\n  t18 += v * b10;\n  t19 += v * b11;\n  t20 += v * b12;\n  t21 += v * b13;\n  t22 += v * b14;\n  t23 += v * b15;\n  v = a[9];\n  t9 += v * b0;\n  t10 += v * b1;\n  t11 += v * b2;\n  t12 += v * b3;\n  t13 += v * b4;\n  t14 += v * b5;\n  t15 += v * b6;\n  t16 += v * b7;\n  t17 += v * b8;\n  t18 += v * b9;\n  t19 += v * b10;\n  t20 += v * b11;\n  t21 += v * b12;\n  t22 += v * b13;\n  t23 += v * b14;\n  t24 += v * b15;\n  v = a[10];\n  t10 += v * b0;\n  t11 += v * b1;\n  t12 += v * b2;\n  t13 += v * b3;\n  t14 += v * b4;\n  t15 += v * b5;\n  t16 += v * b6;\n  t17 += v * b7;\n  t18 += v * b8;\n  t19 += v * b9;\n  t20 += v * b10;\n  t21 += v * b11;\n  t22 += v * b12;\n  t23 += v * b13;\n  t24 += v * b14;\n  t25 += v * b15;\n  v = a[11];\n  t11 += v * b0;\n  t12 += v * b1;\n  t13 += v * b2;\n  t14 += v * b3;\n  t15 += v * b4;\n  t16 += v * b5;\n  t17 += v * b6;\n  t18 += v * b7;\n  t19 += v * b8;\n  t20 += v * b9;\n  t21 += v * b10;\n  t22 += v * b11;\n  t23 += v * b12;\n  t24 += v * b13;\n  t25 += v * b14;\n  t26 += v * b15;\n  v = a[12];\n  t12 += v * b0;\n  t13 += v * b1;\n  t14 += v * b2;\n  t15 += v * b3;\n  t16 += v * b4;\n  t17 += v * b5;\n  t18 += v * b6;\n  t19 += v * b7;\n  t20 += v * b8;\n  t21 += v * b9;\n  t22 += v * b10;\n  t23 += v * b11;\n  t24 += v * b12;\n  t25 += v * b13;\n  t26 += v * b14;\n  t27 += v * b15;\n  v = a[13];\n  t13 += v * b0;\n  t14 += v * b1;\n  t15 += v * b2;\n  t16 += v * b3;\n  t17 += v * b4;\n  t18 += v * b5;\n  t19 += v * b6;\n  t20 += v * b7;\n  t21 += v * b8;\n  t22 += v * b9;\n  t23 += v * b10;\n  t24 += v * b11;\n  t25 += v * b12;\n  t26 += v * b13;\n  t27 += v * b14;\n  t28 += v * b15;\n  v = a[14];\n  t14 += v * b0;\n  t15 += v * b1;\n  t16 += v * b2;\n  t17 += v * b3;\n  t18 += v * b4;\n  t19 += v * b5;\n  t20 += v * b6;\n  t21 += v * b7;\n  t22 += v * b8;\n  t23 += v * b9;\n  t24 += v * b10;\n  t25 += v * b11;\n  t26 += v * b12;\n  t27 += v * b13;\n  t28 += v * b14;\n  t29 += v * b15;\n  v = a[15];\n  t15 += v * b0;\n  t16 += v * b1;\n  t17 += v * b2;\n  t18 += v * b3;\n  t19 += v * b4;\n  t20 += v * b5;\n  t21 += v * b6;\n  t22 += v * b7;\n  t23 += v * b8;\n  t24 += v * b9;\n  t25 += v * b10;\n  t26 += v * b11;\n  t27 += v * b12;\n  t28 += v * b13;\n  t29 += v * b14;\n  t30 += v * b15;\n\n  t0  += 38 * t16;\n  t1  += 38 * t17;\n  t2  += 38 * t18;\n  t3  += 38 * t19;\n  t4  += 38 * t20;\n  t5  += 38 * t21;\n  t6  += 38 * t22;\n  t7  += 38 * t23;\n  t8  += 38 * t24;\n  t9  += 38 * t25;\n  t10 += 38 * t26;\n  t11 += 38 * t27;\n  t12 += 38 * t28;\n  t13 += 38 * t29;\n  t14 += 38 * t30;\n  // t15 left as is\n\n  // first car\n  c = 1;\n  v =  t0 + c + 65535; c = Math.floor(v / 65536);  t0 = v - c * 65536;\n  v =  t1 + c + 65535; c = Math.floor(v / 65536);  t1 = v - c * 65536;\n  v =  t2 + c + 65535; c = Math.floor(v / 65536);  t2 = v - c * 65536;\n  v =  t3 + c + 65535; c = Math.floor(v / 65536);  t3 = v - c * 65536;\n  v =  t4 + c + 65535; c = Math.floor(v / 65536);  t4 = v - c * 65536;\n  v =  t5 + c + 65535; c = Math.floor(v / 65536);  t5 = v - c * 65536;\n  v =  t6 + c + 65535; c = Math.floor(v / 65536);  t6 = v - c * 65536;\n  v =  t7 + c + 65535; c = Math.floor(v / 65536);  t7 = v - c * 65536;\n  v =  t8 + c + 65535; c = Math.floor(v / 65536);  t8 = v - c * 65536;\n  v =  t9 + c + 65535; c = Math.floor(v / 65536);  t9 = v - c * 65536;\n  v = t10 + c + 65535; c = Math.floor(v / 65536); t10 = v - c * 65536;\n  v = t11 + c + 65535; c = Math.floor(v / 65536); t11 = v - c * 65536;\n  v = t12 + c + 65535; c = Math.floor(v / 65536); t12 = v - c * 65536;\n  v = t13 + c + 65535; c = Math.floor(v / 65536); t13 = v - c * 65536;\n  v = t14 + c + 65535; c = Math.floor(v / 65536); t14 = v - c * 65536;\n  v = t15 + c + 65535; c = Math.floor(v / 65536); t15 = v - c * 65536;\n  t0 += c-1 + 37 * (c-1);\n\n  // second car\n  c = 1;\n  v =  t0 + c + 65535; c = Math.floor(v / 65536);  t0 = v - c * 65536;\n  v =  t1 + c + 65535; c = Math.floor(v / 65536);  t1 = v - c * 65536;\n  v =  t2 + c + 65535; c = Math.floor(v / 65536);  t2 = v - c * 65536;\n  v =  t3 + c + 65535; c = Math.floor(v / 65536);  t3 = v - c * 65536;\n  v =  t4 + c + 65535; c = Math.floor(v / 65536);  t4 = v - c * 65536;\n  v =  t5 + c + 65535; c = Math.floor(v / 65536);  t5 = v - c * 65536;\n  v =  t6 + c + 65535; c = Math.floor(v / 65536);  t6 = v - c * 65536;\n  v =  t7 + c + 65535; c = Math.floor(v / 65536);  t7 = v - c * 65536;\n  v =  t8 + c + 65535; c = Math.floor(v / 65536);  t8 = v - c * 65536;\n  v =  t9 + c + 65535; c = Math.floor(v / 65536);  t9 = v - c * 65536;\n  v = t10 + c + 65535; c = Math.floor(v / 65536); t10 = v - c * 65536;\n  v = t11 + c + 65535; c = Math.floor(v / 65536); t11 = v - c * 65536;\n  v = t12 + c + 65535; c = Math.floor(v / 65536); t12 = v - c * 65536;\n  v = t13 + c + 65535; c = Math.floor(v / 65536); t13 = v - c * 65536;\n  v = t14 + c + 65535; c = Math.floor(v / 65536); t14 = v - c * 65536;\n  v = t15 + c + 65535; c = Math.floor(v / 65536); t15 = v - c * 65536;\n  t0 += c-1 + 37 * (c-1);\n\n  o[ 0] = t0;\n  o[ 1] = t1;\n  o[ 2] = t2;\n  o[ 3] = t3;\n  o[ 4] = t4;\n  o[ 5] = t5;\n  o[ 6] = t6;\n  o[ 7] = t7;\n  o[ 8] = t8;\n  o[ 9] = t9;\n  o[10] = t10;\n  o[11] = t11;\n  o[12] = t12;\n  o[13] = t13;\n  o[14] = t14;\n  o[15] = t15;\n}\n\nfunction S(o, a) {\n  M(o, a, a);\n}\n\nfunction inv25519(o, i) {\n  var c = gf();\n  var a;\n  for (a = 0; a < 16; a++) c[a] = i[a];\n  for (a = 253; a >= 0; a--) {\n    S(c, c);\n    if(a !== 2 && a !== 4) M(c, c, i);\n  }\n  for (a = 0; a < 16; a++) o[a] = c[a];\n}\n\nfunction pow2523(o, i) {\n  var c = gf();\n  var a;\n  for (a = 0; a < 16; a++) c[a] = i[a];\n  for (a = 250; a >= 0; a--) {\n      S(c, c);\n      if(a !== 1) M(c, c, i);\n  }\n  for (a = 0; a < 16; a++) o[a] = c[a];\n}\n\nfunction crypto_scalarmult(q, n, p) {\n  var z = new Uint8Array(32);\n  var x = new Float64Array(80), r, i;\n  var a = gf(), b = gf(), c = gf(),\n      d = gf(), e = gf(), f = gf();\n  for (i = 0; i < 31; i++) z[i] = n[i];\n  z[31]=(n[31]&127)|64;\n  z[0]&=248;\n  unpack25519(x,p);\n  for (i = 0; i < 16; i++) {\n    b[i]=x[i];\n    d[i]=a[i]=c[i]=0;\n  }\n  a[0]=d[0]=1;\n  for (i=254; i>=0; --i) {\n    r=(z[i>>>3]>>>(i&7))&1;\n    sel25519(a,b,r);\n    sel25519(c,d,r);\n    A(e,a,c);\n    Z(a,a,c);\n    A(c,b,d);\n    Z(b,b,d);\n    S(d,e);\n    S(f,a);\n    M(a,c,a);\n    M(c,b,e);\n    A(e,a,c);\n    Z(a,a,c);\n    S(b,a);\n    Z(c,d,f);\n    M(a,c,_121665);\n    A(a,a,d);\n    M(c,c,a);\n    M(a,d,f);\n    M(d,b,x);\n    S(b,e);\n    sel25519(a,b,r);\n    sel25519(c,d,r);\n  }\n  for (i = 0; i < 16; i++) {\n    x[i+16]=a[i];\n    x[i+32]=c[i];\n    x[i+48]=b[i];\n    x[i+64]=d[i];\n  }\n  var x32 = x.subarray(32);\n  var x16 = x.subarray(16);\n  inv25519(x32,x32);\n  M(x16,x16,x32);\n  pack25519(q,x16);\n  return 0;\n}\n\nfunction crypto_scalarmult_base(q, n) {\n  return crypto_scalarmult(q, n, _9);\n}\n\nfunction crypto_box_keypair(y, x) {\n  randombytes(x, 32);\n  return crypto_scalarmult_base(y, x);\n}\n\nfunction crypto_box_beforenm(k, y, x) {\n  var s = new Uint8Array(32);\n  crypto_scalarmult(s, x, y);\n  return crypto_core_hsalsa20(k, _0, s, sigma);\n}\n\nvar crypto_box_afternm = crypto_secretbox;\nvar crypto_box_open_afternm = crypto_secretbox_open;\n\nfunction crypto_box(c, m, d, n, y, x) {\n  var k = new Uint8Array(32);\n  crypto_box_beforenm(k, y, x);\n  return crypto_box_afternm(c, m, d, n, k);\n}\n\nfunction crypto_box_open(m, c, d, n, y, x) {\n  var k = new Uint8Array(32);\n  crypto_box_beforenm(k, y, x);\n  return crypto_box_open_afternm(m, c, d, n, k);\n}\n\nvar K = [\n  0x428a2f98, 0xd728ae22, 0x71374491, 0x23ef65cd,\n  0xb5c0fbcf, 0xec4d3b2f, 0xe9b5dba5, 0x8189dbbc,\n  0x3956c25b, 0xf348b538, 0x59f111f1, 0xb605d019,\n  0x923f82a4, 0xaf194f9b, 0xab1c5ed5, 0xda6d8118,\n  0xd807aa98, 0xa3030242, 0x12835b01, 0x45706fbe,\n  0x243185be, 0x4ee4b28c, 0x550c7dc3, 0xd5ffb4e2,\n  0x72be5d74, 0xf27b896f, 0x80deb1fe, 0x3b1696b1,\n  0x9bdc06a7, 0x25c71235, 0xc19bf174, 0xcf692694,\n  0xe49b69c1, 0x9ef14ad2, 0xefbe4786, 0x384f25e3,\n  0x0fc19dc6, 0x8b8cd5b5, 0x240ca1cc, 0x77ac9c65,\n  0x2de92c6f, 0x592b0275, 0x4a7484aa, 0x6ea6e483,\n  0x5cb0a9dc, 0xbd41fbd4, 0x76f988da, 0x831153b5,\n  0x983e5152, 0xee66dfab, 0xa831c66d, 0x2db43210,\n  0xb00327c8, 0x98fb213f, 0xbf597fc7, 0xbeef0ee4,\n  0xc6e00bf3, 0x3da88fc2, 0xd5a79147, 0x930aa725,\n  0x06ca6351, 0xe003826f, 0x14292967, 0x0a0e6e70,\n  0x27b70a85, 0x46d22ffc, 0x2e1b2138, 0x5c26c926,\n  0x4d2c6dfc, 0x5ac42aed, 0x53380d13, 0x9d95b3df,\n  0x650a7354, 0x8baf63de, 0x766a0abb, 0x3c77b2a8,\n  0x81c2c92e, 0x47edaee6, 0x92722c85, 0x1482353b,\n  0xa2bfe8a1, 0x4cf10364, 0xa81a664b, 0xbc423001,\n  0xc24b8b70, 0xd0f89791, 0xc76c51a3, 0x0654be30,\n  0xd192e819, 0xd6ef5218, 0xd6990624, 0x5565a910,\n  0xf40e3585, 0x5771202a, 0x106aa070, 0x32bbd1b8,\n  0x19a4c116, 0xb8d2d0c8, 0x1e376c08, 0x5141ab53,\n  0x2748774c, 0xdf8eeb99, 0x34b0bcb5, 0xe19b48a8,\n  0x391c0cb3, 0xc5c95a63, 0x4ed8aa4a, 0xe3418acb,\n  0x5b9cca4f, 0x7763e373, 0x682e6ff3, 0xd6b2b8a3,\n  0x748f82ee, 0x5defb2fc, 0x78a5636f, 0x43172f60,\n  0x84c87814, 0xa1f0ab72, 0x8cc70208, 0x1a6439ec,\n  0x90befffa, 0x23631e28, 0xa4506ceb, 0xde82bde9,\n  0xbef9a3f7, 0xb2c67915, 0xc67178f2, 0xe372532b,\n  0xca273ece, 0xea26619c, 0xd186b8c7, 0x21c0c207,\n  0xeada7dd6, 0xcde0eb1e, 0xf57d4f7f, 0xee6ed178,\n  0x06f067aa, 0x72176fba, 0x0a637dc5, 0xa2c898a6,\n  0x113f9804, 0xbef90dae, 0x1b710b35, 0x131c471b,\n  0x28db77f5, 0x23047d84, 0x32caab7b, 0x40c72493,\n  0x3c9ebe0a, 0x15c9bebc, 0x431d67c4, 0x9c100d4c,\n  0x4cc5d4be, 0xcb3e42b6, 0x597f299c, 0xfc657e2a,\n  0x5fcb6fab, 0x3ad6faec, 0x6c44198c, 0x4a475817\n];\n\nfunction crypto_hashblocks_hl(hh, hl, m, n) {\n  var wh = new Int32Array(16), wl = new Int32Array(16),\n      bh0, bh1, bh2, bh3, bh4, bh5, bh6, bh7,\n      bl0, bl1, bl2, bl3, bl4, bl5, bl6, bl7,\n      th, tl, i, j, h, l, a, b, c, d;\n\n  var ah0 = hh[0],\n      ah1 = hh[1],\n      ah2 = hh[2],\n      ah3 = hh[3],\n      ah4 = hh[4],\n      ah5 = hh[5],\n      ah6 = hh[6],\n      ah7 = hh[7],\n\n      al0 = hl[0],\n      al1 = hl[1],\n      al2 = hl[2],\n      al3 = hl[3],\n      al4 = hl[4],\n      al5 = hl[5],\n      al6 = hl[6],\n      al7 = hl[7];\n\n  var pos = 0;\n  while (n >= 128) {\n    for (i = 0; i < 16; i++) {\n      j = 8 * i + pos;\n      wh[i] = (m[j+0] << 24) | (m[j+1] << 16) | (m[j+2] << 8) | m[j+3];\n      wl[i] = (m[j+4] << 24) | (m[j+5] << 16) | (m[j+6] << 8) | m[j+7];\n    }\n    for (i = 0; i < 80; i++) {\n      bh0 = ah0;\n      bh1 = ah1;\n      bh2 = ah2;\n      bh3 = ah3;\n      bh4 = ah4;\n      bh5 = ah5;\n      bh6 = ah6;\n      bh7 = ah7;\n\n      bl0 = al0;\n      bl1 = al1;\n      bl2 = al2;\n      bl3 = al3;\n      bl4 = al4;\n      bl5 = al5;\n      bl6 = al6;\n      bl7 = al7;\n\n      // add\n      h = ah7;\n      l = al7;\n\n      a = l & 0xffff; b = l >>> 16;\n      c = h & 0xffff; d = h >>> 16;\n\n      // Sigma1\n      h = ((ah4 >>> 14) | (al4 << (32-14))) ^ ((ah4 >>> 18) | (al4 << (32-18))) ^ ((al4 >>> (41-32)) | (ah4 << (32-(41-32))));\n      l = ((al4 >>> 14) | (ah4 << (32-14))) ^ ((al4 >>> 18) | (ah4 << (32-18))) ^ ((ah4 >>> (41-32)) | (al4 << (32-(41-32))));\n\n      a += l & 0xffff; b += l >>> 16;\n      c += h & 0xffff; d += h >>> 16;\n\n      // Ch\n      h = (ah4 & ah5) ^ (~ah4 & ah6);\n      l = (al4 & al5) ^ (~al4 & al6);\n\n      a += l & 0xffff; b += l >>> 16;\n      c += h & 0xffff; d += h >>> 16;\n\n      // K\n      h = K[i*2];\n      l = K[i*2+1];\n\n      a += l & 0xffff; b += l >>> 16;\n      c += h & 0xffff; d += h >>> 16;\n\n      // w\n      h = wh[i%16];\n      l = wl[i%16];\n\n      a += l & 0xffff; b += l >>> 16;\n      c += h & 0xffff; d += h >>> 16;\n\n      b += a >>> 16;\n      c += b >>> 16;\n      d += c >>> 16;\n\n      th = c & 0xffff | d << 16;\n      tl = a & 0xffff | b << 16;\n\n      // add\n      h = th;\n      l = tl;\n\n      a = l & 0xffff; b = l >>> 16;\n      c = h & 0xffff; d = h >>> 16;\n\n      // Sigma0\n      h = ((ah0 >>> 28) | (al0 << (32-28))) ^ ((al0 >>> (34-32)) | (ah0 << (32-(34-32)))) ^ ((al0 >>> (39-32)) | (ah0 << (32-(39-32))));\n      l = ((al0 >>> 28) | (ah0 << (32-28))) ^ ((ah0 >>> (34-32)) | (al0 << (32-(34-32)))) ^ ((ah0 >>> (39-32)) | (al0 << (32-(39-32))));\n\n      a += l & 0xffff; b += l >>> 16;\n      c += h & 0xffff; d += h >>> 16;\n\n      // Maj\n      h = (ah0 & ah1) ^ (ah0 & ah2) ^ (ah1 & ah2);\n      l = (al0 & al1) ^ (al0 & al2) ^ (al1 & al2);\n\n      a += l & 0xffff; b += l >>> 16;\n      c += h & 0xffff; d += h >>> 16;\n\n      b += a >>> 16;\n      c += b >>> 16;\n      d += c >>> 16;\n\n      bh7 = (c & 0xffff) | (d << 16);\n      bl7 = (a & 0xffff) | (b << 16);\n\n      // add\n      h = bh3;\n      l = bl3;\n\n      a = l & 0xffff; b = l >>> 16;\n      c = h & 0xffff; d = h >>> 16;\n\n      h = th;\n      l = tl;\n\n      a += l & 0xffff; b += l >>> 16;\n      c += h & 0xffff; d += h >>> 16;\n\n      b += a >>> 16;\n      c += b >>> 16;\n      d += c >>> 16;\n\n      bh3 = (c & 0xffff) | (d << 16);\n      bl3 = (a & 0xffff) | (b << 16);\n\n      ah1 = bh0;\n      ah2 = bh1;\n      ah3 = bh2;\n      ah4 = bh3;\n      ah5 = bh4;\n      ah6 = bh5;\n      ah7 = bh6;\n      ah0 = bh7;\n\n      al1 = bl0;\n      al2 = bl1;\n      al3 = bl2;\n      al4 = bl3;\n      al5 = bl4;\n      al6 = bl5;\n      al7 = bl6;\n      al0 = bl7;\n\n      if (i%16 === 15) {\n        for (j = 0; j < 16; j++) {\n          // add\n          h = wh[j];\n          l = wl[j];\n\n          a = l & 0xffff; b = l >>> 16;\n          c = h & 0xffff; d = h >>> 16;\n\n          h = wh[(j+9)%16];\n          l = wl[(j+9)%16];\n\n          a += l & 0xffff; b += l >>> 16;\n          c += h & 0xffff; d += h >>> 16;\n\n          // sigma0\n          th = wh[(j+1)%16];\n          tl = wl[(j+1)%16];\n          h = ((th >>> 1) | (tl << (32-1))) ^ ((th >>> 8) | (tl << (32-8))) ^ (th >>> 7);\n          l = ((tl >>> 1) | (th << (32-1))) ^ ((tl >>> 8) | (th << (32-8))) ^ ((tl >>> 7) | (th << (32-7)));\n\n          a += l & 0xffff; b += l >>> 16;\n          c += h & 0xffff; d += h >>> 16;\n\n          // sigma1\n          th = wh[(j+14)%16];\n          tl = wl[(j+14)%16];\n          h = ((th >>> 19) | (tl << (32-19))) ^ ((tl >>> (61-32)) | (th << (32-(61-32)))) ^ (th >>> 6);\n          l = ((tl >>> 19) | (th << (32-19))) ^ ((th >>> (61-32)) | (tl << (32-(61-32)))) ^ ((tl >>> 6) | (th << (32-6)));\n\n          a += l & 0xffff; b += l >>> 16;\n          c += h & 0xffff; d += h >>> 16;\n\n          b += a >>> 16;\n          c += b >>> 16;\n          d += c >>> 16;\n\n          wh[j] = (c & 0xffff) | (d << 16);\n          wl[j] = (a & 0xffff) | (b << 16);\n        }\n      }\n    }\n\n    // add\n    h = ah0;\n    l = al0;\n\n    a = l & 0xffff; b = l >>> 16;\n    c = h & 0xffff; d = h >>> 16;\n\n    h = hh[0];\n    l = hl[0];\n\n    a += l & 0xffff; b += l >>> 16;\n    c += h & 0xffff; d += h >>> 16;\n\n    b += a >>> 16;\n    c += b >>> 16;\n    d += c >>> 16;\n\n    hh[0] = ah0 = (c & 0xffff) | (d << 16);\n    hl[0] = al0 = (a & 0xffff) | (b << 16);\n\n    h = ah1;\n    l = al1;\n\n    a = l & 0xffff; b = l >>> 16;\n    c = h & 0xffff; d = h >>> 16;\n\n    h = hh[1];\n    l = hl[1];\n\n    a += l & 0xffff; b += l >>> 16;\n    c += h & 0xffff; d += h >>> 16;\n\n    b += a >>> 16;\n    c += b >>> 16;\n    d += c >>> 16;\n\n    hh[1] = ah1 = (c & 0xffff) | (d << 16);\n    hl[1] = al1 = (a & 0xffff) | (b << 16);\n\n    h = ah2;\n    l = al2;\n\n    a = l & 0xffff; b = l >>> 16;\n    c = h & 0xffff; d = h >>> 16;\n\n    h = hh[2];\n    l = hl[2];\n\n    a += l & 0xffff; b += l >>> 16;\n    c += h & 0xffff; d += h >>> 16;\n\n    b += a >>> 16;\n    c += b >>> 16;\n    d += c >>> 16;\n\n    hh[2] = ah2 = (c & 0xffff) | (d << 16);\n    hl[2] = al2 = (a & 0xffff) | (b << 16);\n\n    h = ah3;\n    l = al3;\n\n    a = l & 0xffff; b = l >>> 16;\n    c = h & 0xffff; d = h >>> 16;\n\n    h = hh[3];\n    l = hl[3];\n\n    a += l & 0xffff; b += l >>> 16;\n    c += h & 0xffff; d += h >>> 16;\n\n    b += a >>> 16;\n    c += b >>> 16;\n    d += c >>> 16;\n\n    hh[3] = ah3 = (c & 0xffff) | (d << 16);\n    hl[3] = al3 = (a & 0xffff) | (b << 16);\n\n    h = ah4;\n    l = al4;\n\n    a = l & 0xffff; b = l >>> 16;\n    c = h & 0xffff; d = h >>> 16;\n\n    h = hh[4];\n    l = hl[4];\n\n    a += l & 0xffff; b += l >>> 16;\n    c += h & 0xffff; d += h >>> 16;\n\n    b += a >>> 16;\n    c += b >>> 16;\n    d += c >>> 16;\n\n    hh[4] = ah4 = (c & 0xffff) | (d << 16);\n    hl[4] = al4 = (a & 0xffff) | (b << 16);\n\n    h = ah5;\n    l = al5;\n\n    a = l & 0xffff; b = l >>> 16;\n    c = h & 0xffff; d = h >>> 16;\n\n    h = hh[5];\n    l = hl[5];\n\n    a += l & 0xffff; b += l >>> 16;\n    c += h & 0xffff; d += h >>> 16;\n\n    b += a >>> 16;\n    c += b >>> 16;\n    d += c >>> 16;\n\n    hh[5] = ah5 = (c & 0xffff) | (d << 16);\n    hl[5] = al5 = (a & 0xffff) | (b << 16);\n\n    h = ah6;\n    l = al6;\n\n    a = l & 0xffff; b = l >>> 16;\n    c = h & 0xffff; d = h >>> 16;\n\n    h = hh[6];\n    l = hl[6];\n\n    a += l & 0xffff; b += l >>> 16;\n    c += h & 0xffff; d += h >>> 16;\n\n    b += a >>> 16;\n    c += b >>> 16;\n    d += c >>> 16;\n\n    hh[6] = ah6 = (c & 0xffff) | (d << 16);\n    hl[6] = al6 = (a & 0xffff) | (b << 16);\n\n    h = ah7;\n    l = al7;\n\n    a = l & 0xffff; b = l >>> 16;\n    c = h & 0xffff; d = h >>> 16;\n\n    h = hh[7];\n    l = hl[7];\n\n    a += l & 0xffff; b += l >>> 16;\n    c += h & 0xffff; d += h >>> 16;\n\n    b += a >>> 16;\n    c += b >>> 16;\n    d += c >>> 16;\n\n    hh[7] = ah7 = (c & 0xffff) | (d << 16);\n    hl[7] = al7 = (a & 0xffff) | (b << 16);\n\n    pos += 128;\n    n -= 128;\n  }\n\n  return n;\n}\n\nfunction crypto_hash(out, m, n) {\n  var hh = new Int32Array(8),\n      hl = new Int32Array(8),\n      x = new Uint8Array(256),\n      i, b = n;\n\n  hh[0] = 0x6a09e667;\n  hh[1] = 0xbb67ae85;\n  hh[2] = 0x3c6ef372;\n  hh[3] = 0xa54ff53a;\n  hh[4] = 0x510e527f;\n  hh[5] = 0x9b05688c;\n  hh[6] = 0x1f83d9ab;\n  hh[7] = 0x5be0cd19;\n\n  hl[0] = 0xf3bcc908;\n  hl[1] = 0x84caa73b;\n  hl[2] = 0xfe94f82b;\n  hl[3] = 0x5f1d36f1;\n  hl[4] = 0xade682d1;\n  hl[5] = 0x2b3e6c1f;\n  hl[6] = 0xfb41bd6b;\n  hl[7] = 0x137e2179;\n\n  crypto_hashblocks_hl(hh, hl, m, n);\n  n %= 128;\n\n  for (i = 0; i < n; i++) x[i] = m[b-n+i];\n  x[n] = 128;\n\n  n = 256-128*(n<112?1:0);\n  x[n-9] = 0;\n  ts64(x, n-8,  (b / 0x20000000) | 0, b << 3);\n  crypto_hashblocks_hl(hh, hl, x, n);\n\n  for (i = 0; i < 8; i++) ts64(out, 8*i, hh[i], hl[i]);\n\n  return 0;\n}\n\nfunction add(p, q) {\n  var a = gf(), b = gf(), c = gf(),\n      d = gf(), e = gf(), f = gf(),\n      g = gf(), h = gf(), t = gf();\n\n  Z(a, p[1], p[0]);\n  Z(t, q[1], q[0]);\n  M(a, a, t);\n  A(b, p[0], p[1]);\n  A(t, q[0], q[1]);\n  M(b, b, t);\n  M(c, p[3], q[3]);\n  M(c, c, D2);\n  M(d, p[2], q[2]);\n  A(d, d, d);\n  Z(e, b, a);\n  Z(f, d, c);\n  A(g, d, c);\n  A(h, b, a);\n\n  M(p[0], e, f);\n  M(p[1], h, g);\n  M(p[2], g, f);\n  M(p[3], e, h);\n}\n\nfunction cswap(p, q, b) {\n  var i;\n  for (i = 0; i < 4; i++) {\n    sel25519(p[i], q[i], b);\n  }\n}\n\nfunction pack(r, p) {\n  var tx = gf(), ty = gf(), zi = gf();\n  inv25519(zi, p[2]);\n  M(tx, p[0], zi);\n  M(ty, p[1], zi);\n  pack25519(r, ty);\n  r[31] ^= par25519(tx) << 7;\n}\n\nfunction scalarmult(p, q, s) {\n  var b, i;\n  set25519(p[0], gf0);\n  set25519(p[1], gf1);\n  set25519(p[2], gf1);\n  set25519(p[3], gf0);\n  for (i = 255; i >= 0; --i) {\n    b = (s[(i/8)|0] >> (i&7)) & 1;\n    cswap(p, q, b);\n    add(q, p);\n    add(p, p);\n    cswap(p, q, b);\n  }\n}\n\nfunction scalarbase(p, s) {\n  var q = [gf(), gf(), gf(), gf()];\n  set25519(q[0], X);\n  set25519(q[1], Y);\n  set25519(q[2], gf1);\n  M(q[3], X, Y);\n  scalarmult(p, q, s);\n}\n\nfunction crypto_sign_keypair(pk, sk, seeded) {\n  var d = new Uint8Array(64);\n  var p = [gf(), gf(), gf(), gf()];\n  var i;\n\n  if (!seeded) randombytes(sk, 32);\n  crypto_hash(d, sk, 32);\n  d[0] &= 248;\n  d[31] &= 127;\n  d[31] |= 64;\n\n  scalarbase(p, d);\n  pack(pk, p);\n\n  for (i = 0; i < 32; i++) sk[i+32] = pk[i];\n  return 0;\n}\n\nvar L = new Float64Array([0xed, 0xd3, 0xf5, 0x5c, 0x1a, 0x63, 0x12, 0x58, 0xd6, 0x9c, 0xf7, 0xa2, 0xde, 0xf9, 0xde, 0x14, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x10]);\n\nfunction modL(r, x) {\n  var carry, i, j, k;\n  for (i = 63; i >= 32; --i) {\n    carry = 0;\n    for (j = i - 32, k = i - 12; j < k; ++j) {\n      x[j] += carry - 16 * x[i] * L[j - (i - 32)];\n      carry = Math.floor((x[j] + 128) / 256);\n      x[j] -= carry * 256;\n    }\n    x[j] += carry;\n    x[i] = 0;\n  }\n  carry = 0;\n  for (j = 0; j < 32; j++) {\n    x[j] += carry - (x[31] >> 4) * L[j];\n    carry = x[j] >> 8;\n    x[j] &= 255;\n  }\n  for (j = 0; j < 32; j++) x[j] -= carry * L[j];\n  for (i = 0; i < 32; i++) {\n    x[i+1] += x[i] >> 8;\n    r[i] = x[i] & 255;\n  }\n}\n\nfunction reduce(r) {\n  var x = new Float64Array(64), i;\n  for (i = 0; i < 64; i++) x[i] = r[i];\n  for (i = 0; i < 64; i++) r[i] = 0;\n  modL(r, x);\n}\n\n// Note: difference from C - smlen returned, not passed as argument.\nfunction crypto_sign(sm, m, n, sk) {\n  var d = new Uint8Array(64), h = new Uint8Array(64), r = new Uint8Array(64);\n  var i, j, x = new Float64Array(64);\n  var p = [gf(), gf(), gf(), gf()];\n\n  crypto_hash(d, sk, 32);\n  d[0] &= 248;\n  d[31] &= 127;\n  d[31] |= 64;\n\n  var smlen = n + 64;\n  for (i = 0; i < n; i++) sm[64 + i] = m[i];\n  for (i = 0; i < 32; i++) sm[32 + i] = d[32 + i];\n\n  crypto_hash(r, sm.subarray(32), n+32);\n  reduce(r);\n  scalarbase(p, r);\n  pack(sm, p);\n\n  for (i = 32; i < 64; i++) sm[i] = sk[i];\n  crypto_hash(h, sm, n + 64);\n  reduce(h);\n\n  for (i = 0; i < 64; i++) x[i] = 0;\n  for (i = 0; i < 32; i++) x[i] = r[i];\n  for (i = 0; i < 32; i++) {\n    for (j = 0; j < 32; j++) {\n      x[i+j] += h[i] * d[j];\n    }\n  }\n\n  modL(sm.subarray(32), x);\n  return smlen;\n}\n\nfunction unpackneg(r, p) {\n  var t = gf(), chk = gf(), num = gf(),\n      den = gf(), den2 = gf(), den4 = gf(),\n      den6 = gf();\n\n  set25519(r[2], gf1);\n  unpack25519(r[1], p);\n  S(num, r[1]);\n  M(den, num, D);\n  Z(num, num, r[2]);\n  A(den, r[2], den);\n\n  S(den2, den);\n  S(den4, den2);\n  M(den6, den4, den2);\n  M(t, den6, num);\n  M(t, t, den);\n\n  pow2523(t, t);\n  M(t, t, num);\n  M(t, t, den);\n  M(t, t, den);\n  M(r[0], t, den);\n\n  S(chk, r[0]);\n  M(chk, chk, den);\n  if (neq25519(chk, num)) M(r[0], r[0], I);\n\n  S(chk, r[0]);\n  M(chk, chk, den);\n  if (neq25519(chk, num)) return -1;\n\n  if (par25519(r[0]) === (p[31]>>7)) Z(r[0], gf0, r[0]);\n\n  M(r[3], r[0], r[1]);\n  return 0;\n}\n\nfunction crypto_sign_open(m, sm, n, pk) {\n  var i;\n  var t = new Uint8Array(32), h = new Uint8Array(64);\n  var p = [gf(), gf(), gf(), gf()],\n      q = [gf(), gf(), gf(), gf()];\n\n  if (n < 64) return -1;\n\n  if (unpackneg(q, pk)) return -1;\n\n  for (i = 0; i < n; i++) m[i] = sm[i];\n  for (i = 0; i < 32; i++) m[i+32] = pk[i];\n  crypto_hash(h, m, n);\n  reduce(h);\n  scalarmult(p, q, h);\n\n  scalarbase(q, sm.subarray(32));\n  add(p, q);\n  pack(t, p);\n\n  n -= 64;\n  if (crypto_verify_32(sm, 0, t, 0)) {\n    for (i = 0; i < n; i++) m[i] = 0;\n    return -1;\n  }\n\n  for (i = 0; i < n; i++) m[i] = sm[i + 64];\n  return n;\n}\n\nvar crypto_secretbox_KEYBYTES = 32,\n    crypto_secretbox_NONCEBYTES = 24,\n    crypto_secretbox_ZEROBYTES = 32,\n    crypto_secretbox_BOXZEROBYTES = 16,\n    crypto_scalarmult_BYTES = 32,\n    crypto_scalarmult_SCALARBYTES = 32,\n    crypto_box_PUBLICKEYBYTES = 32,\n    crypto_box_SECRETKEYBYTES = 32,\n    crypto_box_BEFORENMBYTES = 32,\n    crypto_box_NONCEBYTES = crypto_secretbox_NONCEBYTES,\n    crypto_box_ZEROBYTES = crypto_secretbox_ZEROBYTES,\n    crypto_box_BOXZEROBYTES = crypto_secretbox_BOXZEROBYTES,\n    crypto_sign_BYTES = 64,\n    crypto_sign_PUBLICKEYBYTES = 32,\n    crypto_sign_SECRETKEYBYTES = 64,\n    crypto_sign_SEEDBYTES = 32,\n    crypto_hash_BYTES = 64;\n\nnacl.lowlevel = {\n  crypto_core_hsalsa20: crypto_core_hsalsa20,\n  crypto_stream_xor: crypto_stream_xor,\n  crypto_stream: crypto_stream,\n  crypto_stream_salsa20_xor: crypto_stream_salsa20_xor,\n  crypto_stream_salsa20: crypto_stream_salsa20,\n  crypto_onetimeauth: crypto_onetimeauth,\n  crypto_onetimeauth_verify: crypto_onetimeauth_verify,\n  crypto_verify_16: crypto_verify_16,\n  crypto_verify_32: crypto_verify_32,\n  crypto_secretbox: crypto_secretbox,\n  crypto_secretbox_open: crypto_secretbox_open,\n  crypto_scalarmult: crypto_scalarmult,\n  crypto_scalarmult_base: crypto_scalarmult_base,\n  crypto_box_beforenm: crypto_box_beforenm,\n  crypto_box_afternm: crypto_box_afternm,\n  crypto_box: crypto_box,\n  crypto_box_open: crypto_box_open,\n  crypto_box_keypair: crypto_box_keypair,\n  crypto_hash: crypto_hash,\n  crypto_sign: crypto_sign,\n  crypto_sign_keypair: crypto_sign_keypair,\n  crypto_sign_open: crypto_sign_open,\n\n  crypto_secretbox_KEYBYTES: crypto_secretbox_KEYBYTES,\n  crypto_secretbox_NONCEBYTES: crypto_secretbox_NONCEBYTES,\n  crypto_secretbox_ZEROBYTES: crypto_secretbox_ZEROBYTES,\n  crypto_secretbox_BOXZEROBYTES: crypto_secretbox_BOXZEROBYTES,\n  crypto_scalarmult_BYTES: crypto_scalarmult_BYTES,\n  crypto_scalarmult_SCALARBYTES: crypto_scalarmult_SCALARBYTES,\n  crypto_box_PUBLICKEYBYTES: crypto_box_PUBLICKEYBYTES,\n  crypto_box_SECRETKEYBYTES: crypto_box_SECRETKEYBYTES,\n  crypto_box_BEFORENMBYTES: crypto_box_BEFORENMBYTES,\n  crypto_box_NONCEBYTES: crypto_box_NONCEBYTES,\n  crypto_box_ZEROBYTES: crypto_box_ZEROBYTES,\n  crypto_box_BOXZEROBYTES: crypto_box_BOXZEROBYTES,\n  crypto_sign_BYTES: crypto_sign_BYTES,\n  crypto_sign_PUBLICKEYBYTES: crypto_sign_PUBLICKEYBYTES,\n  crypto_sign_SECRETKEYBYTES: crypto_sign_SECRETKEYBYTES,\n  crypto_sign_SEEDBYTES: crypto_sign_SEEDBYTES,\n  crypto_hash_BYTES: crypto_hash_BYTES,\n\n  gf: gf,\n  D: D,\n  L: L,\n  pack25519: pack25519,\n  unpack25519: unpack25519,\n  M: M,\n  A: A,\n  S: S,\n  Z: Z,\n  pow2523: pow2523,\n  add: add,\n  set25519: set25519,\n  modL: modL,\n  scalarmult: scalarmult,\n  scalarbase: scalarbase,\n};\n\n/* High-level API */\n\nfunction checkLengths(k, n) {\n  if (k.length !== crypto_secretbox_KEYBYTES) throw new Error('bad key size');\n  if (n.length !== crypto_secretbox_NONCEBYTES) throw new Error('bad nonce size');\n}\n\nfunction checkBoxLengths(pk, sk) {\n  if (pk.length !== crypto_box_PUBLICKEYBYTES) throw new Error('bad public key size');\n  if (sk.length !== crypto_box_SECRETKEYBYTES) throw new Error('bad secret key size');\n}\n\nfunction checkArrayTypes() {\n  for (var i = 0; i < arguments.length; i++) {\n    if (!(arguments[i] instanceof Uint8Array))\n      throw new TypeError('unexpected type, use Uint8Array');\n  }\n}\n\nfunction cleanup(arr) {\n  for (var i = 0; i < arr.length; i++) arr[i] = 0;\n}\n\nnacl.randomBytes = function(n) {\n  var b = new Uint8Array(n);\n  randombytes(b, n);\n  return b;\n};\n\nnacl.secretbox = function(msg, nonce, key) {\n  checkArrayTypes(msg, nonce, key);\n  checkLengths(key, nonce);\n  var m = new Uint8Array(crypto_secretbox_ZEROBYTES + msg.length);\n  var c = new Uint8Array(m.length);\n  for (var i = 0; i < msg.length; i++) m[i+crypto_secretbox_ZEROBYTES] = msg[i];\n  crypto_secretbox(c, m, m.length, nonce, key);\n  return c.subarray(crypto_secretbox_BOXZEROBYTES);\n};\n\nnacl.secretbox.open = function(box, nonce, key) {\n  checkArrayTypes(box, nonce, key);\n  checkLengths(key, nonce);\n  var c = new Uint8Array(crypto_secretbox_BOXZEROBYTES + box.length);\n  var m = new Uint8Array(c.length);\n  for (var i = 0; i < box.length; i++) c[i+crypto_secretbox_BOXZEROBYTES] = box[i];\n  if (c.length < 32) return null;\n  if (crypto_secretbox_open(m, c, c.length, nonce, key) !== 0) return null;\n  return m.subarray(crypto_secretbox_ZEROBYTES);\n};\n\nnacl.secretbox.keyLength = crypto_secretbox_KEYBYTES;\nnacl.secretbox.nonceLength = crypto_secretbox_NONCEBYTES;\nnacl.secretbox.overheadLength = crypto_secretbox_BOXZEROBYTES;\n\nnacl.scalarMult = function(n, p) {\n  checkArrayTypes(n, p);\n  if (n.length !== crypto_scalarmult_SCALARBYTES) throw new Error('bad n size');\n  if (p.length !== crypto_scalarmult_BYTES) throw new Error('bad p size');\n  var q = new Uint8Array(crypto_scalarmult_BYTES);\n  crypto_scalarmult(q, n, p);\n  return q;\n};\n\nnacl.scalarMult.base = function(n) {\n  checkArrayTypes(n);\n  if (n.length !== crypto_scalarmult_SCALARBYTES) throw new Error('bad n size');\n  var q = new Uint8Array(crypto_scalarmult_BYTES);\n  crypto_scalarmult_base(q, n);\n  return q;\n};\n\nnacl.scalarMult.scalarLength = crypto_scalarmult_SCALARBYTES;\nnacl.scalarMult.groupElementLength = crypto_scalarmult_BYTES;\n\nnacl.box = function(msg, nonce, publicKey, secretKey) {\n  var k = nacl.box.before(publicKey, secretKey);\n  return nacl.secretbox(msg, nonce, k);\n};\n\nnacl.box.before = function(publicKey, secretKey) {\n  checkArrayTypes(publicKey, secretKey);\n  checkBoxLengths(publicKey, secretKey);\n  var k = new Uint8Array(crypto_box_BEFORENMBYTES);\n  crypto_box_beforenm(k, publicKey, secretKey);\n  return k;\n};\n\nnacl.box.after = nacl.secretbox;\n\nnacl.box.open = function(msg, nonce, publicKey, secretKey) {\n  var k = nacl.box.before(publicKey, secretKey);\n  return nacl.secretbox.open(msg, nonce, k);\n};\n\nnacl.box.open.after = nacl.secretbox.open;\n\nnacl.box.keyPair = function() {\n  var pk = new Uint8Array(crypto_box_PUBLICKEYBYTES);\n  var sk = new Uint8Array(crypto_box_SECRETKEYBYTES);\n  crypto_box_keypair(pk, sk);\n  return {publicKey: pk, secretKey: sk};\n};\n\nnacl.box.keyPair.fromSecretKey = function(secretKey) {\n  checkArrayTypes(secretKey);\n  if (secretKey.length !== crypto_box_SECRETKEYBYTES)\n    throw new Error('bad secret key size');\n  var pk = new Uint8Array(crypto_box_PUBLICKEYBYTES);\n  crypto_scalarmult_base(pk, secretKey);\n  return {publicKey: pk, secretKey: new Uint8Array(secretKey)};\n};\n\nnacl.box.publicKeyLength = crypto_box_PUBLICKEYBYTES;\nnacl.box.secretKeyLength = crypto_box_SECRETKEYBYTES;\nnacl.box.sharedKeyLength = crypto_box_BEFORENMBYTES;\nnacl.box.nonceLength = crypto_box_NONCEBYTES;\nnacl.box.overheadLength = nacl.secretbox.overheadLength;\n\nnacl.sign = function(msg, secretKey) {\n  checkArrayTypes(msg, secretKey);\n  if (secretKey.length !== crypto_sign_SECRETKEYBYTES)\n    throw new Error('bad secret key size');\n  var signedMsg = new Uint8Array(crypto_sign_BYTES+msg.length);\n  crypto_sign(signedMsg, msg, msg.length, secretKey);\n  return signedMsg;\n};\n\nnacl.sign.open = function(signedMsg, publicKey) {\n  checkArrayTypes(signedMsg, publicKey);\n  if (publicKey.length !== crypto_sign_PUBLICKEYBYTES)\n    throw new Error('bad public key size');\n  var tmp = new Uint8Array(signedMsg.length);\n  var mlen = crypto_sign_open(tmp, signedMsg, signedMsg.length, publicKey);\n  if (mlen < 0) return null;\n  var m = new Uint8Array(mlen);\n  for (var i = 0; i < m.length; i++) m[i] = tmp[i];\n  return m;\n};\n\nnacl.sign.detached = function(msg, secretKey) {\n  var signedMsg = nacl.sign(msg, secretKey);\n  var sig = new Uint8Array(crypto_sign_BYTES);\n  for (var i = 0; i < sig.length; i++) sig[i] = signedMsg[i];\n  return sig;\n};\n\nnacl.sign.detached.verify = function(msg, sig, publicKey) {\n  checkArrayTypes(msg, sig, publicKey);\n  if (sig.length !== crypto_sign_BYTES)\n    throw new Error('bad signature size');\n  if (publicKey.length !== crypto_sign_PUBLICKEYBYTES)\n    throw new Error('bad public key size');\n  var sm = new Uint8Array(crypto_sign_BYTES + msg.length);\n  var m = new Uint8Array(crypto_sign_BYTES + msg.length);\n  var i;\n  for (i = 0; i < crypto_sign_BYTES; i++) sm[i] = sig[i];\n  for (i = 0; i < msg.length; i++) sm[i+crypto_sign_BYTES] = msg[i];\n  return (crypto_sign_open(m, sm, sm.length, publicKey) >= 0);\n};\n\nnacl.sign.keyPair = function() {\n  var pk = new Uint8Array(crypto_sign_PUBLICKEYBYTES);\n  var sk = new Uint8Array(crypto_sign_SECRETKEYBYTES);\n  crypto_sign_keypair(pk, sk);\n  return {publicKey: pk, secretKey: sk};\n};\n\nnacl.sign.keyPair.fromSecretKey = function(secretKey) {\n  checkArrayTypes(secretKey);\n  if (secretKey.length !== crypto_sign_SECRETKEYBYTES)\n    throw new Error('bad secret key size');\n  var pk = new Uint8Array(crypto_sign_PUBLICKEYBYTES);\n  for (var i = 0; i < pk.length; i++) pk[i] = secretKey[32+i];\n  return {publicKey: pk, secretKey: new Uint8Array(secretKey)};\n};\n\nnacl.sign.keyPair.fromSeed = function(seed) {\n  checkArrayTypes(seed);\n  if (seed.length !== crypto_sign_SEEDBYTES)\n    throw new Error('bad seed size');\n  var pk = new Uint8Array(crypto_sign_PUBLICKEYBYTES);\n  var sk = new Uint8Array(crypto_sign_SECRETKEYBYTES);\n  for (var i = 0; i < 32; i++) sk[i] = seed[i];\n  crypto_sign_keypair(pk, sk, true);\n  return {publicKey: pk, secretKey: sk};\n};\n\nnacl.sign.publicKeyLength = crypto_sign_PUBLICKEYBYTES;\nnacl.sign.secretKeyLength = crypto_sign_SECRETKEYBYTES;\nnacl.sign.seedLength = crypto_sign_SEEDBYTES;\nnacl.sign.signatureLength = crypto_sign_BYTES;\n\nnacl.hash = function(msg) {\n  checkArrayTypes(msg);\n  var h = new Uint8Array(crypto_hash_BYTES);\n  crypto_hash(h, msg, msg.length);\n  return h;\n};\n\nnacl.hash.hashLength = crypto_hash_BYTES;\n\nnacl.verify = function(x, y) {\n  checkArrayTypes(x, y);\n  // Zero length arguments are considered not equal.\n  if (x.length === 0 || y.length === 0) return false;\n  if (x.length !== y.length) return false;\n  return (vn(x, 0, y, 0, x.length) === 0) ? true : false;\n};\n\nnacl.setPRNG = function(fn) {\n  randombytes = fn;\n};\n\n(function() {\n  // Initialize PRNG if environment provides CSPRNG.\n  // If not, methods calling randombytes will throw.\n  var crypto = typeof self !== 'undefined' ? (self.crypto || self.msCrypto) : null;\n  if (crypto && crypto.getRandomValues) {\n    // Browsers.\n    var QUOTA = 65536;\n    nacl.setPRNG(function(x, n) {\n      var i, v = new Uint8Array(n);\n      for (i = 0; i < n; i += QUOTA) {\n        crypto.getRandomValues(v.subarray(i, i + Math.min(n - i, QUOTA)));\n      }\n      for (i = 0; i < n; i++) x[i] = v[i];\n      cleanup(v);\n    });\n  } else if (true) {\n    // Node.js.\n    crypto = __webpack_require__(/*! crypto */ 0);\n    if (crypto && crypto.randomBytes) {\n      nacl.setPRNG(function(x, n) {\n        var i, v = crypto.randomBytes(n);\n        for (i = 0; i < n; i++) x[i] = v[i];\n        cleanup(v);\n      });\n    }\n  }\n})();\n\n})( true && module.exports ? module.exports : (self.nacl = self.nacl || {}));\n\n\n//# sourceURL=webpack:///../node_modules/tweetnacl/nacl-fast.js?"
        );

        /***/
      },

    /***/ "./content.js":
      /*!********************!*\
  !*** ./content.js ***!
  \********************/
      /*! no exports provided */
      /***/ function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        eval(
          '__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _popup_router_tools_LocalStorage_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./popup/router/tools/LocalStorage.js */ "./popup/router/tools/LocalStorage.js");\n //this callback is given to the page Mutation Observer It is called whenever changes occur on page.\n//If the page contains the hidden Let\'s Auth fields, they are stored in chrome storage\n//and the letsAuthenticate variable is set to true.\n\nvar scanForAuthDetails = async function () {\n  chrome.storage.local.get("letsAuthenticate", async function (data) {\n    //if there is already a pending request, nothing is collected from the page or changed in storage\n    if (!data.letsAuthenticate) {\n      chrome.storage.local.get("loggedIn", async function (loginValue) {\n        if (loginValue.loggedIn) {\n          var found = false; //check if hidden fields exist on page.\n          //If they do check that they have received values.\n\n          if (document.getElementById("letsAuthenticateIdUUID") && document.getElementById("letsAuthenticateIdDomain")) {\n            if (document.getElementById("letsAuthenticateIdUUID").value && document.getElementById("letsAuthenticateIdDomain").value) {\n              found = true;\n            }\n          }\n\n          if (found) {\n            chrome.storage.local.set({\n              letsAuthenticate: true\n            });\n            chrome.storage.local.set({\n              letsAuthenticateIdUUID: document.getElementById("letsAuthenticateIdUUID").value\n            });\n            chrome.storage.local.set({\n              letsAuthenticateIdDomain: document.getElementById("letsAuthenticateIdDomain").value\n            });\n            chrome.storage.local.set({\n              letsAuthenticateWebUrl: document.location.href\n            });\n            let isAutoSignIn = await Object(_popup_router_tools_LocalStorage_js__WEBPACK_IMPORTED_MODULE_0__["getSignInSetting"])();\n\n            if (!isAutoSignIn) {\n              //direct user to popup window\n              alert("Login Request Received. Accept Request in 1Key extension popup.");\n            }\n          } else {\n            //if no authentication is gonna happen, clear out storage because safety probably..\n            chrome.storage.local.set({\n              letsAuthenticate: false\n            });\n            chrome.storage.local.remove("letsAuthenticateIdUUID");\n            chrome.storage.local.remove("letsAuthenticateIdDomain");\n            chrome.storage.local.remove("letsAuthenticateWebUrl");\n          }\n        }\n      });\n    }\n  });\n}; // Create an observer instance linked to the callback function\n\n\nvar observer = new MutationObserver(scanForAuthDetails); // Start observing the target node (the body of the website) for configured mutations\n\nvar targetNode = document.body;\nobserver.observe(targetNode, {\n  attributes: true,\n  characterData: true,\n  childList: true,\n  subtree: true\n});\n/*//triggers anytime user clicks on page.\n//In the case where hidden fields are present before user logs in\n//user doesn\'t have to refresh page to make it work.\n//but this method has some issues.\ndocument.addEventListener("click", scanForAuthDetails);\n*/\n\n//# sourceURL=webpack:///./content.js?'
        );

        /***/
      },

    /***/ "./popup/router/tools/LocalStorage.js":
      /*!********************************************!*\
  !*** ./popup/router/tools/LocalStorage.js ***!
  \********************************************/
      /*! exports provided: clearSecretLocalStorage, setLoggedInCredentials, getLoggedInCredentials, setLogoutCredentials, setIndexeddbKey, resetIndexeddbKey, getIndexeddbKey, getIndexeddbKeyRecovery, getAuthenticateValue, getLoggedInValue, getDomain, getUuid, getLoginObject, getWebUrl, getSignInSetting, getLogoutSetting, getNightModeSetting, clearAuthInfoFromStorage */
      /***/ function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        eval(
          '__webpack_require__.r(__webpack_exports__);\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "clearSecretLocalStorage", function() { return clearSecretLocalStorage; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setLoggedInCredentials", function() { return setLoggedInCredentials; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getLoggedInCredentials", function() { return getLoggedInCredentials; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setLogoutCredentials", function() { return setLogoutCredentials; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setIndexeddbKey", function() { return setIndexeddbKey; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "resetIndexeddbKey", function() { return resetIndexeddbKey; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getIndexeddbKey", function() { return getIndexeddbKey; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getIndexeddbKeyRecovery", function() { return getIndexeddbKeyRecovery; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getAuthenticateValue", function() { return getAuthenticateValue; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getLoggedInValue", function() { return getLoggedInValue; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getDomain", function() { return getDomain; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getUuid", function() { return getUuid; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getLoginObject", function() { return getLoginObject; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getWebUrl", function() { return getWebUrl; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getSignInSetting", function() { return getSignInSetting; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getLogoutSetting", function() { return getLogoutSetting; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getNightModeSetting", function() { return getNightModeSetting; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "clearAuthInfoFromStorage", function() { return clearAuthInfoFromStorage; });\n/* harmony import */ var secure_ls__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! secure-ls */ "../node_modules/secure-ls/dist/secure-ls.js");\n/* harmony import */ var secure_ls__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(secure_ls__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var tweetnacl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tweetnacl */ "../node_modules/tweetnacl/nacl-fast.js");\n/* harmony import */ var tweetnacl__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(tweetnacl__WEBPACK_IMPORTED_MODULE_1__);\n//File dedicated solely to functions fetching local storage values\n//Functions are exported here and imported in the various vue components and pages that need them\n\n\nfunction clearSecretLocalStorage() {\n  let ls = new secure_ls__WEBPACK_IMPORTED_MODULE_0___default.a();\n  ls.clear();\n}\nfunction setLoggedInCredentials(password) {\n  //store password while user is logged in\n  let passwordLs = new secure_ls__WEBPACK_IMPORTED_MODULE_0___default.a({\n    encodingType: "des",\n    isCompression: true\n  });\n  passwordLs.set("credentials", password);\n}\nfunction getLoggedInCredentials() {\n  //store password while user is logged in\n  let passwordLs = new secure_ls__WEBPACK_IMPORTED_MODULE_0___default.a({\n    encodingType: "des",\n    isCompression: true\n  });\n\n  try {\n    return passwordLs.get("credentials");\n  } catch (error) {\n    return undefined;\n  }\n}\nfunction setLogoutCredentials() {\n  //take out stored password so nothing can be done\n  let passwordLs = new secure_ls__WEBPACK_IMPORTED_MODULE_0___default.a({\n    encodingType: "des",\n    isCompression: true\n  });\n  return passwordLs.remove("credentials");\n} //upon registration this is called to save the random key that opens the indexeddb stuff\n//takes password string and returns array of random account recovery passkeys\n\nfunction setIndexeddbKey(password) {\n  let key = Object(tweetnacl__WEBPACK_IMPORTED_MODULE_1__["randomBytes"])(32);\n  let ls = new secure_ls__WEBPACK_IMPORTED_MODULE_0___default.a({\n    encodingType: "des",\n    isCompression: true,\n    //encryptionSecret: password\n    encryptionNamespace: "main"\n  });\n  ls.set("indexeddbKey", key);\n  /*let emergencyKey = new SecureLS({\n    encodingType: "des",\n    isCompression: true\n  });\n  //TODO: store another copy of the key not protected by password for case\n  when another device changes password.\n  You\'ll have to delete the "main" that is stored by password and replace it with\n  the new password when user successfully logs in\n   This is NOT correct or final, but it will help with simulating the actual\n  experience of the updated system.\n  */\n  //generate 10 random Passkeys\n\n  let passkeys = [];\n\n  for (let i = 0; i < 10; i++) {\n    let passkey = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);\n    passkeys.push(passkey); //store key with each passkey\n\n    let passkeyLs = new secure_ls__WEBPACK_IMPORTED_MODULE_0___default.a({\n      encodingType: "des",\n      isCompression: true,\n      encryptionSecret: passkey,\n      encryptionNamespace: i.toString()\n    });\n    passkeyLs.set("indexeddbKey" + i.toString(), key);\n  }\n\n  return passkeys;\n} //in case of password change, this replaces storage of key by old password\n//this is not currently being used because key is no longer stored based on password\n//subject to change\n\nfunction resetIndexeddbKey(key, newPassword) {\n  let ls = new secure_ls__WEBPACK_IMPORTED_MODULE_0___default.a({\n    encodingType: "des",\n    isCompression: true,\n    //encryptionSecret: newPassword,\n    encryptionNamespace: "main"\n  });\n  ls.set("indexeddbKey", key);\n}\nfunction getIndexeddbKey(password) {\n  try {\n    let ls = new secure_ls__WEBPACK_IMPORTED_MODULE_0___default.a({\n      encodingType: "des",\n      isCompression: true,\n      //encryptionSecret: password\n      encryptionNamespace: "main"\n    });\n    let keyObj = ls.get("indexeddbKey");\n    let keyUint8 = new Uint8Array(32);\n\n    for (let i = 0; i < 32; i++) {\n      keyUint8[i] = keyObj[i];\n    }\n\n    return keyUint8;\n  } catch (error) {\n    //password was probably incorrect, key not found\n    console.log("PASSWORD WAS PROBABLY INCORRECT, KEY NOT FOUND");\n    return undefined;\n  }\n}\nfunction getIndexeddbKeyRecovery(recoveryPasskey) {\n  if (recoveryPasskey) {\n    for (let i = 0; i < 10; i++) {\n      try {\n        let ls = new secure_ls__WEBPACK_IMPORTED_MODULE_0___default.a({\n          encodingType: "des",\n          isCompression: true,\n          encryptionSecret: recoveryPasskey,\n          encryptionNamespace: i.toString()\n        });\n        let keyname = "indexeddbKey" + i.toString();\n        let keyObj = ls.get(keyname);\n\n        if (keyObj) {\n          ls.remove(keyname);\n          let keyUint8 = new Uint8Array(32);\n\n          for (let i = 0; i < 32; i++) {\n            keyUint8[i] = keyObj[i];\n          }\n\n          return keyUint8;\n        }\n      } catch (error) {} //doesn\'t match this passkey but it could be found elsewhere so we do nothing\n\n    }\n  } //not found\n\n\n  return undefined;\n}\nasync function getAuthenticateValue() {\n  //checks local storage to see if account has received any website request\n  return new Promise((resolve, reject) => {\n    try {\n      chrome.storage.local.get("letsAuthenticate", function (value) {\n        resolve(value.letsAuthenticate);\n      });\n    } catch (ex) {\n      reject(ex);\n    }\n  });\n}\nasync function getLoggedInValue() {\n  //checks local storage to see if account is logged in\n  return new Promise((resolve, reject) => {\n    try {\n      chrome.storage.local.get("loggedIn", function (value) {\n        resolve(value.loggedIn);\n      });\n    } catch (ex) {\n      reject(ex);\n    }\n  });\n}\nasync function getDomain() {\n  return new Promise((resolve, reject) => {\n    try {\n      chrome.storage.local.get("letsAuthenticateIdDomain", function (value) {\n        resolve(value.letsAuthenticateIdDomain);\n      });\n    } catch (ex) {\n      reject(ex);\n    }\n  });\n}\nasync function getUuid() {\n  return new Promise((resolve, reject) => {\n    try {\n      chrome.storage.local.get("letsAuthenticateIdUUID", function (value) {\n        resolve(value.letsAuthenticateIdUUID);\n      });\n    } catch (ex) {\n      reject(ex);\n    }\n  });\n} //^^WILL BE DEPRECATED IN FAVOR OF ONE HIDDEN FORM VALUE THAT CONTAINS AN OBJECT\n//This pulls out and returns the json string of login info from the hidden form fields\n\nasync function getLoginObject() {\n  return new Promise((resolve, reject) => {\n    try {\n      chrome.storage.local.get("letsAuthenticateLogin", function (value) {\n        resolve(value.letsAuthenticateLogin);\n      });\n    } catch (ex) {\n      reject(ex);\n    }\n  });\n}\nasync function getWebUrl() {\n  return new Promise((resolve, reject) => {\n    try {\n      chrome.storage.local.get("letsAuthenticateWebUrl", function (value) {\n        resolve(value.letsAuthenticateWebUrl);\n      });\n    } catch (ex) {\n      reject(ex);\n    }\n  });\n} //gets setting value of whether or not to streamline sign in.\n//Automatically set to false upon extension upload\n\nasync function getSignInSetting() {\n  return new Promise((resolve, reject) => {\n    try {\n      chrome.storage.sync.get("signInSetting", function (value) {\n        resolve(value.signInSetting);\n      });\n    } catch (ex) {\n      reject(ex);\n    }\n  });\n} //gets setting value of whether or not to have automatic logout.\n//stores value of number of minutes of idle time after which logout should occur\n//Automatically set to 0 upon extension upload (meaning no logout will occur)\n\nasync function getLogoutSetting() {\n  return new Promise((resolve, reject) => {\n    try {\n      chrome.storage.sync.get("logoutSetting", function (value) {\n        resolve(value.logoutSetting);\n      });\n    } catch (ex) {\n      reject(ex);\n    }\n  });\n} //gets setting value of whether or not to put colors in night mode.\n//Automatically set to false upon extension upload\n\nasync function getNightModeSetting() {\n  return new Promise((resolve, reject) => {\n    try {\n      chrome.storage.sync.get("nightModeSetting", function (value) {\n        resolve(value.nightModeSetting);\n      });\n    } catch (ex) {\n      reject(ex);\n    }\n  });\n}\nasync function clearAuthInfoFromStorage() {\n  //clears out all information collected from a website\'s hidden fields\n  //sets letsAuthenticate value to false\n  chrome.storage.local.set({\n    letsAuthenticate: false\n  });\n  chrome.storage.local.remove("letsAuthenticateIdUUID");\n  chrome.storage.local.remove("letsAuthenticateIdDomain");\n  chrome.storage.local.remove("letsAuthenticateWebUrl");\n}\n\n//# sourceURL=webpack:///./popup/router/tools/LocalStorage.js?'
        );

        /***/
      },

    /***/ 0:
      /*!************************!*\
  !*** crypto (ignored) ***!
  \************************/
      /*! no static exports found */
      /***/ function(module, exports) {
        eval("/* (ignored) */\n\n//# sourceURL=webpack:///crypto_(ignored)?");

        /***/
      }

    /******/
  }
);
